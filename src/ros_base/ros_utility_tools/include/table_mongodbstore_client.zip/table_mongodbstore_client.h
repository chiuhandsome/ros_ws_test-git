#ifndef BASE_MONGODBSTORE_CLIENT_H
#define BASE_MONGODBSTORE_CLIENT_H
//----------------------------------------------------------------------------
#include <ros/ros.h>
#include <mongodb_store/message_store.h>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/foreach.hpp>
#include <boost/any.hpp>
//---------------------------------------------------------------------------
typedef enum {
	edb_tb_err_type_none = 0 , edb_tb_err_type_empty, edb_tb_err_type_int, edb_tb_err_type_param,
    edb_tb_err_type_indexkey,  edb_tb_err_type_database
} db_tb_error_type;

typedef enum {
	edb_tb_search_base_code = 0 , edb_tb_search_base_name , edb_tb_search_system_id
} db_tb_search_type;
//---------------------------------------------------------------------------
using namespace mongodb_store ;
using namespace std ;
//----------------------------------------------------------------------------
//template<typename MsgType>
class table_mongodbstore_client
{
	private:
		/*ros::NodeHandle nh_ ;		
		std::string _tablename ;
		bool using_def_code_flag ;
		db_tb_search_type F_search_type ;
		std::string search_keydata ;	

		MessageStoreProxy* base_mongodb ; 
		std::multimap<std::string, std::string> searchkey_map ;
		void searchkey_map_erase(std::string base_code, std::string system_id);
		std::multimap<std::string, std::string> search_dynamic_map ;	
		void search_dynamic_map_refresh();
		//----------------------
		vector< boost::shared_ptr<MsgType>> ptr_results_vector ;
		vector< boost::shared_ptr<MsgType>> find_results_vector;
		//----------------------
		bool mongo_table_Insert(const boost::shared_ptr<MsgType> &_data);
		bool mongo_table_modify(const boost::shared_ptr<MsgType> &_data) ;*/
	protected:
	public:
		table_mongodbstore_client(ros::NodeHandle &nh,std::string tablename,bool def_code_flag=false);	 
		~table_mongodbstore_client();
		//----------------------------
		/*MessageStoreProxy* base_mongodb ; 
		std::multimap<std::string, std::string> searchkey_map ;
		void searchkey_map_erase(std::string base_code, std::string system_id);
		std::multimap<std::string, std::string> search_dynamic_map ;*/
		//----------------------------
		/*virtual void table_data_refresh() = 0 ;
		void db_table_refresh();
		vector< boost::shared_ptr<MsgType>> getdata_table_vector();
		bool is_search_key_Exist(const boost::shared_ptr<MsgType> &_iter);
		virtual void table_data_Insert() = 0 ;
		bool db_table_Insert(const boost::shared_ptr<MsgType> &_data,db_tb_error_type &err_type);
		virtual void table_data_modify() = 0 ;
		bool db_table_modify(const boost::shared_ptr<MsgType> &_data,db_tb_error_type &err_type);
		bool db_table_delete(std::string base_code);
		bool db_table_query_base_code(std::string _code_low,std::string _code_up);
		vector< boost::shared_ptr<MsgType>> get_find_results_vector();
		db_tb_error_type check_db_table_in_data(boost::shared_ptr<MsgType> _data);
		bool db_table_query_dynamic(std::string param_low,std::string param_up = "") ;
		void search_condition_set(db_tb_search_type _search_type,std::string search_key) ;*/
		//----------------------------
		/*template<typename MsgType> 
		void database_refresh(vector< boost::shared_ptr<MsgType>> &ptr_vector_results)
		{
			ptr_vector_results.clear();
		    base_mongodb->query<MsgType>(ptr_vector_results) ;
		    //BOOST_FOREACH( boost::shared_ptr<MsgType> p, ptr_vector_results)
		    //{
		    //	_mainmap.insert(std::pair<std::string, boost::shared_ptr<MsgType>>((*p).system_id,p));
		    //}
		}
		//----------------------------		
		template<typename MsgType> 
		bool database_Insert(const boost::shared_ptr<MsgType> &_data)
		{ 
			//-- add to mongo db ---			
			(*_data).update_time = get_Now_LocalTime();  //-- from tools
			std::string _id = base_mongodb->insertNamed(base_mongodb_tablename, (*_data));
			(*_data).system_id = _id ;
			bool bAdd = base_mongodb->updateID(_id, (*_data));
			//--------------
			return bAdd ;
		}
		//----------------------------
		template<typename MsgType> 
		bool database_modify(const boost::shared_ptr<MsgType> & _data)
		{
			//-- modified mongodb ----
			(*_data).update_time = get_Now_LocalTime();
			std::string id = (*_data).system_id ;
			bool bModify = base_mongodb->updateID(id, (*_data)); 
			return bModify ;
		}*/
		//-----------------
		//bool database_delete(std::string system_id)	;	
		//std::string get_updatetime_data(std::string  updatetime_data,bool bupper = false);
};
//-----------------------------------------------------------------------------
#endif   
