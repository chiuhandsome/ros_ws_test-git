#ifndef robot_if_proc_upper_ac_H
#define robot_if_proc_upper_ac_H
//---------------------------------------------------------------------------
#include <ros/ros.h>
#include <actionlib/client/simple_action_client.h>
#include <robot_scheduling_msgs/robot_interface_proc_upperAction.h>
//-----------------------------------------------------------------------------
class robot_if_proc_upper_ac  
{
	using if_proc_upper_ac = actionlib::SimpleActionClient<robot_scheduling_msgs::robot_interface_proc_upperAction> ;
	private:
   		ros::NodeHandle nh_ ;	
		//-- declare all action_clients   
		if_proc_upper_ac if_proc_upper_ac_;

		int eval_state_ ;
		//-- Called once when the goal completes ----
		void doneCb(const actionlib::SimpleClientGoalState& state,const robot_scheduling_msgs::robot_interface_proc_upperResultConstPtr& result);
		//-- Called once when the goal becomes active ---
		void activeCb() ;
		//-- Called every time feedback is received for the goal ---
  		void feedbackCb(const robot_scheduling_msgs::robot_interface_proc_upperFeedbackConstPtr& feedback);
	public:
	   	//robot_command_ac(ros::NodeHandle& nh,robot_scheduling_parameter* parameter) ;
		robot_if_proc_upper_ac(ros::NodeHandle& nh,std::string ac_name) ;
	   	~robot_if_proc_upper_ac();
	   	//--------------------		   
	   	int evalCondition(std::string condition);
	   	void do_robot_interface_proc_upper(const robot_scheduling_msgs::robot_interface_proc_upperGoal& goal);
};
//-----------------------------------------------------------------------------
#endif
