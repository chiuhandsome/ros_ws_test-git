^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package tug_example_actions
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.11 (2016-07-22)
-------------------

0.0.10 (2016-07-20)
-------------------

0.0.9 (2016-07-20)
------------------
* Merge pull request `#1 <https://github.com/marc-hanheide/PetriNetPlans/issues/1>`_ from marc-hanheide/master
  bringing it back in line with master branch
* * merged upstream (resolved conflicts)
  * added Luca Iocchi as author in all packages
  * sanitised some package.xml and CMakeLists.txt
  * Merge branch 'master' of https://github.com/iocchi/PetriNetPlans into upstream-merge
  Conflicts:
  PNP/src/CMakeLists.txt
* Contributors: Marc Hanheide

0.0.8 (2016-07-20)
------------------

0.0.7 (2016-04-26)
------------------

0.0.6 (2016-04-26)
------------------

0.0.5 (2016-04-26)
------------------

0.0.4 (2016-04-26)
------------------
* Merge branch 'catkinised' of https://github.com/marc-hanheide/PetriNetPlans into catkinised
* added missing tf
* Contributors: Marc Hanheide

0.0.3 (2016-04-26)
------------------

0.0.2 (2016-04-25)
------------------
* cleaned changelogs
* Contributors: Marc Hanheide

0.0.1 (2016-04-25)
------------------
* Add cmake target dependencies of the executable/library to ensure that
  the required messages/services/actions are generated previously.
* add some example actions
* Contributors: Julia Nitsch, corot
