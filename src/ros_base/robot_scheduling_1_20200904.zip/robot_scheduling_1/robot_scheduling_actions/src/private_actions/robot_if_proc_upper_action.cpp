#include <private_actions/robot_if_proc_upper_action.h>
#include <ros_utility_tools/ros_tools.h>
//-----------------------------------------------------------------------------
robot_if_proc_upper_action::robot_if_proc_upper_action(ros::NodeHandle nh,std::string name_as) : nh_(nh), 
                        if_proc_upper_as(nh_,name_as, boost::bind(&robot_if_proc_upper_action::if_proc_upper_CB, this, _1), false)
{ 
    ROS_INFO("if_proc_upper_as.start()");
    if_proc_upper_as.start();
    //---------------------
    pubRobot_Info = nh_.advertise<robot_scheduling_msgs::robot_info>("hyc_robot_info", 10);
    pubRobot_state = nh_.advertise<robot_scheduling_msgs::robot_info>("hyc_robot_state", 10);
    begin_Time_Info = ros::Time::now() ;
    begin_Time_state = ros::Time::now() ;
    
    //---------------------
    if_topic_destory = false;
	if_topic_pass = false;
    if_topic_thread = std::unique_ptr<std::thread>( new std::thread( std::bind(&robot_if_proc_upper_action::if_topic_ThreadEntry, this)));
}    
//-----------------------------------------------------------------------------
robot_if_proc_upper_action::~robot_if_proc_upper_action()
{
    if (if_topic_thread->joinable()){
        std::lock_guard<std::mutex> lock(if_topic_mtx);
        if_topic_destory = true;
        if_topic_cv.notify_one();
    }    
}
//-------------------------------------------------------		
runmode_type robot_if_proc_upper_action::sys_runmode_type_decise()
{
    runmode_type run_type = runmode_none ;
    runstatus_type sys_status = parameter_->get_system_status() ;  
    manualstatus_type m_type = parameter_->get_manual_status();
    remotestatus_type r_type = parameter_->get_remote_status();
    if((sys_status == runstatus_standby) || (sys_status == runstatus_manual) || (sys_status == runstatus_remote)){
        bool b_manual_none = (m_type == manualstatus_none);
        bool b_remote_none = (r_type == remotestatus_none);    
        if(!b_manual_none || !b_remote_none)
            run_type = runmode_running ;
        else
            run_type = runmode_ready ;   
    }
    else if((sys_status == runstatus_unknow) || (sys_status == runstatus_awarded) ||
            (sys_status == runstatus_pause) )
        run_type = runmode_standby ;   
    else if(sys_status == runstatus_alarm) 
        run_type = runmode_alarm ; 

    return run_type ;
}
//-----------------------------------------------------------------------------
void robot_if_proc_upper_action::Process_SendTopic() 
{
    //-- topic process ----------
    double fTime_period_Info = (ros::Time::now() - begin_Time_Info).toSec() ;
    if(fTime_period_Info >= double(1.0/robot_info_rate)){
        robot_info_msg.robot_name = "hyc_robot_1";
        robot_info_msg.status = (int) parameter_->get_system_status();
        robot_info_msg.mode = (int)sys_runmode_type_decise() ;
        pubRobot_Info.publish(robot_info_msg);
        begin_Time_Info = ros::Time::now() ;
    }
    double fTime_period_State = (ros::Time::now() - begin_Time_state).toSec() ;
    if(fTime_period_State >= double(1.0/robot_state_rate)){
        robot_state_msg.robot_name = "hyc_robot_1";
        robot_state_msg.mode = (int)sys_runmode_type_decise() ;
        robot_state_msg.status = (int) parameter_->get_system_status();
        pubRobot_state.publish(robot_state_msg);
        begin_Time_state = ros::Time::now() ;
    }
    //-- check buffer size ----
    //bool buffer_size = true ;  
	if_topic_pass = true ; 
	if_topic_cv.notify_one(); 
}
//-----------------------------------------------------------------------------
void robot_if_proc_upper_action::if_topic_ThreadEntry() 
{
	std::this_thread::sleep_for(std::chrono::milliseconds(1));
	//-- send message to stm for UDPWOrkerData including eVector_pub,eVector_cltService,eVector_srvService type
	while(true){
		std::unique_lock<std::mutex> lock(if_topic_mtx);	
		if_topic_cv.wait( lock, [&] () { return (if_topic_destory || if_topic_pass) ; } );
		if(if_topic_destory)
			break;
		else{
			//-- send topic topic logic ----	
			Process_SendTopic();
		}	
		std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
	}
}
//-----------------------------------------------------------------------------
void robot_if_proc_upper_action::set_robot_scheduling_parameter(robot_scheduling_parameter* parameter)
{
    parameter_ = parameter ;
    //---------------
    parameter_->get_upper_topic_rate(robot_info_rate , robot_state_rate);
    //-----------------
    if_topic_pass = true;
    if_topic_cv.notify_one(); 
}
//-----------------------------------------------------------------------------
void robot_if_proc_upper_action::set_robot_scheduling_service(robot_scheduling_service* service)
{
    service_ = service ;
}
//-----------------------------------------------------------------------------
void robot_if_proc_upper_action::if_proc_upper_CB(const robot_scheduling_msgs::robot_interface_proc_upperGoalConstPtr& goal)
{
    ROS_INFO("if_proc_upper_CB");   
    if (if_proc_upper_as.isPreemptRequested() || !ros::ok()){
        ROS_ERROR("if_proc_upper_as execution preempted.");
        if_proc_upper_as.setPreempted();
        return;
    }
    else{  
        int cmd_type = goal->cmd_type ;
        bool bResult = false ;        
        //--- interface upper Process --------------------------
        if(cmd_type == robot_scheduling_msgs::robot_interface_proc_upperGoal::GET_STATUS){
            do_proc_upper_get_function(goal) ;
        }
        //--- Status_code Process ---------------------------
        else if(cmd_type == robot_scheduling_msgs::robot_interface_proc_upperGoal::SET_COMMAND){
            do_proc_upper_set_function(goal) ;
        }                
    }
}
//-----------------------------------------------------------------------------
void robot_if_proc_upper_action::do_proc_upper_get_function(const robot_scheduling_msgs::robot_interface_proc_upperGoalConstPtr& goal)
{  
    ROS_INFO("do_proc_upper_get_function");   
    int cmd_id = goal->cmd_id ;
    bool bResult = false ;
    robot_scheduling_msgs::robot_interface_proc_upperResult _result;
    //----------------------
    if(cmd_id == robot_scheduling_msgs::robot_interface_proc_upperGoal::BASE_PROC){
        if(parameter_->get_b_simulation()){
            //parameter_->set_base_ctrl_connected(true);
            _result.result = robot_scheduling_msgs::robot_interface_proc_upperResult::OK;
        }
        else{
            //-- process topic and service data --
            _result.result = robot_scheduling_msgs::robot_interface_proc_upperResult::OK;
        }         
        bResult = true ;   
    }




    /*if(cmd_id == robot_scheduling_msgs::robot_interface_proc_upperGoal::BASE_READY){
        if(parameter_->get_b_simulation()){
            //ROS_INFO("b_simulation - do_proc_upper_function");
            //parameter_->set_base_ctrl_connected(true);
            _result.result = robot_scheduling_msgs::robot_interface_proc_upperResult::OK;
        }
        else{
            //-- process topic and service data --
            _result.result = robot_scheduling_msgs::robot_interface_proc_upperResult::OK;
        }         
        bResult = true ;   
    }
    //----------------------
    else if(cmd_id == robot_scheduling_msgs::robot_interface_proc_upperGoal::STATUS ||
            cmd_id == robot_scheduling_msgs::robot_interface_proc_upperGoal::BASE_CONNECT ){
        int call_type = robot_scheduling_msgs::robot_interface_proc_upperGoal::GET_STATUS ;
        int call_id = robot_scheduling_msgs::robot_interface_proc_upperGoal::STATUS ;
        std::string call_data = "" ; 

        service_->call_service_to_base_ctrl(call_type,call_id,call_data);
        if(cmd_id == robot_scheduling_msgs::robot_interface_proc_upperGoal::BASE_CONNECT)
            _result.result = parameter_->get_base_ctrl_connected() ? robot_scheduling_msgs::robot_interface_proc_upperResult::OK :
                                                                     robot_scheduling_msgs::robot_interface_proc_upperResult::PASS;
        else{                                                             
            _result.result = robot_scheduling_msgs::robot_interface_proc_upperResult::OK ;
        }
        _result.result_state = parameter_->get_base_status_type();
        bResult = true ;     
    }*/
    //---------------------------------------------------------------------        
    if(bResult){
        if_proc_upper_as.setSucceeded(_result);      
    }
    else{
        if_proc_upper_as.setAborted(_result);      
    } 
    //--------------------------------------------------------------
}
//-----------------------------------------------------------------------------
void robot_if_proc_upper_action::do_proc_upper_set_function(const robot_scheduling_msgs::robot_interface_proc_upperGoalConstPtr& goal) 
{
    bool bResult = false ;
    robot_scheduling_msgs::robot_interface_proc_upperResult _result;

    if(parameter_->get_b_simulation()){
        ROS_INFO("b_simulation - do_proc_upper_upper_function");
        //parameter_->set_base_ctrl_connected(true);
        bResult = true ;
    }
    //---------------------------------------------------------------------        
    if(bResult){
        if_proc_upper_as.setSucceeded(_result);      
    }
    else{
        if_proc_upper_as.setAborted(_result);      
    } 
}
//--------------------------------------------------------------------------------
