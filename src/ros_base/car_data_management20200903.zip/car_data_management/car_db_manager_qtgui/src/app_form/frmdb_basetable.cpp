#include "car_db_manager/app_form/frmdb_basetable.h"
#include "ui_frmdb_basetable.h"
#include "car_db_manager/utility/qt_generaltools.h"
#include <QMessageBox>
#include <ros_utility_tools/ros_tools.h>
//-----------------------------------------------------------------------------
frmDB_baseTable::frmDB_baseTable(qt_app_model* app_mode,QWidget *parent) :
    QWidget(parent),
    ui(new Ui::frmDB_baseTable)
{
    ui->setupUi(this);
    _app_mode = app_mode ;    
    //---------------------
    set_style_sheet();
    //----------------------
    _fieldname_Vec_E.clear();
    _fieldname_Vec_TC.clear();
    _fieldname_Vec_SC.clear();
    _titlename_Vec_E.clear();
    _titlename_Vec_E.clear();
    _titlename_Vec_E.clear();
    _fiels_maxnum = 12 ;
    //----------------------
    _table_OP_type = db_table_OP_None ;
    _table_sorttype = ebasetable_sort_code ;

    b_rowno_error_false = false ;
}
//-----------------------------------------------------------------------------
frmDB_baseTable::~frmDB_baseTable()
{
    delete ui;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  base conrtoller area   --- fixed                                       **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmDB_baseTable::set_style_sheet()
{
    labeltitle_style_enable = "QLabel{font: bold 14pt;color:Blue;}";
    labeltitle_style_disable = "QLabel{font: bold 14pt;color:Gray;}";
    label_style_enable = "QLabel{font: bold 12pt;color:Blue;}";
    label_style_disable = "QLabel{font: bold 12pt;color:Gray;}";
    
    lineedit_style_enable = "QLineEdit{font: bold 12pt;color:Blue;\
                                       background-color:yellow}";
    lineedit_style_disable = "QLineEdit{font: bold 12pt;color:Gray;\
                                        background-color:white}";
    groupbox_style_enable = "QGroupBox{font: bold 14pt;\
                                       color:blue;\
                                       border: 1px solid silver;\
                                       border-radius: 6px;\
                                       margin-top: 6px;\
                                      }\
                              QGroupBox::title {subcontrol-origin: margin; \
                                                left: 12px;\
                                                top:  -2px;\
                                                padding: 0 5px 0 5px;\
                                               }\
                              QGroupBox::indicator:unchecked {image: url(:/png/resource/tools_png/robot_001.png);\
                                               }";
      groupbox_style_disable = "QGroupBox{font: bold 14pt;\
                                         color:gray;\
                                         border: 1px solid silver;\
                                         border-radius: 6px;\
                                         margin-top: 6px;\
                                        }\
                                QGroupBox::title {subcontrol-origin: margin; \
                                                  left: 12px;\
                                                  top:  -2px;\
                                                  padding: 0 5px 0 5px;\
                                                 }\
                                QGroupBox::indicator:unchecked {image: url(:/png/resource/tools_png/robot_001.png);\
                                                 }";
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::control_model_set(ros_controlmodel *controlmodel)
{
    _controlmodel = controlmodel ;
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::vectors_clear()
{
    _fieldname_Vec_E.clear();
    _fieldname_Vec_TC.clear();
    _fieldname_Vec_SC.clear();

    _titlename_Vec_E.clear();
    _titlename_Vec_TC.clear();
    _titlename_Vec_SC.clear();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::parse_basetb_base()
{
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    //-- caption show of operation ----------------
    ui->btn_op_add->setText((lang_type == elanguage_type_TC)? "新增" :
                            ((lang_type == elanguage_type_SC)? "新增":"new"));
    ui->btn_op_modify->setText((lang_type == elanguage_type_TC)? "修改" :
                               ((lang_type == elanguage_type_SC)? "修改":"Modify"));
    ui->btn_op_delete->setText((lang_type == elanguage_type_TC)? "删除" :
                               ((lang_type == elanguage_type_SC)? "删除":"DDelete"));
    ui->btn_op_inquire->setText((lang_type == elanguage_type_TC)? "查詢" :
                                ((lang_type == elanguage_type_SC)? "查询":"Inquire"));

    ui->btn_confirm->setText((lang_type == elanguage_type_TC)? "確認" :
                             ((lang_type == elanguage_type_SC)? "确认":"Confirm"));
    ui->btn_cancel->setText((lang_type == elanguage_type_TC)? "取消" :
                             ((lang_type == elanguage_type_SC)? "取消":"Cancel"));
    ui->btn_close->setText((lang_type == elanguage_type_TC)? "離開" :
                             ((lang_type == elanguage_type_SC)? "离开":"Exit"));
    //--- search_frame show -----------------------
    ui->gbox_search_condition->setTitle((lang_type == elanguage_type_TC)? " 選擇搜尋欄位 " :
                                        ((lang_type == elanguage_type_SC)? " 选择搜寻栏位 ":" Select search field "));
    ui->gbox_search_region->setTitle((lang_type == elanguage_type_TC)? " 輸入搜尋範圍 " :
                                     ((lang_type == elanguage_type_SC)? " 输入搜寻范围 ":" Enter search region "));
    ui->lb_search_from->setText((lang_type == elanguage_type_TC)? "起始" :
                                ((lang_type == elanguage_type_SC)? "起始":"from"));
    ui->lb_search_to->setText((lang_type == elanguage_type_TC)? "結束" :
                                ((lang_type == elanguage_type_SC)? "结束":"to"));
    ui->btn_search_confirm->setText((lang_type == elanguage_type_TC)? "確認" :
                                    ((lang_type == elanguage_type_SC)? "确认":"Confirm"));
    ui->btn_search_cancel->setText((lang_type == elanguage_type_TC)? "返回" :
                                   ((lang_type == elanguage_type_SC)? "返回":"Return"));    
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::form_tabletype_show()
{
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    //-- groupbox title and table title show ---
    QString gbox_title = "";
    QString table_title = "";
    if(lang_type == elanguage_type_E){
        gbox_title = _titlename_Vec_E[0];
        table_title = _titlename_Vec_E[1];
    }
    else if(lang_type == elanguage_type_TC){
        gbox_title = _titlename_Vec_TC[0];
        table_title = _titlename_Vec_TC[1];
    }
    else if(lang_type == elanguage_type_SC){
        gbox_title = _titlename_Vec_SC[0];
        table_title = _titlename_Vec_SC[1];
    }
    ui->lb_titlename->setText(table_title);
    ui->gbox_basetable->setTitle(gbox_title);
    //-- label and lineedit show in edit_frame ----------------
    QString label_name ;
    QString lineedit_name ;
    
    for(int i=0;i<_fiels_maxnum;i++){
        lineedit_name = "lineEdit_"+QString::number(i);
        label_name = "lb_field_"+QString::number(i);
        QLineEdit *obj_lEdit = ui->edit_frame->findChild<QLineEdit *>(lineedit_name);
        QLabel *obj_label = ui->edit_frame->findChild<QLabel *>(label_name);
        if(obj_lEdit && obj_label){
            bool bVisible = (i<_fiels_num);
            obj_lEdit->setVisible(bVisible);
            obj_label->setVisible(bVisible);
            if(bVisible){
                //obj_label->setEnabled(bEdit);
                if(lang_type == elanguage_type_E)
                    obj_label->setText(_fieldname_Vec_E[i]);
                else if(lang_type == elanguage_type_TC)
                    obj_label->setText(_fieldname_Vec_TC[i]);
                else if(lang_type == elanguage_type_SC)
                    obj_label->setText(_fieldname_Vec_SC[i]);
            }
        }
    }
    //-- title show of tableWidget ----------------
    ui->tableWidget->setVisible(true);
    ui->tableWidget->setRowCount(1);
    ui->tableWidget->setColumnCount(_fiels_num);
    QStringList header;    
    //QString label_name ;
    QString data ;
    for(int i=0;i<_fiels_num;i++){
        label_name = "lb_field_"+QString::number(i);
        QLabel *obj_label = ui->edit_frame->findChild<QLabel *>((QString)label_name);
        data = (QString)obj_label->text();
        header.append(data);
    }
    ui->tableWidget->setHorizontalHeaderLabels(header);
    ui->tableWidget->setSortingEnabled(false);
    for(int i=0;i<_fiels_num;i++){
        ui->tableWidget->setItem(0,i,new QTableWidgetItem(""));   // (row,col) 
    }
    ui->tableWidget->setSortingEnabled(true);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    
    //--- initial dataset ------------------------- 
    table_dataShow();
    formEdit_Show(false);
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::formEdit_Show(bool bEdit)
{
    //-- groupbox and tablewidge edit-type show ---
    ui->gbox_basetable->setEnabled(!bEdit);
    ui->gbox_basetable->setStyleSheet( !bEdit ? groupbox_style_enable : groupbox_style_disable);
    //-- edit_frame edit-type show ---
    ui->lb_titlename->setStyleSheet(!bEdit ? labeltitle_style_enable :labeltitle_style_enable)  ;
    ui->edit_frame->setEnabled(bEdit);
    ui->lb_table_edittype->setVisible(bEdit) ;   
    QString lineedit_name ;
    QString label_name ;
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    
    for(int i=0;i<_fiels_maxnum;i++){
        lineedit_name = "lineEdit_"+QString::number(i);
        label_name = "lb_field_"+QString::number(i);
        QLineEdit *obj_lEdit = ui->edit_frame->findChild<QLineEdit *>(lineedit_name);
        QLabel *obj_label = ui->edit_frame->findChild<QLabel *>(label_name);
        if(obj_lEdit && obj_label){
            //if(obj_lEdit->isVisible()){
            if(i<_fiels_num){    
                obj_label->setEnabled(bEdit);
                obj_lEdit->setEnabled(bEdit);
                obj_label->setStyleSheet(bEdit ? label_style_enable : label_style_disable );
                obj_lEdit->setStyleSheet(bEdit ? lineedit_style_enable : lineedit_style_disable );
            }
        }
    }    
    //-- can't edit show for edit and lineedit (fixed) ---
    formEdit_QtherShow(bEdit);
    //-- operating frame edit show ----    
    ui->op_frame->setVisible(!bEdit);
    ui->close_frame->setVisible(!bEdit);
    ui->choice_frame->setVisible(bEdit);
    ui->search_frame->setVisible(false);
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::edit_frame_dataShow()
{
    QString lineedit_name ; 
    int row = ui->tableWidget->currentItem()->row();     
    for(int i=0;i<_fiels_num;i++){
        lineedit_name = "lineEdit_"+QString::number(i);  
        QLineEdit *obj_lEdit = ui->edit_frame->findChild<QLineEdit *>(lineedit_name);
        if(obj_lEdit){
            obj_lEdit->setText(ui->tableWidget->item(row, i)->text());    
        }
    }       
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::edit_table_dataShow()
{
    QString lineedit_name ; 
    int row = ui->tableWidget->currentItem()->row();   
    ui->tableWidget->setSortingEnabled(false);  
    for(int i=0;i<_fiels_num;i++){
        lineedit_name = "lineEdit_"+QString::number(i);  
        QLineEdit *obj_lEdit = ui->edit_frame->findChild<QLineEdit *>(lineedit_name);
        if(obj_lEdit){
            ui->tableWidget->setItem(row,i,new QTableWidgetItem(obj_lEdit->text()));    
        }
    }       
    ui->tableWidget->setSortingEnabled(true);
}
//-----------------------------------------------------------------------------
int frmDB_baseTable::get_keyvalue_tablerow(int col_no,QString key_value)
{
    int iRet = -1 ;
    QList<QTableWidgetItem *> LTempTable =ui->tableWidget->findItems(key_value,Qt::MatchEndsWith);
    for(int i=0;i<LTempTable.count();i++){
        int row = LTempTable[i]->row();
        if(ui->tableWidget->item(row, col_no)->text()==key_value){
            iRet = row ; break;   
        }
    }
    return iRet ; 
} 
//-----------------------------------------------------------------------------
bool frmDB_baseTable::dbtable_move_next()
{
    int row = ui->tableWidget->currentRow();
    int count = ui->tableWidget->rowCount();
    bool bRet = (row < count) ;
    if(bRet){
        //ui->tableWidget->selectRow(row+1); 
        edit_frame_dataShow();       
    }

    return bRet ;
}
//-----------------------------------------------------------------------------
bool frmDB_baseTable::dbtable_move_previous()
{
    int row = ui->tableWidget->currentRow();
    bool bRet = (row >= 0) ;
    if(bRet){
        //ui->tableWidget->selectRow(row-1); 
        edit_frame_dataShow();       
    }

    return bRet ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  base conrtoller area   --- modify                                      **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmDB_baseTable::parse_config_basetable(ebasetable_type _type)
{
    parse_basetb_base();
    //------------------
    _basetable_type = _type ;
    switch(_basetable_type){
        case ebasetb_check_parameters:{
           parse_basetb_check_parameters() ;
        } break;
        case ebasetb_pid_ctrl_parameters:{
           parse_basetb_pid_ctrl_parameters() ;
        } break;
        case ebasetb_targer_pos2d_parameters:{
           parse_basetb_targer_pos2d_parameters() ;
        } break;
        case ebasetb_alarmcode_parameters:{
           parse_basetb_alarmcode_parameters() ;
        } break;
        case ebasetb_operatecode_parameters:{
           parse_basetb_operatecode_parameters() ;
        } break;
        case ebasetb_car_alarm_history:{
           parse_basetb_car_alarm_history() ;
        } break;
        case ebasetb_car_operate_history:{
           parse_basetb_car_operate_history() ;
        } break;
        case ebasetb_action_function_parameters:{
           parse_basetb_action_function_parameters() ;
        } break;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::table_dataShow()
{
    switch(_basetable_type){
        case ebasetb_check_parameters:{
           table_dataShow_check_parameters() ;
        } break;
        case ebasetb_pid_ctrl_parameters:{
           table_dataShow_pid_ctrl_parameters() ;
        } break;
        case ebasetb_targer_pos2d_parameters:{
           table_dataShow_targer_pos2d_parameters() ;
        } break;
        case ebasetb_alarmcode_parameters:{
           table_dataShow_alarmcode_parameters() ;
        } break;
        case ebasetb_operatecode_parameters:{
           table_dataShow_operatecode_parameters() ;
        } break;
        case ebasetb_car_alarm_history:{
           table_dataShow_car_alarm_history() ;
        } break;
        case ebasetb_car_operate_history:{
           table_dataShow_car_operate_history() ;
        } break;
        case ebasetb_action_function_parameters:{
           table_dataShow_action_function_parameters() ;
        } break;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::formEdit_QtherShow(bool bEdit)
{
    switch(_basetable_type){
        case ebasetb_check_parameters:{
           ui->lb_field_0->setEnabled(false) ; ui->lb_field_0->setStyleSheet(label_style_disable) ;
           ui->lineEdit_0->setEnabled(false) ; ui->lineEdit_0->setStyleSheet(lineedit_style_disable) ;
           ui->lb_field_5->setEnabled(false) ; ui->lb_field_5->setStyleSheet(label_style_disable) ;
           ui->lineEdit_5->setEnabled(false) ; ui->lineEdit_5->setStyleSheet(lineedit_style_disable) ;
        } break;
        case ebasetb_pid_ctrl_parameters:{
           ui->lb_field_0->setEnabled(false) ; ui->lb_field_0->setStyleSheet(label_style_disable) ;
           ui->lineEdit_0->setEnabled(false) ; ui->lineEdit_0->setStyleSheet(lineedit_style_disable) ;
           ui->lb_field_11->setEnabled(false) ; ui->lb_field_11->setStyleSheet(label_style_disable) ;
           ui->lineEdit_11->setEnabled(false) ; ui->lineEdit_11->setStyleSheet(lineedit_style_disable) ;
        } break;
        case ebasetb_targer_pos2d_parameters:{
           ui->lb_field_0->setEnabled(false) ; ui->lb_field_0->setStyleSheet(label_style_disable) ;
           ui->lineEdit_0->setEnabled(false) ; ui->lineEdit_0->setStyleSheet(lineedit_style_disable) ;
           ui->lb_field_7->setEnabled(false) ; ui->lb_field_7->setStyleSheet(label_style_disable) ;
           ui->lineEdit_7->setEnabled(false) ; ui->lineEdit_7->setStyleSheet(lineedit_style_disable) ;
        } break;
        case ebasetb_alarmcode_parameters:{
           ui->lb_field_0->setEnabled(false) ; ui->lb_field_0->setStyleSheet(label_style_disable) ;
           ui->lineEdit_0->setEnabled(false) ; ui->lineEdit_0->setStyleSheet(lineedit_style_disable) ;
           ui->lb_field_7->setEnabled(false) ; ui->lb_field_7->setStyleSheet(label_style_disable) ;
           ui->lineEdit_7->setEnabled(false) ; ui->lineEdit_7->setStyleSheet(lineedit_style_disable) ;
        } break;
        case ebasetb_operatecode_parameters:{
           ui->lb_field_0->setEnabled(false) ; ui->lb_field_0->setStyleSheet(label_style_disable) ;
           ui->lineEdit_0->setEnabled(false) ; ui->lineEdit_0->setStyleSheet(lineedit_style_disable) ;
           ui->lb_field_7->setEnabled(false) ; ui->lb_field_7->setStyleSheet(label_style_disable) ;
           ui->lineEdit_7->setEnabled(false) ; ui->lineEdit_7->setStyleSheet(lineedit_style_disable) ;
        } break;
        case ebasetb_car_alarm_history:{
           ui->lb_field_0->setEnabled(false) ; ui->lb_field_0->setStyleSheet(label_style_disable) ;
           ui->lineEdit_0->setEnabled(false) ; ui->lineEdit_0->setStyleSheet(lineedit_style_disable) ;
           ui->lb_field_5->setEnabled(false) ; ui->lb_field_5->setStyleSheet(label_style_disable) ;
           ui->lineEdit_5->setEnabled(false) ; ui->lineEdit_5->setStyleSheet(lineedit_style_disable) ;
        } break;
        case ebasetb_car_operate_history:{
           ui->lb_field_0->setEnabled(false) ; ui->lb_field_0->setStyleSheet(label_style_disable) ;
           ui->lineEdit_0->setEnabled(false) ; ui->lineEdit_0->setStyleSheet(lineedit_style_disable) ;
           ui->lb_field_5->setEnabled(false) ; ui->lb_field_5->setStyleSheet(label_style_disable) ;
           ui->lineEdit_5->setEnabled(false) ; ui->lineEdit_5->setStyleSheet(lineedit_style_disable) ;
        } break;
        case ebasetb_action_function_parameters:{
           ui->lb_field_0->setEnabled(false) ; ui->lb_field_0->setStyleSheet(label_style_disable) ;
           ui->lineEdit_0->setEnabled(false) ; ui->lineEdit_0->setStyleSheet(lineedit_style_disable) ;
           ui->lb_field_8->setEnabled(false) ; ui->lb_field_8->setStyleSheet(label_style_disable) ;
           ui->lineEdit_8->setEnabled(false) ; ui->lineEdit_8->setStyleSheet(lineedit_style_disable) ;
        } break;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::table_sorttype_show()
{
    //if(ui->cbox_sort_code->isVisible())
        ui->cbox_sort_code->setChecked(_table_sorttype == ebasetable_sort_code);
    //if(ui->cbox_sort_time->isVisible())
        ui->cbox_sort_time->setChecked(_table_sorttype == ebasetable_sort_update);
    //----------------------
    switch(_basetable_type){
        case ebasetb_check_parameters:{
            if(_table_sorttype == ebasetable_sort_code)
                ui->tableWidget->sortItems(1,Qt::AscendingOrder);
            else if(_table_sorttype == ebasetable_sort_update)
                ui->tableWidget->sortItems(5,Qt::AscendingOrder);    
        } break;
        case ebasetb_pid_ctrl_parameters:{
            if(_table_sorttype == ebasetable_sort_code)
                ui->tableWidget->sortItems(1,Qt::AscendingOrder);
            else if(_table_sorttype == ebasetable_sort_update)
                ui->tableWidget->sortItems(11,Qt::AscendingOrder);  
        } break;
        case ebasetb_targer_pos2d_parameters:{
            if(_table_sorttype == ebasetable_sort_code)
                ui->tableWidget->sortItems(1,Qt::AscendingOrder);
            else if(_table_sorttype == ebasetable_sort_update)
                ui->tableWidget->sortItems(7,Qt::AscendingOrder);  
        } break;
        case ebasetb_alarmcode_parameters:{
            if(_table_sorttype == ebasetable_sort_code)
                ui->tableWidget->sortItems(1,Qt::AscendingOrder);
            else if(_table_sorttype == ebasetable_sort_update)
                ui->tableWidget->sortItems(7,Qt::AscendingOrder);  
        } break;
        case ebasetb_operatecode_parameters:{
            if(_table_sorttype == ebasetable_sort_code)
                ui->tableWidget->sortItems(1,Qt::AscendingOrder);
            else if(_table_sorttype == ebasetable_sort_update)
                ui->tableWidget->sortItems(7,Qt::AscendingOrder);  
        } break;
        case ebasetb_car_alarm_history:{
            if(_table_sorttype == ebasetable_sort_code)
                ui->tableWidget->sortItems(1,Qt::AscendingOrder);
            else if(_table_sorttype == ebasetable_sort_update)
                ui->tableWidget->sortItems(5,Qt::AscendingOrder);  
        } break;
        case ebasetb_car_operate_history:{
            if(_table_sorttype == ebasetable_sort_code)
                ui->tableWidget->sortItems(1,Qt::AscendingOrder);
            else if(_table_sorttype == ebasetable_sort_update)
                ui->tableWidget->sortItems(5,Qt::AscendingOrder);  
        } break;
        case ebasetb_action_function_parameters:{
            if(_table_sorttype == ebasetable_sort_code)
                ui->tableWidget->sortItems(1,Qt::AscendingOrder);
            else if(_table_sorttype == ebasetable_sort_update)
                ui->tableWidget->sortItems(7,Qt::AscendingOrder);  
        } break;
    }    
}


//-----------------------------------------------------------------------------
//*****************************************************************************
//**  GUI Component : trigger .....  Fixed                                   **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmDB_baseTable::on_btn_close_clicked()
{
    emit _app_mode->frm_main_enable_Changed(true);
    close();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::on_btn_op_add_clicked()
{
    last_table_rowno = ui->tableWidget->currentRow(); 
    last_unique_code = ui->lineEdit_0->text();
    //----------------------
    _table_OP_type = db_table_OP_Add ;
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    QString type_name = ((lang_type == elanguage_type_TC) ? "新增" :
                         ((lang_type == elanguage_type_SC) ? "新增" : "Add"));
    ui->lb_table_edittype->setText(type_name);
    //-- add a blank record to tableWidge and refresh editfram data ---
    ui->tableWidget->setSortingEnabled(false);  

    int act_row = ui->tableWidget->rowCount()+1 ;
    ui->tableWidget->setRowCount(act_row);
    ui->tableWidget->selectRow(act_row-1);    
    
    for(int i=0;i<_fiels_num;i++){
            ui->tableWidget->setItem(act_row-1,i,new QTableWidgetItem(QString::fromStdString("")));   // (row,col) 
        }
    //ui->tableWidget->setSortingEnabled(true);    
    ui->tableWidget->setFocus();    
    //----------------------
    edit_frame_dataShow();
    //-------------     
    formEdit_Show(true);
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::on_btn_op_modify_clicked()
{
    last_table_rowno = ui->tableWidget->currentRow();  
    last_unique_code = ui->lineEdit_0->text();
    //----------------------
    _table_OP_type = db_table_OP_Modify ;
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    QString type_name = ((lang_type == elanguage_type_TC) ? "修改" :
                         ((lang_type == elanguage_type_SC) ? "修改" : "Modify"));
    ui->lb_table_edittype->setText(type_name);
    //-------------     
    formEdit_Show(true);
}


//-----------------------------------------------------------------------------
void frmDB_baseTable::on_btn_cancel_clicked()
{
    int actrow ;
    if(_table_OP_type == db_table_OP_Add){
        int row = ui->tableWidget->currentRow(); 
        ui->tableWidget->removeRow(row);//清除已有的行列
        int row_cnt = ui->tableWidget->rowCount();        
        if(row_cnt >0){
            ui->tableWidget->selectRow(last_table_rowno);
            ui->tableWidget->setFocus();                  
        }
        else{
            ui->tableWidget->setRowCount(1);  
            ui->tableWidget->selectRow(0);  
        }
    }    
    //----------------------- 
    action_unique_code = ui->lineEdit_0->text();    
    ui->tableWidget->setSortingEnabled(true);
    int act_row = get_keyvalue_tablerow(0,action_unique_code);
    if(act_row < 0){ 
        act_row = get_keyvalue_tablerow(0,last_unique_code);
        if(act_row < 0)
            act_row = 0 ;
    }
    
    ui->tableWidget->setFocus();
    //ui->tableWidget->selectRow(act_row);
    //-----------------------
    _table_OP_type = db_table_OP_None ;
    edit_frame_dataShow();
    formEdit_Show(false);
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::on_btn_op_delete_clicked()
{
    int row = ui->tableWidget->currentRow(); 
    QString _primary_id = ui->tableWidget->item(row,1)->text();
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    QString delete_msg = (lang_type == elanguage_type_TC)? "删除此筆資料\n(" :
                         ((lang_type == elanguage_type_SC)? "删除此笔资料\n(":"Delete this record\n(");
    delete_msg += ui->tableWidget->item(row,1)->text()+"/\n" + ui->tableWidget->item(row,0)->text()+") ?" ;

    bool bRet = tools->dialog_formShow(delete_msg,eConfirmStyle,tools->getlanguage_type());
    if(bRet){
        qt_generaltools* tools = qt_generaltools::getInstance();
        elanguage_type lang_type = tools->getlanguage_type();
        QString type_name = ((lang_type == elanguage_type_TC) ? "删除" :
                            ((lang_type == elanguage_type_SC) ? "删除" : "Delete"));
        ui->lb_table_edittype->setText(type_name);
        //---------------------------------
        last_table_rowno = ui->tableWidget->currentRow();  
        _table_OP_type = db_table_OP_Delete ;   
        //formEdit_Show(false); 
        formEdit_Show(true); 
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::on_tableWidget_clicked(const QModelIndex &index)
{
    if (index.isValid()) {     
        edit_frame_dataShow();     
    }   
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::on_btn_op_inquire_clicked()
{
    ui->search_frame->setVisible(true);
    ui->search_frame->raise();    
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::on_cbox_sort_code_clicked()
{
    last_unique_code = ui->lineEdit_0->text();
    //--------------    
    _table_sorttype = ebasetable_sort_code ;
    table_sorttype_show();
    //--------------
    int act_row = get_keyvalue_tablerow(0,last_unique_code);
    if(act_row < 0)        act_row = 0 ;
    ui->tableWidget->selectRow(act_row);
    ui->tableWidget->setFocus();
    //-----------------------
    edit_frame_dataShow();    
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::on_cbox_sort_time_clicked()
{
    last_unique_code = ui->lineEdit_0->text();
    //--------------    
    _table_sorttype = ebasetable_sort_update ;
    table_sorttype_show();
    //--------------
    int act_row = get_keyvalue_tablerow(0,last_unique_code);
    if(act_row < 0)        act_row = 0 ;
    ui->tableWidget->selectRow(act_row);
    ui->tableWidget->setFocus();
    //-----------------------
    edit_frame_dataShow();        
}
//-----------------------------------------------------------------------------
/*void frmDB_baseTable::on_tableWidget_pressed(const QModelIndex &index)
{
    if (index.isValid()) {     
        edit_frame_dataShow();     
    }       
}*/
//-----------------------------------------------------------------------------
void frmDB_baseTable::keyPressEvent(QKeyEvent *event)
{
    if(!ui->tableWidget->hasFocus()) return ; 
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::keyReleaseEvent(QKeyEvent *event)
{
    if(!ui->tableWidget->hasFocus()) return ;

    int row = ui->tableWidget->currentRow();    
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    if(event->key() == Qt::Key_Up)  
    {    
        edit_frame_dataShow();       
        if(row == 0){
            if(b_rowno_error_false){
                QString message = ((lang_type == elanguage_type_TC) ? "資料已是第一筆 ！" :
                                ((lang_type == elanguage_type_SC) ? "资料已是第一笔 !" : "It is already the first record !"));
                tools->dialog_formShow(message,eMessageStyle,lang_type);    
                b_rowno_error_false = false ;    
            }
            else  b_rowno_error_false = true ;            
        }  
        else  b_rowno_error_false = false ;                         
    }
    else if(event->key() == Qt::Key_Down)  
    {    
        edit_frame_dataShow();   
        int count = ui->tableWidget->rowCount();
        if(row == (count-1)){    
            if(b_rowno_error_false){   
                QString message = ((lang_type == elanguage_type_TC) ? "資料已是最後一筆 ！" :
                                ((lang_type == elanguage_type_SC) ? "资料已是最后一笔 !" : "It is already the last record !"));
                tools->dialog_formShow(message,eMessageStyle,lang_type); 
                b_rowno_error_false = false ;    
            }
            else  b_rowno_error_false = true ; 
        }
        else  b_rowno_error_false = false ;   
    }
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  GUI Component : trigger .....  modify                                  **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmDB_baseTable::on_btn_confirm_clicked()
{    
    //-- todo database table process ---
    db_tb_error_type _error_type = edb_tb_err_type_none ;
    if((_table_OP_type == db_table_OP_Add) || (_table_OP_type == db_table_OP_Modify)){    
        if(_basetable_type == ebasetb_check_parameters)
            update_procedure_check_parameters(_error_type);
        else if(_basetable_type == ebasetb_pid_ctrl_parameters)
            update_procedure_pid_ctrl_parameters(_error_type);
        else if(_basetable_type == ebasetb_targer_pos2d_parameters)
            update_procedure_targer_pos2d_parameters(_error_type);
        else if(_basetable_type == ebasetb_alarmcode_parameters)
            update_procedure_alarmcode_parameters(_error_type);
        else if(_basetable_type == ebasetb_operatecode_parameters)
            update_procedure_operatecode_parameters(_error_type);
        else if(_basetable_type == ebasetb_car_alarm_history)
            update_procedure_car_alarm_history(_error_type);
        else if(_basetable_type == ebasetb_car_operate_history)
            update_procedure_car_operate_history(_error_type);
        else if(_basetable_type == ebasetb_action_function_parameters)
            update_procedure_action_function_parameters(_error_type);
    }
    else if(_table_OP_type == db_table_OP_Delete){   
        if(_basetable_type == ebasetb_check_parameters)
            delete_procedure_check_parameters(_error_type);
        else if(_basetable_type == ebasetb_pid_ctrl_parameters)
            delete_procedure_pid_ctrl_parameters(_error_type);    
        else if(_basetable_type == ebasetb_targer_pos2d_parameters)
            delete_procedure_targer_pos2d_parameters(_error_type);   
        else if(_basetable_type == ebasetb_alarmcode_parameters)
            delete_procedure_alarmcode_parameters(_error_type);   
        else if(_basetable_type == ebasetb_operatecode_parameters)
            delete_procedure_operatecode_parameters(_error_type);  
        else if(_basetable_type == ebasetb_car_alarm_history)
            delete_procedure_car_alarm_history(_error_type);
        else if(_basetable_type == ebasetb_car_operate_history)
            delete_procedure_car_operate_history(_error_type);
        else if(_basetable_type == ebasetb_action_function_parameters)
            delete_procedure_action_function_parameters(_error_type);
    }
    if(_error_type != edb_tb_err_type_none){
        qt_generaltools* tools = qt_generaltools::getInstance();
        elanguage_type lang_type = tools->getlanguage_type();
        QString message = ((lang_type == elanguage_type_TC) ? "錯誤訊息：" :
                           ((lang_type == elanguage_type_SC) ? "错误讯息：" : "Error message :"));
        message += QString::fromStdString(_controlmodel->get_error_desc((int)lang_type,_error_type)) ;  
        tools->dialog_formShow(message,eMessageStyle,lang_type);    
        return ;
    }
    //------------------
    ui->btn_cancel->click();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::on_btn_search_confirm_clicked()
{
    if(ui->edit_search_from->text().isEmpty()){
        qt_generaltools* tools = qt_generaltools::getInstance();
        elanguage_type lang_type = tools->getlanguage_type();
        QString message = ((lang_type == elanguage_type_TC) ? "參數資料錯誤！" :
                           ((lang_type == elanguage_type_SC) ? "参数资料错误！" : "Parameters Error !"));

        tools->dialog_formShow(message,eMessageStyle,lang_type);    
        return ;
    }
    else{
        db_tb_error_type _error_type ;
        switch(_basetable_type){
            case ebasetb_check_parameters:{
                search_confirm_check_parameters(_error_type) ;
                } break;
            case ebasetb_pid_ctrl_parameters:{
                search_confirm_pid_ctrl_parameters(_error_type) ;
                } break;    
            case ebasetb_targer_pos2d_parameters:{
                search_confirm_targer_pos2d_parameters(_error_type) ;
                } break;
            case ebasetb_alarmcode_parameters:{
                search_confirm_alarmcode_parameters(_error_type) ;
                } break;
            case ebasetb_operatecode_parameters:{
                search_confirm_operatecode_parameters(_error_type) ;
                } break;
            case ebasetb_car_alarm_history:{
                search_confirm_car_alarm_history(_error_type) ;
                } break;
            case ebasetb_car_operate_history:{
                search_confirm_car_operate_history(_error_type) ;
                } break;
            case ebasetb_action_function_parameters:{
                search_confirm_action_function_parameters(_error_type) ;
                } break;
        }
        //----------------
        if(_error_type == edb_tb_err_type_none){
            switch(_basetable_type){
                case ebasetb_check_parameters:{
                    table_dataShow_check_parameters();
                    } break;
                case ebasetb_pid_ctrl_parameters:{
                    table_dataShow_pid_ctrl_parameters();
                    } break;    
                case ebasetb_targer_pos2d_parameters:{
                    table_dataShow_targer_pos2d_parameters();
                    } break;  
                case ebasetb_alarmcode_parameters:{
                    table_dataShow_alarmcode_parameters();
                    } break;  
                case ebasetb_operatecode_parameters:{
                    table_dataShow_operatecode_parameters();
                    } break; 
                case ebasetb_car_alarm_history:{
                    table_dataShow_car_alarm_history();
                    } break; 
                case ebasetb_car_operate_history:{
                    table_dataShow_car_operate_history();
                    } break;
                case ebasetb_action_function_parameters:{
                    table_dataShow_action_function_parameters();
                    } break;
            }
        }   
        else{
            qt_generaltools* tools = qt_generaltools::getInstance();
            elanguage_type lang_type = tools->getlanguage_type();
            QString message = ((lang_type == elanguage_type_TC) ? "參數資料錯誤！" :
                            ((lang_type == elanguage_type_SC) ? "参数资料错误！" : "Parameters Error !"));

            tools->dialog_formShow(message,eMessageStyle,lang_type);    
            return ;
        }
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::on_btn_search_cancel_clicked()
{
    db_tb_error_type _error_type ;
    switch(_basetable_type){
        case ebasetb_check_parameters:{
            search_cancel_check_parameters(_error_type) ;
            } break;
        case ebasetb_pid_ctrl_parameters:{
            search_cancel_pid_ctrl_parameters(_error_type) ;
            } break;
        case ebasetb_targer_pos2d_parameters:{
            search_cancel_targer_pos2d_parameters(_error_type) ;
            } break;
        case ebasetb_alarmcode_parameters:{
            search_cancel_alarmcode_parameters(_error_type) ;
            } break;
        case ebasetb_operatecode_parameters:{
            search_cancel_operatecode_parameters(_error_type) ;
            } break;
        case ebasetb_car_alarm_history:{
            search_cancel_car_alarm_history(_error_type) ;
            } break;
        case ebasetb_car_operate_history:{
            search_cancel_car_operate_history(_error_type) ;
            } break;
        case ebasetb_action_function_parameters:{
            search_cancel_action_function_parameters(_error_type) ;
            } break;
    }

    if(_error_type == edb_tb_err_type_none){
        switch(_basetable_type){
            case ebasetb_check_parameters:{
                table_dataShow_check_parameters();
                } break;
            case ebasetb_pid_ctrl_parameters:{
                table_dataShow_pid_ctrl_parameters();
                } break;   
            case ebasetb_targer_pos2d_parameters:{
                table_dataShow_targer_pos2d_parameters();
                } break;  
            case ebasetb_alarmcode_parameters:{
                table_dataShow_alarmcode_parameters();
                } break;  
            case ebasetb_operatecode_parameters:{
                table_dataShow_operatecode_parameters();
                } break;  
            case ebasetb_car_alarm_history:{
                table_dataShow_car_alarm_history();
                } break;  
            case ebasetb_car_operate_history:{
                table_dataShow_car_operate_history();
                } break; 
            case ebasetb_action_function_parameters:{
                table_dataShow_action_function_parameters();
                } break; 
        }
    }   
    //---------------------------
    ui->search_frame->setVisible(false);    
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  table function : check_parameters                                      **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmDB_baseTable::parse_basetb_check_parameters()
{
    vectors_clear();

    config_filename = QApplication::applicationDirPath()+"/config/config.cfg";
    QSettings config_set(config_filename,QSettings::IniFormat);
    config_set.setIniCodec("UTF-8");
    //-- table field number ----
    int field_num = config_set.value("check_parameters/field_num",-1).toInt();
    if(field_num == -1){
        config_set.setValue("check_parameters/field_num",6);
        field_num = config_set.value("check_parameters/field_num").toInt();
    }
    _fiels_num = field_num ;

    //-- groupbox title ----
    QString prefix_key = "check_parameters/tablelist";
    QString tag_value = "";
    QString tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "Action Recovery parameters manager list" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "錯誤回復參數管理 表列" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "错误回复参数管理 表列" ; }
        QString tablelist = config_set.value(tag_key,"").toString();
        if(tablelist.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablelist = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablelist); }
        else if(i==1){ _titlename_Vec_TC.append(tablelist); }
        else if(i==2){ _titlename_Vec_SC.append(tablelist); }

    }
    //-- tablename title ----
    prefix_key = "check_parameters/tablename";
    tag_value = "";
    tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "table name:check_parameters" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "資料表名稱:check_parameters" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "资料表名称:check_parameters" ; }
        QString tablename = config_set.value(tag_key,"").toString();
        if(tablename.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablename = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablename); }
        else if(i==1){ _titlename_Vec_TC.append(tablename); }
        else if(i==2){ _titlename_Vec_SC.append(tablename); }

    }
    //--- field title set ----
    QString key_value[3]={"","",""};

    for(int i=0;i<_fiels_num;i++){
        prefix_key = "check_parameters/fieldname_"+ QString::number(i);
        if(i==0){key_value[0]="primary_id";key_value[1]="主KEY值";key_value[2]="主KEY值";}
        else if(i==1){key_value[0]="Recovery_code";key_value[1]="錯誤回復碼";key_value[2]="错误回复码";}
        else if(i==2){key_value[0]="Recovery name";key_value[1]="錯誤回復名稱";key_value[2]="错误回复名称";}
        else if(i==3){key_value[0]="out_of_times";key_value[1]="回復次數";key_value[2]="回复次数";}
        else if(i==4){key_value[0]="timeout";key_value[1]="回復逾時時間";key_value[2]="回复逾时时间";}
        else if(i==5){key_value[0]="update_time";key_value[1]="異動時間";key_value[2]="异动时间";}

        for(int j=0;j<3;j++){
            if(j==0){ tag_key = prefix_key+"_E" ; tag_value = key_value[0];}
            else if(j==1){ tag_key = prefix_key+"_TC" ; tag_value = key_value[1];}
            else if(j==2){ tag_key = prefix_key+"_SC" ; tag_value = key_value[2];}

            QString fieldname = config_set.value(tag_key,"").toString();
            if(fieldname.isEmpty()){
                config_set.setValue(tag_key,tag_value);
                fieldname = config_set.value(tag_key).toString();
            }
            if(j==0){ _fieldname_Vec_E.append(fieldname); }
            else if(j==1){ _fieldname_Vec_TC.append(fieldname); }
            else if(j==2){ _fieldname_Vec_SC.append(fieldname); }
        }
    }    
    //--- sort_frame show -----------------------
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    ui->lb_sorttitle->setText((lang_type == elanguage_type_TC)? "排序欄位" :
                              ((lang_type == elanguage_type_SC)? "排序栏位":"Sort by"));
    ui->cbox_sort_code->setText((lang_type == elanguage_type_TC)? "錯誤回復碼" :
                              ((lang_type == elanguage_type_SC)? "错误回复码":"Recovery_code"));
    ui->cbox_sort_time->setText((lang_type == elanguage_type_TC)? "異動時間" :
                              ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    //--- Search field set ----------------------
    ui->cbox_search_condition->clear();
    QStringList strList;
    strList.append((lang_type == elanguage_type_TC)? "錯誤回復碼" :
                   ((lang_type == elanguage_type_SC)? "错误回复码":"Recovery_code"));
    strList.append((lang_type == elanguage_type_TC)? "主KEY值" :
                   ((lang_type == elanguage_type_SC)? "主KEY值":"primary_id"));    
    strList.append((lang_type == elanguage_type_TC)? "全部資料" :
                   ((lang_type == elanguage_type_SC)? "全部资料":"all data"));
    strList.append((lang_type == elanguage_type_TC)? "錯誤回復名稱" :
                   ((lang_type == elanguage_type_SC)? "错误回复名称":"Recovery name"));
    strList.append((lang_type == elanguage_type_TC)? "異動時間" :
                   ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    ui->cbox_search_condition->addItems(strList);
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::table_dataShow_check_parameters()
{
    ui->tableWidget->setSortingEnabled(false);
    //----------------------------
    vector<ptr_check_parameters> result = _controlmodel->get_check_parameters_results();
    int isize = result.size();
    ui->tableWidget->setSortingEnabled(false);
    if(isize == 0){
        ui->tableWidget->setRowCount(1) ; 
        for(int i=0;i<_fiels_num;i++){
            ui->tableWidget->setItem(0,i,new QTableWidgetItem(""));   // (row,col) 
        }
    }
    else{
        ui->tableWidget->setRowCount(isize) ; 
        for(int i=0;i<isize;i++){
            ui->tableWidget->setItem(i,0,new QTableWidgetItem(QString::fromStdString(result[i]->primary_id)));   // (row,col) 
            ui->tableWidget->setItem(i,1,new QTableWidgetItem(QString::fromStdString(result[i]->unique_code)));   // (row,col) 
            ui->tableWidget->setItem(i,2,new QTableWidgetItem(QString::fromStdString(result[i]->base_name)));   // (row,col) 
            ui->tableWidget->setItem(i,3,new QTableWidgetItem(QString::number(result[i]->out_of_times)));   // (row,col) 
            ui->tableWidget->setItem(i,4,new QTableWidgetItem(QString::number(result[i]->timeout,'d',2)));   // (row,col) 
            ui->tableWidget->setItem(i,5,new QTableWidgetItem(QString::fromStdString(result[i]->update_time)));   // (row,col) 
        }          
    }
    ui->tableWidget->setSortingEnabled(true);
    //-------------------------
    table_sorttype_show();
    //-- set currentItem is first item and show its detail data ---
    ui->tableWidget->selectRow(0);
    edit_frame_dataShow();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::update_procedure_check_parameters(db_tb_error_type &_error_type)
{ 
    ptr_check_parameters _data = boost::make_shared<type_check_parameters>();
    _data->primary_id = ui->lineEdit_0->text().toStdString();
    _data->unique_code = ui->lineEdit_1->text().toStdString();
    _data->base_name = ui->lineEdit_2->text().toStdString();
    _data->out_of_times = ui->lineEdit_3->text().toInt();
    _data->timeout = ui->lineEdit_4->text().toDouble();
    _data->update_time = ui->lineEdit_5->text().toStdString();

    db_tb_edit_type _edit_type = (_table_OP_type == db_table_OP_Add) ? edb_tb_edit_add : edb_tb_edit_modify ; 
    emit _controlmodel->check_parameters_update_Changed(_edit_type,_data);

    _error_type = _controlmodel->get_check_parameters_error_type();
    if(_error_type == edb_tb_err_type_none){
        std::string _primary_code,_updatetime ;
        _controlmodel->get_check_parameters_req_updated(_primary_code,_updatetime); 
        ui->lineEdit_0->setText(QString::fromStdString(_primary_code));
        ui->lineEdit_5->setText(QString::fromStdString(_updatetime));
        edit_table_dataShow();
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::delete_procedure_check_parameters(db_tb_error_type &_error_type)
{ 
    std::string delete_code =  ui->lineEdit_0->text().toStdString();
    emit _controlmodel->check_parameters_delete_Changed(delete_code) ;
    _error_type = _controlmodel->get_check_parameters_error_type();
    if(_error_type == edb_tb_err_type_none){
        int rowIndex = ui->tableWidget->currentRow();
        if (rowIndex != -1)
            ui->tableWidget->removeRow(rowIndex);
        int row = ui->tableWidget->rowCount();
        if((row-1) >= last_table_rowno)
            ui->tableWidget->selectRow(last_table_rowno);  
        else{
            ui->tableWidget->selectRow(row);  
        }  
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_confirm_check_parameters(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_check_parameters_search_type query_opt = edynamic_check_parameters_search_base_name;
    int _query = ui->cbox_search_condition->currentIndex();
    if(_query < 3){
        query_base = (db_tb_search_type) _query ;
    }
    else if(_query == 3){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_check_parameters_search_base_name;
    }
    else if(_query == 4){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_check_parameters_search_uptime;
    }

    std::string search_param = ui->edit_search_from->text().toStdString() ;
    search_param += ui->edit_search_to->text().isEmpty() ? "" :
                    ","+ ui->edit_search_to->text().toStdString();

    emit _controlmodel->check_parameters_query_Changed(query_base,query_opt,search_param);
    _error_type = _controlmodel->get_check_parameters_error_type();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_cancel_check_parameters(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_check_parameters_search_type query_opt = edynamic_check_parameters_search_base_name;
    std::string search_param = "search_all" ; 

    emit _controlmodel->check_parameters_query_Changed(query_base,query_opt,search_param);

    _error_type = _controlmodel->get_check_parameters_error_type();
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  table function : ebasetb_pid_ctrl_parameters                           **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmDB_baseTable::parse_basetb_pid_ctrl_parameters()
{
    vectors_clear();

    config_filename = QApplication::applicationDirPath()+"/config/config.cfg";
    QSettings config_set(config_filename,QSettings::IniFormat);
    config_set.setIniCodec("UTF-8");
    //-- table field number ----
    int field_num = config_set.value("pid_ctrl_parameters/field_num",-1).toInt();
    if(field_num == -1){
        config_set.setValue("pid_ctrl_parameters/field_num",12);
        field_num = config_set.value("pid_ctrl_parameters/field_num").toInt();
    }
    _fiels_num = field_num ;

    //-- groupbox title ----
    QString prefix_key = "pid_ctrl_parameters/tablelist";
    QString tag_value = "";
    QString tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "PID control parameter manager list" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "PID 控制參數管理 表列" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "PID 控制参数管理 表列" ; }
        QString tablelist = config_set.value(tag_key,"").toString();
        if(tablelist.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablelist = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablelist); }
        else if(i==1){ _titlename_Vec_TC.append(tablelist); }
        else if(i==2){ _titlename_Vec_SC.append(tablelist); }

    }
    //-- tablename title ----
    prefix_key = "pid_ctrl_parameters/tablename";
    tag_value = "";
    tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "table name:pid_ctrl_parameters" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "資料表名稱:pid_ctrl_parameters" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "资料表名称:pid_ctrl_parameters" ; }
        QString tablename = config_set.value(tag_key,"").toString();
        if(tablename.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablename = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablename); }
        else if(i==1){ _titlename_Vec_TC.append(tablename); }
        else if(i==2){ _titlename_Vec_SC.append(tablename); }

    }
    //--- field title set ----
    QString key_value[3]={"","",""};

    for(int i=0;i<_fiels_num;i++){
        prefix_key = "pid_ctrl_parameters/fieldname_"+ QString::number(i);
        if(i==0){key_value[0]="primary_id";key_value[1]="主KEY值";key_value[2]="主KEY值";}
        else if(i==1){key_value[0]="PID id";key_value[1]="PID 識別碼";key_value[2]="PID 识别码";}
        else if(i==2){key_value[0]="PID name";key_value[1]="PID 識別名稱";key_value[2]="PID 识别名称";}
        else if(i==3){key_value[0]="Target value";key_value[1]="目標值";key_value[2]="目标值";}
        else if(i==4){key_value[0]="tolerance";key_value[1]="容許誤差";key_value[2]="容许误差";}
        else if(i==5){key_value[0]="min_bound";key_value[1]="最小輸出極限";key_value[2]="最小输出极限";}
        else if(i==6){key_value[0]="max_bound";key_value[1]="最大輸出極限";key_value[2]="最大输出极限";}
        else if(i==7){key_value[0]="d_KP";key_value[1]="d_KP";key_value[2]="d_KP";}
        else if(i==8){key_value[0]="d_KI";key_value[1]="d_KI";key_value[2]="d_KI";}
        else if(i==9){key_value[0]="d_KD";key_value[1]="d_KD";key_value[2]="d_KD";}
        else if(i==10){key_value[0]="Dirction_reverse";key_value[1]="方向反向";key_value[2]="方向反向";}
        else if(i==11){key_value[0]="update_time";key_value[1]="異動時間";key_value[2]="异动时间";}

        for(int j=0;j<3;j++){
            if(j==0){ tag_key = prefix_key+"_E" ; tag_value = key_value[0];}
            else if(j==1){ tag_key = prefix_key+"_TC" ; tag_value = key_value[1];}
            else if(j==2){ tag_key = prefix_key+"_SC" ; tag_value = key_value[2];}

            QString fieldname = config_set.value(tag_key,"").toString();
            if(fieldname.isEmpty()){
                config_set.setValue(tag_key,tag_value);
                fieldname = config_set.value(tag_key).toString();
            }
            if(j==0){ _fieldname_Vec_E.append(fieldname); }
            else if(j==1){ _fieldname_Vec_TC.append(fieldname); }
            else if(j==2){ _fieldname_Vec_SC.append(fieldname); }
        }
    }    
    //--- sort_frame show -----------------------
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    ui->lb_sorttitle->setText((lang_type == elanguage_type_TC)? "排序欄位" :
                              ((lang_type == elanguage_type_SC)? "排序栏位":"Sort by"));
    ui->cbox_sort_code->setText((lang_type == elanguage_type_TC)? "PID 識別碼" :
                              ((lang_type == elanguage_type_SC)? "PID 识别码":"PID id"));
    ui->cbox_sort_time->setText((lang_type == elanguage_type_TC)? "異動時間" :
                              ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    //--- Search field set ----------------------
    ui->cbox_search_condition->clear();
    QStringList strList;
    strList.append((lang_type == elanguage_type_TC)? "PID 識別碼" :
                   ((lang_type == elanguage_type_SC)? "PID 识别码":"PID id"));
    strList.append((lang_type == elanguage_type_TC)? "主KEY值" :
                   ((lang_type == elanguage_type_SC)? "主KEY值":"primary_id"));    
    strList.append((lang_type == elanguage_type_TC)? "全部資料" :
                   ((lang_type == elanguage_type_SC)? "全部资料":"all data"));
    strList.append((lang_type == elanguage_type_TC)? "PID 識別名稱" :
                   ((lang_type == elanguage_type_SC)? "PID 识别名称":"PID name"));
    strList.append((lang_type == elanguage_type_TC)? "異動時間" :
                   ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    ui->cbox_search_condition->addItems(strList);
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::table_dataShow_pid_ctrl_parameters()
{
    ui->tableWidget->setSortingEnabled(false);
    //----------------------------
    vector<ptr_pid_ctrl_parameters> result = _controlmodel->get_pid_ctrl_parameters_results();
    int isize = result.size();
    ui->tableWidget->setSortingEnabled(false);
    if(isize == 0){
        ui->tableWidget->setRowCount(1) ; 
        for(int i=0;i<_fiels_num;i++){
            ui->tableWidget->setItem(0,i,new QTableWidgetItem(""));   // (row,col) 
        }
    }
    else{
        ui->tableWidget->setRowCount(isize) ; 
        for(int i=0;i<isize;i++){
            ui->tableWidget->setItem(i,0,new QTableWidgetItem(QString::fromStdString(result[i]->primary_id)));   // (row,col) 
            ui->tableWidget->setItem(i,1,new QTableWidgetItem(QString::fromStdString(result[i]->unique_code)));   // (row,col) 
            ui->tableWidget->setItem(i,2,new QTableWidgetItem(QString::fromStdString(result[i]->base_name)));   // (row,col) 
            ui->tableWidget->setItem(i,3,new QTableWidgetItem(QString::number(result[i]->target,'d',2)));   // (row,col) 
            ui->tableWidget->setItem(i,4,new QTableWidgetItem(QString::number(result[i]->tolerance,'d',2)));   // (row,col) 
            ui->tableWidget->setItem(i,5,new QTableWidgetItem(QString::number(result[i]->min_bound)));   // (row,col) 
            ui->tableWidget->setItem(i,6,new QTableWidgetItem(QString::number(result[i]->max_bound,'d',2)));   // (row,col) 
            ui->tableWidget->setItem(i,7,new QTableWidgetItem(QString::number(result[i]->d_KP,'d',8)));   // (row,col) 
            //ui->tableWidget->setItem(i,7,new QTableWidgetItem(QString::number(result[i]->d_KP,'d')));   // (row,col) 
            ui->tableWidget->setItem(i,8,new QTableWidgetItem(QString::number(result[i]->d_KI,'d',8)));   // (row,col) 
            ui->tableWidget->setItem(i,9,new QTableWidgetItem(QString::number(result[i]->d_KD,'d',8)));   // (row,col) 
            ui->tableWidget->setItem(i,10,new QTableWidgetItem(QString::number(result[i]->b_compensation)));   // (row,col) 
            ui->tableWidget->setItem(i,11,new QTableWidgetItem(QString::fromStdString(result[i]->update_time)));   // (row,col) 
        }          
    }
    ui->tableWidget->setSortingEnabled(true);
    //-------------------------
    table_sorttype_show();
    //-- set currentItem is first item and show its detail data ---
    ui->tableWidget->selectRow(0);
    edit_frame_dataShow();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::update_procedure_pid_ctrl_parameters(db_tb_error_type &_error_type)
{ 
    ptr_pid_ctrl_parameters _data = boost::make_shared<type_pid_ctrl_parameters>();
    _data->primary_id = ui->lineEdit_0->text().toStdString();
    _data->unique_code = ui->lineEdit_1->text().toStdString();
    _data->base_name = ui->lineEdit_2->text().toStdString();
    _data->target = ui->lineEdit_3->text().toDouble();
    _data->tolerance = ui->lineEdit_4->text().toDouble();
    _data->min_bound = ui->lineEdit_5->text().toDouble();
    _data->max_bound = ui->lineEdit_6->text().toDouble();
    _data->d_KP = ui->lineEdit_7->text().toDouble();
    _data->d_KI = ui->lineEdit_8->text().toDouble();
    _data->d_KD = ui->lineEdit_9->text().toDouble();
    _data->b_compensation = (bool)ui->lineEdit_10->text().toInt();
    _data->update_time = ui->lineEdit_11->text().toStdString();

    db_tb_edit_type _edit_type = (_table_OP_type == db_table_OP_Add) ? edb_tb_edit_add : edb_tb_edit_modify ; 
    emit _controlmodel->pid_ctrl_parameters_update_Changed(_edit_type,_data);

    _error_type = _controlmodel->get_pid_ctrl_parameters_error_type();
    if(_error_type == edb_tb_err_type_none){
        std::string _primary_code,_updatetime ;
        _controlmodel->get_pid_ctrl_parameters_req_updated(_primary_code,_updatetime); 
        ui->lineEdit_0->setText(QString::fromStdString(_primary_code));
        ui->lineEdit_11->setText(QString::fromStdString(_updatetime));
        edit_table_dataShow();
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::delete_procedure_pid_ctrl_parameters(db_tb_error_type &_error_type)
{ 
    std::string delete_code =  ui->lineEdit_0->text().toStdString();        // primary key
    emit _controlmodel->pid_ctrl_parameters_delete_Changed(delete_code) ;
    _error_type = _controlmodel->get_pid_ctrl_parameters_error_type();
    if(_error_type == edb_tb_err_type_none){
        int rowIndex = ui->tableWidget->currentRow();
        if (rowIndex != -1)
            ui->tableWidget->removeRow(rowIndex);
        int row = ui->tableWidget->rowCount();
        if((row-1) >= last_table_rowno)
            ui->tableWidget->selectRow(last_table_rowno);  
        else{
            ui->tableWidget->selectRow(row);  
        }  
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_confirm_pid_ctrl_parameters(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_pid_ctrl_parameters_search_type query_opt = edynamic_pid_ctrl_parameters_search_base_name;
    int _query = ui->cbox_search_condition->currentIndex();
    if(_query < 3){
        query_base = (db_tb_search_type) _query ;
    }
    else if(_query == 3){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_pid_ctrl_parameters_search_base_name;
    }
    else if(_query == 4){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_pid_ctrl_parameters_search_uptime;
    }

    std::string search_param = ui->edit_search_from->text().toStdString() ;
    search_param += ui->edit_search_to->text().isEmpty() ? "" :
                    ","+ ui->edit_search_to->text().toStdString();

    emit _controlmodel->pid_ctrl_parameters_query_Changed(query_base,query_opt,search_param);
    _error_type = _controlmodel->get_pid_ctrl_parameters_error_type();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_cancel_pid_ctrl_parameters(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_pid_ctrl_parameters_search_type query_opt = edynamic_pid_ctrl_parameters_search_base_name;
    std::string search_param = "search_all" ; 

    emit _controlmodel->pid_ctrl_parameters_query_Changed(query_base,query_opt,search_param);

    _error_type = _controlmodel->get_pid_ctrl_parameters_error_type();
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  table function : ebasetb_targer_pos2d_parameters                       **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmDB_baseTable::parse_basetb_targer_pos2d_parameters()
{
    vectors_clear();

    config_filename = QApplication::applicationDirPath()+"/config/config.cfg";
    QSettings config_set(config_filename,QSettings::IniFormat);
    config_set.setIniCodec("UTF-8");
    //-- table field number ----
    int field_num = config_set.value("targer_pos2d_parameters/field_num",-1).toInt();
    if(field_num == -1){
        config_set.setValue("targer_pos2d_parameters/field_num",8);
        field_num = config_set.value("targer_pos2d_parameters/field_num").toInt();
    }
    _fiels_num = field_num ;

    //-- groupbox title ----
    QString prefix_key = "targer_pos2d_parameters/tablelist";
    QString tag_value = "";
    QString tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "Target pose parameters manager list" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "目標位姿參數管理 表列" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "目标位姿参数管理 表列" ; }
        QString tablelist = config_set.value(tag_key,"").toString();
        if(tablelist.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablelist = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablelist); }
        else if(i==1){ _titlename_Vec_TC.append(tablelist); }
        else if(i==2){ _titlename_Vec_SC.append(tablelist); }

    }
    //-- tablename title ----
    prefix_key = "targer_pos2d_parameters/tablename";
    tag_value = "";
    tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "table name:targer_pos2d_parameters" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "資料表名稱:targer_pos2d_parameters" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "资料表名称:targer_pos2d_parameters" ; }
        QString tablename = config_set.value(tag_key,"").toString();
        if(tablename.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablename = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablename); }
        else if(i==1){ _titlename_Vec_TC.append(tablename); }
        else if(i==2){ _titlename_Vec_SC.append(tablename); }

    }
    //--- field title set ----
    QString key_value[3]={"","",""};

    for(int i=0;i<_fiels_num;i++){
        prefix_key = "targer_pos2d_parameters/fieldname_"+ QString::number(i);
        if(i==0){key_value[0]="primary_id";key_value[1]="主KEY值";key_value[2]="主KEY值";}
        else if(i==1){key_value[0]="Pose id";key_value[1]="位姿識別碼";key_value[2]="位姿识别码";}
        else if(i==2){key_value[0]="Pose name";key_value[1]="位姿識別名稱";key_value[2]="位姿识别名称";}
        else if(i==3){key_value[0]="Pose_x";key_value[1]="座標位置_x";key_value[2]="座标位置_x";}
        else if(i==4){key_value[0]="Pose_y";key_value[1]="座標位置_y";key_value[2]="座标位置_y";}
        else if(i==5){key_value[0]="Pose_theta";key_value[1]="旋轉角度";key_value[2]="旋转角度";}
        else if(i==6){key_value[0]="Rotate Flag";key_value[1]="旋轉旗標";key_value[2]="旋转旗标";}
        else if(i==7){key_value[0]="update_time";key_value[1]="異動時間";key_value[2]="异动时间";}

        for(int j=0;j<3;j++){
            if(j==0){ tag_key = prefix_key+"_E" ; tag_value = key_value[0];}
            else if(j==1){ tag_key = prefix_key+"_TC" ; tag_value = key_value[1];}
            else if(j==2){ tag_key = prefix_key+"_SC" ; tag_value = key_value[2];}

            QString fieldname = config_set.value(tag_key,"").toString();
            if(fieldname.isEmpty()){
                config_set.setValue(tag_key,tag_value);
                fieldname = config_set.value(tag_key).toString();
            }
            if(j==0){ _fieldname_Vec_E.append(fieldname); }
            else if(j==1){ _fieldname_Vec_TC.append(fieldname); }
            else if(j==2){ _fieldname_Vec_SC.append(fieldname); }
        }
    }    
    //--- sort_frame show -----------------------
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    ui->lb_sorttitle->setText((lang_type == elanguage_type_TC)? "排序欄位" :
                              ((lang_type == elanguage_type_SC)? "排序栏位":"Sort by"));
    ui->cbox_sort_code->setText((lang_type == elanguage_type_TC)? "PID 識別碼" :
                              ((lang_type == elanguage_type_SC)? "PID 识别码":"PID id"));
    ui->cbox_sort_time->setText((lang_type == elanguage_type_TC)? "異動時間" :
                              ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    //--- Search field set ----------------------
    ui->cbox_search_condition->clear();
    QStringList strList;
    strList.append((lang_type == elanguage_type_TC)? "位姿識別碼" :
                   ((lang_type == elanguage_type_SC)? "位姿识别码":"Pose id"));
    strList.append((lang_type == elanguage_type_TC)? "主KEY值" :
                   ((lang_type == elanguage_type_SC)? "主KEY值":"primary_id"));    
    strList.append((lang_type == elanguage_type_TC)? "全部資料" :
                   ((lang_type == elanguage_type_SC)? "全部资料":"all data"));
    strList.append((lang_type == elanguage_type_TC)? "位姿識別名稱" :
                   ((lang_type == elanguage_type_SC)? "位姿识别名称":"Pose name"));
    strList.append((lang_type == elanguage_type_TC)? "異動時間" :
                   ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    ui->cbox_search_condition->addItems(strList);
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::table_dataShow_targer_pos2d_parameters()
{
    ui->tableWidget->setSortingEnabled(false);
    //----------------------------
    vector<ptr_targer_pos2d_parameters> result = _controlmodel->get_targer_pos2d_parameters_results();
    int isize = result.size();
    ui->tableWidget->setSortingEnabled(false);
    if(isize == 0){
        ui->tableWidget->setRowCount(1) ; 
        for(int i=0;i<_fiels_num;i++){
            ui->tableWidget->setItem(0,i,new QTableWidgetItem(""));   // (row,col) 
        }
    }
    else{
        ui->tableWidget->setRowCount(isize) ; 
        for(int i=0;i<isize;i++){
            ui->tableWidget->setItem(i,0,new QTableWidgetItem(QString::fromStdString(result[i]->primary_id)));   // (row,col) 
            ui->tableWidget->setItem(i,1,new QTableWidgetItem(QString::fromStdString(result[i]->unique_code)));   // (row,col) 
            ui->tableWidget->setItem(i,2,new QTableWidgetItem(QString::fromStdString(result[i]->base_name)));   // (row,col) 
            ui->tableWidget->setItem(i,3,new QTableWidgetItem(QString::number(result[i]->pos_x,'d',2)));   // (row,col) 
            ui->tableWidget->setItem(i,4,new QTableWidgetItem(QString::number(result[i]->pos_y,'d',2)));   // (row,col) 
            ui->tableWidget->setItem(i,5,new QTableWidgetItem(QString::number(result[i]->theta)));   // (row,col) 
            ui->tableWidget->setItem(i,6,new QTableWidgetItem(QString::number(result[i]->rotate_flag)));   // (row,col) 
            ui->tableWidget->setItem(i,7,new QTableWidgetItem(QString::fromStdString(result[i]->update_time)));   // (row,col) 
        }          
    }
    ui->tableWidget->setSortingEnabled(true);
    //-------------------------
    table_sorttype_show();
    //-- set currentItem is first item and show its detail data ---
    ui->tableWidget->selectRow(0);
    edit_frame_dataShow();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::update_procedure_targer_pos2d_parameters(db_tb_error_type &_error_type)
{ 
    ptr_targer_pos2d_parameters _data = boost::make_shared<type_targer_pos2d_parameters>();
    _data->primary_id = ui->lineEdit_0->text().toStdString();
    _data->unique_code = ui->lineEdit_1->text().toStdString();
    _data->base_name = ui->lineEdit_2->text().toStdString();
    _data->pos_x = ui->lineEdit_3->text().toDouble();
    _data->pos_y = ui->lineEdit_4->text().toDouble();
    _data->theta = ui->lineEdit_5->text().toDouble();
    _data->rotate_flag = (bool)ui->lineEdit_6->text().toInt();
    _data->update_time = ui->lineEdit_7->text().toStdString();

    db_tb_edit_type _edit_type = (_table_OP_type == db_table_OP_Add) ? edb_tb_edit_add : edb_tb_edit_modify ; 
    emit _controlmodel->targer_pos2d_parameters_update_Changed(_edit_type,_data);

    _error_type = _controlmodel->get_targer_pos2d_parameters_error_type();
    if(_error_type == edb_tb_err_type_none){
        std::string _primary_code,_updatetime ;
        _controlmodel->get_targer_pos2d_parameters_req_updated(_primary_code,_updatetime); 
        ui->lineEdit_0->setText(QString::fromStdString(_primary_code));
        ui->lineEdit_7->setText(QString::fromStdString(_updatetime));
        edit_table_dataShow();
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::delete_procedure_targer_pos2d_parameters(db_tb_error_type &_error_type)
{ 
    std::string delete_code =  ui->lineEdit_0->text().toStdString();    // primary key
    emit _controlmodel->targer_pos2d_parameters_delete_Changed(delete_code) ;
    _error_type = _controlmodel->get_targer_pos2d_parameters_error_type();
    if(_error_type == edb_tb_err_type_none){
        int rowIndex = ui->tableWidget->currentRow();
        if (rowIndex != -1)
            ui->tableWidget->removeRow(rowIndex);
        int row = ui->tableWidget->rowCount();
        if((row-1) >= last_table_rowno)
            ui->tableWidget->selectRow(last_table_rowno);  
        else{
            ui->tableWidget->selectRow(row);  
        }  
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_confirm_targer_pos2d_parameters(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_targer_pos2d_parameters_search_type query_opt = edynamic_targer_pos2d_parameters_search_base_name;
    int _query = ui->cbox_search_condition->currentIndex();
    if(_query < 3){
        query_base = (db_tb_search_type) _query ;
    }
    else if(_query == 3){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_targer_pos2d_parameters_search_base_name;
    }
    else if(_query == 4){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_targer_pos2d_parameters_search_uptime;
    }

    std::string search_param = ui->edit_search_from->text().toStdString() ;
    search_param += ui->edit_search_to->text().isEmpty() ? "" :
                    ","+ ui->edit_search_to->text().toStdString();

    emit _controlmodel->targer_pos2d_parameters_query_Changed(query_base,query_opt,search_param);
    _error_type = _controlmodel->get_targer_pos2d_parameters_error_type();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_cancel_targer_pos2d_parameters(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_targer_pos2d_parameters_search_type query_opt = edynamic_targer_pos2d_parameters_search_base_name;
    std::string search_param = "search_all" ; 

    emit _controlmodel->targer_pos2d_parameters_query_Changed(query_base,query_opt,search_param);

    _error_type = _controlmodel->get_targer_pos2d_parameters_error_type();
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  table function : ebasetb_alarmcode_parameters                          **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmDB_baseTable::parse_basetb_alarmcode_parameters()
{
    vectors_clear();

    config_filename = QApplication::applicationDirPath()+"/config/config.cfg";
    QSettings config_set(config_filename,QSettings::IniFormat);
    config_set.setIniCodec("UTF-8");
    //-- table field number ----
    int field_num = config_set.value("alarmcode_parameters/field_num",-1).toInt();
    if(field_num == -1){
        config_set.setValue("alarmcode_parameters/field_num",8);
        field_num = config_set.value("alarmcode_parameters/field_num").toInt();
    }
    _fiels_num = field_num ;

    //-- groupbox title ----
    QString prefix_key = "alarmcode_parameters/tablelist";
    QString tag_value = "";
    QString tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "Alarm code parameters manager list" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "警報編碼管理 表列" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "警报编码管理 表列" ; }
        QString tablelist = config_set.value(tag_key,"").toString();
        if(tablelist.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablelist = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablelist); }
        else if(i==1){ _titlename_Vec_TC.append(tablelist); }
        else if(i==2){ _titlename_Vec_SC.append(tablelist); }

    }
    //-- tablename title ----
    prefix_key = "alarmcode_parameters/tablename";
    tag_value = "";
    tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "table name:alarmcode_parameters" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "資料表名稱:alarmcode_parameters" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "资料表名称:alarmcode_parameters" ; }
        QString tablename = config_set.value(tag_key,"").toString();
        if(tablename.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablename = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablename); }
        else if(i==1){ _titlename_Vec_TC.append(tablename); }
        else if(i==2){ _titlename_Vec_SC.append(tablename); }

    }
    //--- field title set ----
    QString key_value[3]={"","",""};

    for(int i=0;i<_fiels_num;i++){
        prefix_key = "alarmcode_parameters/fieldname_"+ QString::number(i);
        if(i==0){key_value[0]="primary_id";key_value[1]="主KEY值";key_value[2]="主KEY值";}
        else if(i==1){key_value[0]="Alarm id";key_value[1]="警報識別碼";key_value[2]="警报识别码";}
        else if(i==2){key_value[0]="Alarm Code";key_value[1]="警報編號";key_value[2]="警报编号";}
        else if(i==3){key_value[0]="Alarm level";key_value[1]="警報等級";key_value[2]="警报等级";}
        else if(i==4){key_value[0]="Description_Eng";key_value[1]="英文說明";key_value[2]="英文说明";}
        else if(i==5){key_value[0]="Description_TC";key_value[1]="繁體中文說明";key_value[2]="繁体中文说明";}
        else if(i==6){key_value[0]="Description_SC";key_value[1]="簡體中文說明";key_value[2]="简体中文说明";}
        else if(i==7){key_value[0]="update_time";key_value[1]="異動時間";key_value[2]="异动时间";}

        for(int j=0;j<3;j++){
            if(j==0){ tag_key = prefix_key+"_E" ; tag_value = key_value[0];}
            else if(j==1){ tag_key = prefix_key+"_TC" ; tag_value = key_value[1];}
            else if(j==2){ tag_key = prefix_key+"_SC" ; tag_value = key_value[2];}

            QString fieldname = config_set.value(tag_key,"").toString();
            if(fieldname.isEmpty()){
                config_set.setValue(tag_key,tag_value);
                fieldname = config_set.value(tag_key).toString();
            }
            if(j==0){ _fieldname_Vec_E.append(fieldname); }
            else if(j==1){ _fieldname_Vec_TC.append(fieldname); }
            else if(j==2){ _fieldname_Vec_SC.append(fieldname); }
        }
    }    
    //--- sort_frame show -----------------------
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    ui->lb_sorttitle->setText((lang_type == elanguage_type_TC)? "排序欄位" :
                              ((lang_type == elanguage_type_SC)? "排序栏位":"Sort by"));
    ui->cbox_sort_code->setText((lang_type == elanguage_type_TC)? "警報識別碼" :
                              ((lang_type == elanguage_type_SC)? "警报识别码":"Alarm id"));
    ui->cbox_sort_time->setText((lang_type == elanguage_type_TC)? "異動時間" :
                              ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    //--- Search field set ----------------------
    ui->cbox_search_condition->clear();
    QStringList strList;
    strList.append((lang_type == elanguage_type_TC)? "警報識別碼" :
                   ((lang_type == elanguage_type_SC)? "警报识别码":"Alarm id"));
    strList.append((lang_type == elanguage_type_TC)? "主KEY值" :
                   ((lang_type == elanguage_type_SC)? "主KEY值":"primary_id"));    
    strList.append((lang_type == elanguage_type_TC)? "全部資料" :
                   ((lang_type == elanguage_type_SC)? "全部资料":"all data"));
    strList.append((lang_type == elanguage_type_TC)? "警報編號" :
                   ((lang_type == elanguage_type_SC)? "警报编号":"Alarm level"));
    strList.append((lang_type == elanguage_type_TC)? "異動時間" :
                   ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    ui->cbox_search_condition->addItems(strList);
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::table_dataShow_alarmcode_parameters()
{
    ui->tableWidget->setSortingEnabled(false);
    //----------------------------
    vector<ptr_alarmcode_parameters> result = _controlmodel->get_alarmcode_parameters_results();
    int isize = result.size();
    ui->tableWidget->setSortingEnabled(false);
    if(isize == 0){
        ui->tableWidget->setRowCount(1) ; 
        for(int i=0;i<_fiels_num;i++){
            ui->tableWidget->setItem(0,i,new QTableWidgetItem(""));   // (row,col) 
        }
    }
    else{
        ui->tableWidget->setRowCount(isize) ; 
        for(int i=0;i<isize;i++){
            ui->tableWidget->setItem(i,0,new QTableWidgetItem(QString::fromStdString(result[i]->primary_id)));   // (row,col) 
            ui->tableWidget->setItem(i,1,new QTableWidgetItem(QString::fromStdString(result[i]->unique_code)));   // (row,col) 
            ui->tableWidget->setItem(i,2,new QTableWidgetItem(QString::fromStdString(result[i]->base_name)));   // (row,col) 
            ui->tableWidget->setItem(i,3,new QTableWidgetItem(QString::number(result[i]->alarm_level)));   // (row,col) 
            ui->tableWidget->setItem(i,4,new QTableWidgetItem(QString::fromStdString(result[i]->alarm_desc_eng)));   // (row,col) 
            ui->tableWidget->setItem(i,5,new QTableWidgetItem(QString::fromStdString(result[i]->alarm_desc_tc)));   // (row,col) 
            ui->tableWidget->setItem(i,6,new QTableWidgetItem(QString::fromStdString(result[i]->alarm_desc_sc)));   // (row,col) 
            ui->tableWidget->setItem(i,7,new QTableWidgetItem(QString::fromStdString(result[i]->update_time)));   // (row,col) 
        }          
    }
    ui->tableWidget->setSortingEnabled(true);
    //-------------------------
    table_sorttype_show();
    //-- set currentItem is first item and show its detail data ---
    ui->tableWidget->selectRow(0);
    edit_frame_dataShow();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::update_procedure_alarmcode_parameters(db_tb_error_type &_error_type)
{ 
    ptr_alarmcode_parameters _data = boost::make_shared<type_alarmcode_parameters>();
    _data->primary_id = ui->lineEdit_0->text().toStdString();
    _data->unique_code = ui->lineEdit_1->text().toStdString();
    _data->base_name = ui->lineEdit_2->text().toStdString();
    _data->alarm_level = ui->lineEdit_3->text().toInt();
    _data->alarm_desc_eng = ui->lineEdit_4->text().toStdString();
    _data->alarm_desc_tc = ui->lineEdit_5->text().toStdString();
    _data->alarm_desc_sc = (bool)ui->lineEdit_6->text().toInt();
    _data->update_time = ui->lineEdit_7->text().toStdString();

    db_tb_edit_type _edit_type = (_table_OP_type == db_table_OP_Add) ? edb_tb_edit_add : edb_tb_edit_modify ; 
    emit _controlmodel->alarmcode_parameters_update_Changed(_edit_type,_data);

    _error_type = _controlmodel->get_alarmcode_parameters_error_type();
    if(_error_type == edb_tb_err_type_none){
        std::string _primary_code,_updatetime ;
        _controlmodel->get_alarmcode_parameters_req_updated(_primary_code,_updatetime); 
        ui->lineEdit_0->setText(QString::fromStdString(_primary_code));
        ui->lineEdit_7->setText(QString::fromStdString(_updatetime));
        edit_table_dataShow();
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::delete_procedure_alarmcode_parameters(db_tb_error_type &_error_type)
{ 
    std::string delete_code =  ui->lineEdit_0->text().toStdString();    // primary key
    emit _controlmodel->alarmcode_parameters_delete_Changed(delete_code) ;
    _error_type = _controlmodel->get_alarmcode_parameters_error_type();
    if(_error_type == edb_tb_err_type_none){
        int rowIndex = ui->tableWidget->currentRow();
        if (rowIndex != -1)
            ui->tableWidget->removeRow(rowIndex);
        int row = ui->tableWidget->rowCount();
        if((row-1) >= last_table_rowno)
            ui->tableWidget->selectRow(last_table_rowno);  
        else{
            ui->tableWidget->selectRow(row);  
        }  
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_confirm_alarmcode_parameters(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_alarmcode_parameters_search_type query_opt = edynamic_alarmcode_parameters_search_base_name;
    int _query = ui->cbox_search_condition->currentIndex();
    if(_query < 3){
        query_base = (db_tb_search_type) _query ;
    }
    else if(_query == 3){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_alarmcode_parameters_search_base_name;
    }
    else if(_query == 4){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_alarmcode_parameters_search_uptime;
    }

    std::string search_param = ui->edit_search_from->text().toStdString() ;
    search_param += ui->edit_search_to->text().isEmpty() ? "" :
                    ","+ ui->edit_search_to->text().toStdString();

    emit _controlmodel->alarmcode_parameters_query_Changed(query_base,query_opt,search_param);
    _error_type = _controlmodel->get_alarmcode_parameters_error_type();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_cancel_alarmcode_parameters(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_alarmcode_parameters_search_type query_opt = edynamic_alarmcode_parameters_search_base_name;
    std::string search_param = "search_all" ; 

    emit _controlmodel->alarmcode_parameters_query_Changed(query_base,query_opt,search_param);

    _error_type = _controlmodel->get_alarmcode_parameters_error_type();
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  table function : ebasetb_operatecode_parameters                       **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmDB_baseTable::parse_basetb_operatecode_parameters()
{
    vectors_clear();

    config_filename = QApplication::applicationDirPath()+"/config/config.cfg";
    QSettings config_set(config_filename,QSettings::IniFormat);
    config_set.setIniCodec("UTF-8");
    //-- table field number ----
    int field_num = config_set.value("operatecode_parameters/field_num",-1).toInt();
    if(field_num == -1){
        config_set.setValue("operatecode_parameters/field_num",8);
        field_num = config_set.value("operatecode_parameters/field_num").toInt();
    }
    _fiels_num = field_num ;

    //-- groupbox title ----
    QString prefix_key = "operatecode_parameters/tablelist";
    QString tag_value = "";
    QString tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "Operate code parameters manager list" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "操作編碼管理 表列" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "操作编码管理 表列" ; }
        QString tablelist = config_set.value(tag_key,"").toString();
        if(tablelist.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablelist = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablelist); }
        else if(i==1){ _titlename_Vec_TC.append(tablelist); }
        else if(i==2){ _titlename_Vec_SC.append(tablelist); }

    }
    //-- tablename title ----
    prefix_key = "operatecode_parameters/tablename";
    tag_value = "";
    tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "table name:operatecode_parameters" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "資料表名稱:operatecode_parameters" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "资料表名称:operatecode_parameters" ; }
        QString tablename = config_set.value(tag_key,"").toString();
        if(tablename.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablename = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablename); }
        else if(i==1){ _titlename_Vec_TC.append(tablename); }
        else if(i==2){ _titlename_Vec_SC.append(tablename); }

    }
    //--- field title set ----
    QString key_value[3]={"","",""};

    for(int i=0;i<_fiels_num;i++){
        prefix_key = "operatecode_parameters/fieldname_"+ QString::number(i);
        if(i==0){key_value[0]="primary_id";key_value[1]="主KEY值";key_value[2]="主KEY值";}
        else if(i==1){key_value[0]="Operate id";key_value[1]="操作識別碼";key_value[2]="操作识别码";}
        else if(i==2){key_value[0]="Operate Code";key_value[1]="操作編號";key_value[2]="操作编号";}
        else if(i==3){key_value[0]="Operate level";key_value[1]="操作等級";key_value[2]="操作等级";}
        else if(i==4){key_value[0]="Description_Eng";key_value[1]="英文說明";key_value[2]="英文说明";}
        else if(i==5){key_value[0]="Description_TC";key_value[1]="繁體中文說明";key_value[2]="繁体中文说明";}
        else if(i==6){key_value[0]="Description_SC";key_value[1]="簡體中文說明";key_value[2]="简体中文说明";}
        else if(i==7){key_value[0]="update_time";key_value[1]="異動時間";key_value[2]="异动时间";}

        for(int j=0;j<3;j++){
            if(j==0){ tag_key = prefix_key+"_E" ; tag_value = key_value[0];}
            else if(j==1){ tag_key = prefix_key+"_TC" ; tag_value = key_value[1];}
            else if(j==2){ tag_key = prefix_key+"_SC" ; tag_value = key_value[2];}

            QString fieldname = config_set.value(tag_key,"").toString();
            if(fieldname.isEmpty()){
                config_set.setValue(tag_key,tag_value);
                fieldname = config_set.value(tag_key).toString();
            }
            if(j==0){ _fieldname_Vec_E.append(fieldname); }
            else if(j==1){ _fieldname_Vec_TC.append(fieldname); }
            else if(j==2){ _fieldname_Vec_SC.append(fieldname); }
        }
    }    
    //--- sort_frame show -----------------------
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    ui->lb_sorttitle->setText((lang_type == elanguage_type_TC)? "排序欄位" :
                              ((lang_type == elanguage_type_SC)? "排序栏位":"Sort by"));
    ui->cbox_sort_code->setText((lang_type == elanguage_type_TC)? "操作識別碼" :
                              ((lang_type == elanguage_type_SC)? "操作识别码":"Operate id"));
    ui->cbox_sort_time->setText((lang_type == elanguage_type_TC)? "異動時間" :
                              ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    //--- Search field set ----------------------
    ui->cbox_search_condition->clear();
    QStringList strList;
    strList.append((lang_type == elanguage_type_TC)? "操作識別碼" :
                   ((lang_type == elanguage_type_SC)? "操作识别码":"Operate id"));
    strList.append((lang_type == elanguage_type_TC)? "主KEY值" :
                   ((lang_type == elanguage_type_SC)? "主KEY值":"primary_id"));    
    strList.append((lang_type == elanguage_type_TC)? "全部資料" :
                   ((lang_type == elanguage_type_SC)? "全部资料":"all data"));
    strList.append((lang_type == elanguage_type_TC)? "操作編號" :
                   ((lang_type == elanguage_type_SC)? "操作编号":"Operate level"));
    strList.append((lang_type == elanguage_type_TC)? "異動時間" :
                   ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    ui->cbox_search_condition->addItems(strList);
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::table_dataShow_operatecode_parameters()
{
    ui->tableWidget->setSortingEnabled(false);
    //----------------------------
    vector<ptr_operatecode_parameters> result = _controlmodel->get_operatecode_parameters_results();
    int isize = result.size();
    ui->tableWidget->setSortingEnabled(false);
    if(isize == 0){
        ui->tableWidget->setRowCount(1) ; 
        for(int i=0;i<_fiels_num;i++){
            ui->tableWidget->setItem(0,i,new QTableWidgetItem(""));   // (row,col) 
        }
    }
    else{
        ui->tableWidget->setRowCount(isize) ; 
        for(int i=0;i<isize;i++){
            ui->tableWidget->setItem(i,0,new QTableWidgetItem(QString::fromStdString(result[i]->primary_id)));   // (row,col) 
            ui->tableWidget->setItem(i,1,new QTableWidgetItem(QString::fromStdString(result[i]->unique_code)));   // (row,col) 
            ui->tableWidget->setItem(i,2,new QTableWidgetItem(QString::fromStdString(result[i]->base_name)));   // (row,col) 
            ui->tableWidget->setItem(i,3,new QTableWidgetItem(QString::number(result[i]->operate_level)));   // (row,col) 
            ui->tableWidget->setItem(i,4,new QTableWidgetItem(QString::fromStdString(result[i]->operate_desc_eng)));   // (row,col) 
            ui->tableWidget->setItem(i,5,new QTableWidgetItem(QString::fromStdString(result[i]->operate_desc_tc)));   // (row,col) 
            ui->tableWidget->setItem(i,6,new QTableWidgetItem(QString::fromStdString(result[i]->operate_desc_sc)));   // (row,col) 
            ui->tableWidget->setItem(i,7,new QTableWidgetItem(QString::fromStdString(result[i]->update_time)));   // (row,col) 
        }          
    }
    ui->tableWidget->setSortingEnabled(true);
    //-------------------------
    table_sorttype_show();
    //-- set currentItem is first item and show its detail data ---
    ui->tableWidget->selectRow(0);
    edit_frame_dataShow();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::update_procedure_operatecode_parameters(db_tb_error_type &_error_type)
{ 
    ptr_operatecode_parameters _data = boost::make_shared<type_operatecode_parameters>();
    _data->primary_id = ui->lineEdit_0->text().toStdString();
    _data->unique_code = ui->lineEdit_1->text().toStdString();
    _data->base_name = ui->lineEdit_2->text().toStdString();
    _data->operate_level = ui->lineEdit_3->text().toInt();
    _data->operate_desc_eng = ui->lineEdit_4->text().toStdString();
    _data->operate_desc_tc = ui->lineEdit_5->text().toStdString();
    _data->operate_desc_sc = (bool)ui->lineEdit_6->text().toInt();
    _data->update_time = ui->lineEdit_7->text().toStdString();

    db_tb_edit_type _edit_type = (_table_OP_type == db_table_OP_Add) ? edb_tb_edit_add : edb_tb_edit_modify ; 
    emit _controlmodel->operatecode_parameters_update_Changed(_edit_type,_data);

    _error_type = _controlmodel->get_operatecode_parameters_error_type();
    if(_error_type == edb_tb_err_type_none){
        std::string _primary_code,_updatetime ;
        _controlmodel->get_operatecode_parameters_req_updated(_primary_code,_updatetime); 
        ui->lineEdit_0->setText(QString::fromStdString(_primary_code));
        ui->lineEdit_7->setText(QString::fromStdString(_updatetime));
        edit_table_dataShow();
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::delete_procedure_operatecode_parameters(db_tb_error_type &_error_type)
{ 
    std::string delete_code =  ui->lineEdit_0->text().toStdString();    // primary key
    emit _controlmodel->operatecode_parameters_delete_Changed(delete_code) ;
    _error_type = _controlmodel->get_operatecode_parameters_error_type();
    if(_error_type == edb_tb_err_type_none){
        int rowIndex = ui->tableWidget->currentRow();
        if (rowIndex != -1)
            ui->tableWidget->removeRow(rowIndex);
        int row = ui->tableWidget->rowCount();
        if((row-1) >= last_table_rowno){
            ui->tableWidget->selectRow(last_table_rowno);  
        }
        else{
            ui->tableWidget->selectRow(row-1);  
        }  
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_confirm_operatecode_parameters(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_operatecode_parameters_search_type query_opt = edynamic_operatecode_parameters_search_base_name;
    int _query = ui->cbox_search_condition->currentIndex();
    if(_query < 3){
        query_base = (db_tb_search_type) _query ;
    }
    else if(_query == 3){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_operatecode_parameters_search_base_name;
    }
    else if(_query == 4){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_operatecode_parameters_search_uptime;
    }

    std::string search_param = ui->edit_search_from->text().toStdString() ;
    search_param += ui->edit_search_to->text().isEmpty() ? "" :
                    ","+ ui->edit_search_to->text().toStdString();

    emit _controlmodel->operatecode_parameters_query_Changed(query_base,query_opt,search_param);
    _error_type = _controlmodel->get_operatecode_parameters_error_type();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_cancel_operatecode_parameters(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_operatecode_parameters_search_type query_opt = edynamic_operatecode_parameters_search_base_name;
    std::string search_param = "search_all" ; 

    emit _controlmodel->operatecode_parameters_query_Changed(query_base,query_opt,search_param);

    _error_type = _controlmodel->get_operatecode_parameters_error_type();
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  table function : ebasetb_car_alarm_history                             **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmDB_baseTable::parse_basetb_car_alarm_history()
{
    vectors_clear();

    config_filename = QApplication::applicationDirPath()+"/config/config.cfg";
    QSettings config_set(config_filename,QSettings::IniFormat);
    config_set.setIniCodec("UTF-8");
    //-- table field number ----
    int field_num = config_set.value("car_alarm_history/field_num",-1).toInt();
    if(field_num == -1){
        config_set.setValue("car_alarm_history/field_num",6);
        field_num = config_set.value("car_alarm_history/field_num").toInt();
    }
    _fiels_num = field_num ;

    //-- groupbox title ----
    QString prefix_key = "car_alarm_history/tablelist";
    QString tag_value = "";
    QString tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "Alarm History manager list" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "警報歷史資料 表列" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "警报历史资料 表列" ; }
        QString tablelist = config_set.value(tag_key,"").toString();
        if(tablelist.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablelist = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablelist); }
        else if(i==1){ _titlename_Vec_TC.append(tablelist); }
        else if(i==2){ _titlename_Vec_SC.append(tablelist); }

    }
    //-- tablename title ----
    prefix_key = "car_alarm_history/tablename";
    tag_value = "";
    tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "table name:car_alarm_history" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "資料表名稱:car_alarm_history" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "资料表名称:car_alarm_history" ; }
        QString tablename = config_set.value(tag_key,"").toString();
        if(tablename.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablename = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablename); }
        else if(i==1){ _titlename_Vec_TC.append(tablename); }
        else if(i==2){ _titlename_Vec_SC.append(tablename); }

    }
    //--- field title set ----
    QString key_value[3]={"","",""};

    for(int i=0;i<_fiels_num;i++){
        prefix_key = "car_alarm_history/fieldname_"+ QString::number(i);
        if(i==0){key_value[0]="primary_id";key_value[1]="主KEY值";key_value[2]="主KEY值";}
        else if(i==1){key_value[0]="Alarm History id";key_value[1]="歷史警報識別碼";key_value[2]="历史警报识别码";}
        else if(i==2){key_value[0]="Alarm Code";key_value[1]="警報編號";key_value[2]="警报编号";}
        else if(i==3){key_value[0]="occur time";key_value[1]="發生時間";key_value[2]="发生时间";}
        else if(i==4){key_value[0]="Remark";key_value[1]="備註說明";key_value[2]="备注说明";}
        else if(i==5){key_value[0]="update_time";key_value[1]="異動時間";key_value[2]="异动时间";}

        for(int j=0;j<3;j++){
            if(j==0){ tag_key = prefix_key+"_E" ; tag_value = key_value[0];}
            else if(j==1){ tag_key = prefix_key+"_TC" ; tag_value = key_value[1];}
            else if(j==2){ tag_key = prefix_key+"_SC" ; tag_value = key_value[2];}

            QString fieldname = config_set.value(tag_key,"").toString();
            if(fieldname.isEmpty()){
                config_set.setValue(tag_key,tag_value);
                fieldname = config_set.value(tag_key).toString();
            }
            if(j==0){ _fieldname_Vec_E.append(fieldname); }
            else if(j==1){ _fieldname_Vec_TC.append(fieldname); }
            else if(j==2){ _fieldname_Vec_SC.append(fieldname); }
        }
    }    
    //--- sort_frame show -----------------------
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    ui->lb_sorttitle->setText((lang_type == elanguage_type_TC)? "排序欄位" :
                              ((lang_type == elanguage_type_SC)? "排序栏位":"Sort by"));
    ui->cbox_sort_code->setText((lang_type == elanguage_type_TC)? "操作識別碼" :
                              ((lang_type == elanguage_type_SC)? "操作识别码":"Operate id"));
    ui->cbox_sort_time->setText((lang_type == elanguage_type_TC)? "異動時間" :
                              ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    //--- Search field set ----------------------
    ui->cbox_search_condition->clear();
    QStringList strList;
    strList.append((lang_type == elanguage_type_TC)? "歷史警報識別碼" :
                   ((lang_type == elanguage_type_SC)? "历史警报识别码":"Alarm History id"));
    strList.append((lang_type == elanguage_type_TC)? "主KEY值" :
                   ((lang_type == elanguage_type_SC)? "主KEY值":"primary_id"));    
    strList.append((lang_type == elanguage_type_TC)? "全部資料" :
                   ((lang_type == elanguage_type_SC)? "全部资料":"all data"));
    strList.append((lang_type == elanguage_type_TC)? "警報編號" :
                   ((lang_type == elanguage_type_SC)? "警报编号":"Alarm Code"));
    strList.append((lang_type == elanguage_type_TC)? "異動時間" :
                   ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    ui->cbox_search_condition->addItems(strList);
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::table_dataShow_car_alarm_history()
{
    ui->tableWidget->setSortingEnabled(false);
    //----------------------------
    vector<ptr_car_alarm_history> result = _controlmodel->get_car_alarm_history_results();
    int isize = result.size();
    ui->tableWidget->setSortingEnabled(false);
    if(isize == 0){
        ui->tableWidget->setRowCount(1) ; 
        for(int i=0;i<_fiels_num;i++){
            ui->tableWidget->setItem(0,i,new QTableWidgetItem(""));   // (row,col) 
        }
    }
    else{
        ui->tableWidget->setRowCount(isize) ; 
        for(int i=0;i<isize;i++){
            ui->tableWidget->setItem(i,0,new QTableWidgetItem(QString::fromStdString(result[i]->primary_id)));   // (row,col) 
            ui->tableWidget->setItem(i,1,new QTableWidgetItem(QString::fromStdString(result[i]->unique_code)));   // (row,col) 
            ui->tableWidget->setItem(i,2,new QTableWidgetItem(QString::fromStdString(result[i]->base_name)));   // (row,col) 
            ui->tableWidget->setItem(i,3,new QTableWidgetItem(QString::fromStdString(result[i]->occur_time)));   // (row,col) 
            ui->tableWidget->setItem(i,4,new QTableWidgetItem(QString::fromStdString(result[i]->alarm_remark)));   // (row,col) 
            ui->tableWidget->setItem(i,5,new QTableWidgetItem(QString::fromStdString(result[i]->update_time)));   // (row,col) 
        }          
    }
    ui->tableWidget->setSortingEnabled(true);
    //-------------------------
    table_sorttype_show();
    //-- set currentItem is first item and show its detail data ---
    ui->tableWidget->selectRow(0);
    edit_frame_dataShow();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::update_procedure_car_alarm_history(db_tb_error_type &_error_type)
{ 
    ptr_car_alarm_history _data = boost::make_shared<type_car_alarm_history>();
    _data->primary_id = ui->lineEdit_0->text().toStdString();
    _data->unique_code = ui->lineEdit_1->text().toStdString();
    _data->base_name = ui->lineEdit_2->text().toStdString();
    _data->occur_time = ui->lineEdit_3->text().toInt();
    _data->alarm_remark = ui->lineEdit_4->text().toStdString();
    _data->update_time = ui->lineEdit_5->text().toStdString();

    db_tb_edit_type _edit_type = (_table_OP_type == db_table_OP_Add) ? edb_tb_edit_add : edb_tb_edit_modify ; 
    emit _controlmodel->car_alarm_history_update_Changed(_edit_type,_data);

    _error_type = _controlmodel->get_car_alarm_history_error_type();
    if(_error_type == edb_tb_err_type_none){
        std::string _primary_code,_updatetime ;
        _controlmodel->get_car_alarm_history_req_updated(_primary_code,_updatetime); 
        ui->lineEdit_0->setText(QString::fromStdString(_primary_code));
        ui->lineEdit_5->setText(QString::fromStdString(_updatetime));
        edit_table_dataShow();
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::delete_procedure_car_alarm_history(db_tb_error_type &_error_type)
{ 
    std::string delete_code =  ui->lineEdit_0->text().toStdString();    // primary key
    emit _controlmodel->car_alarm_history_delete_Changed(delete_code) ;
    _error_type = _controlmodel->get_car_alarm_history_error_type();
    if(_error_type == edb_tb_err_type_none){
        int rowIndex = ui->tableWidget->currentRow();
        if (rowIndex != -1)
            ui->tableWidget->removeRow(rowIndex);
        int row = ui->tableWidget->rowCount();
        if((row-1) >= last_table_rowno)
            ui->tableWidget->selectRow(last_table_rowno);  
        else{
            ui->tableWidget->selectRow(row);  
        }  
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_confirm_car_alarm_history(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_car_alarm_history_search_type query_opt = edynamic_car_alarm_history_search_base_name;
    int _query = ui->cbox_search_condition->currentIndex();
    if(_query < 3){
        query_base = (db_tb_search_type) _query ;
    }
    else if(_query == 3){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_car_alarm_history_search_base_name;
    }
    else if(_query == 4){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_car_alarm_history_search_uptime;
    }

    std::string search_param = ui->edit_search_from->text().toStdString() ;
    search_param += ui->edit_search_to->text().isEmpty() ? "" :
                    ","+ ui->edit_search_to->text().toStdString();

    emit _controlmodel->car_alarm_history_query_Changed(query_base,query_opt,search_param);
    _error_type = _controlmodel->get_car_alarm_history_error_type();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_cancel_car_alarm_history(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_car_alarm_history_search_type query_opt = edynamic_car_alarm_history_search_base_name;
    std::string search_param = "search_all" ; 

    emit _controlmodel->car_alarm_history_query_Changed(query_base,query_opt,search_param);

    _error_type = _controlmodel->get_car_alarm_history_error_type();
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  table function : ebasetb_car_operate_history                           **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmDB_baseTable::parse_basetb_car_operate_history()
{
    vectors_clear();

    config_filename = QApplication::applicationDirPath()+"/config/config.cfg";
    QSettings config_set(config_filename,QSettings::IniFormat);
    config_set.setIniCodec("UTF-8");
    //-- table field number ----
    int field_num = config_set.value("car_operate_history/field_num",-1).toInt();
    if(field_num == -1){
        config_set.setValue("car_operate_history/field_num",6);
        field_num = config_set.value("car_operate_history/field_num").toInt();
    }
    _fiels_num = field_num ;

    //-- groupbox title ----
    QString prefix_key = "car_operate_history/tablelist";
    QString tag_value = "";
    QString tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "Alarm History manager list" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "操作歷史資料 表列" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "操作历史资料 表列" ; }
        QString tablelist = config_set.value(tag_key,"").toString();
        if(tablelist.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablelist = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablelist); }
        else if(i==1){ _titlename_Vec_TC.append(tablelist); }
        else if(i==2){ _titlename_Vec_SC.append(tablelist); }

    }
    //-- tablename title ----
    prefix_key = "car_operate_history/tablename";
    tag_value = "";
    tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "table name:car_operate_history" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "資料表名稱:car_operate_history" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "资料表名称:car_operate_history" ; }
        QString tablename = config_set.value(tag_key,"").toString();
        if(tablename.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablename = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablename); }
        else if(i==1){ _titlename_Vec_TC.append(tablename); }
        else if(i==2){ _titlename_Vec_SC.append(tablename); }

    }
    //--- field title set ----
    QString key_value[3]={"","",""};

    for(int i=0;i<_fiels_num;i++){
        prefix_key = "car_operate_history/fieldname_"+ QString::number(i);
        if(i==0){key_value[0]="primary_id";key_value[1]="主KEY值";key_value[2]="主KEY值";}
        else if(i==1){key_value[0]="Operate History id";key_value[1]="操作警報識別碼";key_value[2]="操作警报识别码";}
        else if(i==2){key_value[0]="Operate Code";key_value[1]="操作編號";key_value[2]="操作编号";}
        else if(i==3){key_value[0]="occur time";key_value[1]="發生時間";key_value[2]="发生时间";}
        else if(i==4){key_value[0]="Remark";key_value[1]="備註說明";key_value[2]="备注说明";}
        else if(i==5){key_value[0]="update_time";key_value[1]="異動時間";key_value[2]="异动时间";}

        for(int j=0;j<3;j++){
            if(j==0){ tag_key = prefix_key+"_E" ; tag_value = key_value[0];}
            else if(j==1){ tag_key = prefix_key+"_TC" ; tag_value = key_value[1];}
            else if(j==2){ tag_key = prefix_key+"_SC" ; tag_value = key_value[2];}

            QString fieldname = config_set.value(tag_key,"").toString();
            if(fieldname.isEmpty()){
                config_set.setValue(tag_key,tag_value);
                fieldname = config_set.value(tag_key).toString();
            }
            if(j==0){ _fieldname_Vec_E.append(fieldname); }
            else if(j==1){ _fieldname_Vec_TC.append(fieldname); }
            else if(j==2){ _fieldname_Vec_SC.append(fieldname); }
        }
    }    
    //--- sort_frame show -----------------------
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    ui->lb_sorttitle->setText((lang_type == elanguage_type_TC)? "排序欄位" :
                              ((lang_type == elanguage_type_SC)? "排序栏位":"Sort by"));
    ui->cbox_sort_code->setText((lang_type == elanguage_type_TC)? "操作識別碼" :
                              ((lang_type == elanguage_type_SC)? "操作识别码":"Operate id"));
    ui->cbox_sort_time->setText((lang_type == elanguage_type_TC)? "異動時間" :
                              ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    //--- Search field set ----------------------
    ui->cbox_search_condition->clear();
    QStringList strList;
    strList.append((lang_type == elanguage_type_TC)? "歷史操作識別碼" :
                   ((lang_type == elanguage_type_SC)? "历史操作识别码":"Alarm History id"));
    strList.append((lang_type == elanguage_type_TC)? "主KEY值" :
                   ((lang_type == elanguage_type_SC)? "主KEY值":"primary_id"));    
    strList.append((lang_type == elanguage_type_TC)? "全部資料" :
                   ((lang_type == elanguage_type_SC)? "全部资料":"all data"));
    strList.append((lang_type == elanguage_type_TC)? "操作編號" :
                   ((lang_type == elanguage_type_SC)? "操作编号":"Alarm Code"));
    strList.append((lang_type == elanguage_type_TC)? "異動時間" :
                   ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    ui->cbox_search_condition->addItems(strList);
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::table_dataShow_car_operate_history()
{
    ui->tableWidget->setSortingEnabled(false);
    //----------------------------
    vector<ptr_car_operate_history> result = _controlmodel->get_car_operate_history_results();
    int isize = result.size();
    ui->tableWidget->setSortingEnabled(false);
    if(isize == 0){
        ui->tableWidget->setRowCount(1) ; 
        for(int i=0;i<_fiels_num;i++){
            ui->tableWidget->setItem(0,i,new QTableWidgetItem(""));   // (row,col) 
        }
    }
    else{
        ui->tableWidget->setRowCount(isize) ; 
        for(int i=0;i<isize;i++){
            ui->tableWidget->setItem(i,0,new QTableWidgetItem(QString::fromStdString(result[i]->primary_id)));   // (row,col) 
            ui->tableWidget->setItem(i,1,new QTableWidgetItem(QString::fromStdString(result[i]->unique_code)));   // (row,col) 
            ui->tableWidget->setItem(i,2,new QTableWidgetItem(QString::fromStdString(result[i]->base_name)));   // (row,col) 
            ui->tableWidget->setItem(i,3,new QTableWidgetItem(QString::fromStdString(result[i]->occur_time)));   // (row,col) 
            ui->tableWidget->setItem(i,4,new QTableWidgetItem(QString::fromStdString(result[i]->alarm_remark)));   // (row,col) 
            ui->tableWidget->setItem(i,5,new QTableWidgetItem(QString::fromStdString(result[i]->update_time)));   // (row,col) 
        }          
    }
    ui->tableWidget->setSortingEnabled(true);
    //-------------------------
    table_sorttype_show();
    //-- set currentItem is first item and show its detail data ---
    ui->tableWidget->selectRow(0);
    edit_frame_dataShow();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::update_procedure_car_operate_history(db_tb_error_type &_error_type)
{ 
    ptr_car_operate_history _data = boost::make_shared<type_car_operate_history>();
    _data->primary_id = ui->lineEdit_0->text().toStdString();
    _data->unique_code = ui->lineEdit_1->text().toStdString();
    _data->base_name = ui->lineEdit_2->text().toStdString();
    _data->occur_time = ui->lineEdit_3->text().toInt();
    _data->alarm_remark = ui->lineEdit_4->text().toStdString();
    _data->update_time = ui->lineEdit_5->text().toStdString();

    db_tb_edit_type _edit_type = (_table_OP_type == db_table_OP_Add) ? edb_tb_edit_add : edb_tb_edit_modify ; 
    emit _controlmodel->car_operate_history_update_Changed(_edit_type,_data);

    _error_type = _controlmodel->get_car_operate_history_error_type();
    if(_error_type == edb_tb_err_type_none){
        std::string _primary_code,_updatetime ;
        _controlmodel->get_car_operate_history_req_updated(_primary_code,_updatetime); 
        ui->lineEdit_0->setText(QString::fromStdString(_primary_code));
        ui->lineEdit_5->setText(QString::fromStdString(_updatetime));
        edit_table_dataShow();
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::delete_procedure_car_operate_history(db_tb_error_type &_error_type)
{ 
    std::string delete_code =  ui->lineEdit_0->text().toStdString();    // primary key
    emit _controlmodel->car_operate_history_delete_Changed(delete_code) ;
    _error_type = _controlmodel->get_car_operate_history_error_type();
    if(_error_type == edb_tb_err_type_none){
        int rowIndex = ui->tableWidget->currentRow();
        if (rowIndex != -1)
            ui->tableWidget->removeRow(rowIndex);
        int row = ui->tableWidget->rowCount();
        if((row-1) >= last_table_rowno)
            ui->tableWidget->selectRow(last_table_rowno);  
        else{
            ui->tableWidget->selectRow(row);  
        }  
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_confirm_car_operate_history(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_car_operate_history_search_type query_opt = edynamic_car_operate_history_search_base_name;
    int _query = ui->cbox_search_condition->currentIndex();
    if(_query < 3){
        query_base = (db_tb_search_type) _query ;
    }
    else if(_query == 3){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_car_operate_history_search_base_name;
    }
    else if(_query == 4){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_car_operate_history_search_uptime;
    }

    std::string search_param = ui->edit_search_from->text().toStdString() ;
    search_param += ui->edit_search_to->text().isEmpty() ? "" :
                    ","+ ui->edit_search_to->text().toStdString();

    emit _controlmodel->car_operate_history_query_Changed(query_base,query_opt,search_param);
    _error_type = _controlmodel->get_car_operate_history_error_type();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_cancel_car_operate_history(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_car_operate_history_search_type query_opt = edynamic_car_operate_history_search_base_name;
    std::string search_param = "search_all" ; 

    emit _controlmodel->car_operate_history_query_Changed(query_base,query_opt,search_param);

    _error_type = _controlmodel->get_car_operate_history_error_type();
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  table function : ebasetb_action_function_parameters                    **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmDB_baseTable::parse_basetb_action_function_parameters()
{
    vectors_clear();

    config_filename = QApplication::applicationDirPath()+"/config/config.cfg";
    QSettings config_set(config_filename,QSettings::IniFormat);
    config_set.setIniCodec("UTF-8");
    //-- table field number ----
    int field_num = config_set.value("action_function_parameters/field_num",-1).toInt();
    if(field_num == -1){
        config_set.setValue("action_function_parameters/field_num",9);//8);
        field_num = config_set.value("action_function_parameters/field_num").toInt();
    }
    _fiels_num = field_num ;

    //-- groupbox title ----
    QString prefix_key = "action_function_parameters/tablelist";
    QString tag_value = "";
    QString tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "Alarm History manager list" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "動作功能資料 表列" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "动作功能资料 表列" ; }
        QString tablelist = config_set.value(tag_key,"").toString();
        if(tablelist.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablelist = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablelist); }
        else if(i==1){ _titlename_Vec_TC.append(tablelist); }
        else if(i==2){ _titlename_Vec_SC.append(tablelist); }

    }
    //-- tablename title ----
    prefix_key = "action_function_parameters/tablename";
    tag_value = "";
    tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "table name:action_function_parameters" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "資料表名稱:action_function_parameters" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "资料表名称:action_function_parameters" ; }
        QString tablename = config_set.value(tag_key,"").toString();
        if(tablename.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablename = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_Vec_E.append(tablename); }
        else if(i==1){ _titlename_Vec_TC.append(tablename); }
        else if(i==2){ _titlename_Vec_SC.append(tablename); }

    }
    //--- field title set ----
    QString key_value[3]={"","",""};

    for(int i=0;i<_fiels_num;i++){
        prefix_key = "action_function_parameters/fieldname_"+ QString::number(i);
        if(i==0){key_value[0]="primary_id";key_value[1]="主KEY值";key_value[2]="主KEY值";}
        else if(i==1){key_value[0]="Action function id";key_value[1]="動作功能識別碼";key_value[2]="动作功能识别码";}
        else if(i==2){key_value[0]="Action function Code";key_value[1]="動作功能編號";key_value[2]="动作功能编号";}
        else if(i==3){key_value[0]="Action function level";key_value[1]="動作功能等級";key_value[2]="动作功能等级";}
        else if(i==4){key_value[0]="Action client name";key_value[1]="Action client 名稱";key_value[2]="Action client 名称";}
        else if(i==5){key_value[0]="Description_Eng";key_value[1]="英文說明";key_value[2]="英文说明";}
        else if(i==6){key_value[0]="Description_TC";key_value[1]="繁體中文說明";key_value[2]="繁体中文说明";}
        else if(i==7){key_value[0]="Description_SC";key_value[1]="簡體中文說明";key_value[2]="简体中文说明";}
        else if(i==8){key_value[0]="update_time";key_value[1]="異動時間";key_value[2]="异动时间";}

        for(int j=0;j<3;j++){
            if(j==0){ tag_key = prefix_key+"_E" ; tag_value = key_value[0];}
            else if(j==1){ tag_key = prefix_key+"_TC" ; tag_value = key_value[1];}
            else if(j==2){ tag_key = prefix_key+"_SC" ; tag_value = key_value[2];}

            QString fieldname = config_set.value(tag_key,"").toString();
            if(fieldname.isEmpty()){
                config_set.setValue(tag_key,tag_value);
                fieldname = config_set.value(tag_key).toString();
            }
            if(j==0){ _fieldname_Vec_E.append(fieldname); }
            else if(j==1){ _fieldname_Vec_TC.append(fieldname); }
            else if(j==2){ _fieldname_Vec_SC.append(fieldname); }
        }
    }    
    //--- sort_frame show -----------------------
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    ui->lb_sorttitle->setText((lang_type == elanguage_type_TC)? "排序欄位" :
                              ((lang_type == elanguage_type_SC)? "排序栏位":"Sort by"));
    ui->cbox_sort_code->setText((lang_type == elanguage_type_TC)? "操作識別碼" :
                              ((lang_type == elanguage_type_SC)? "操作识别码":"Operate id"));
    ui->cbox_sort_time->setText((lang_type == elanguage_type_TC)? "異動時間" :
                              ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    //--- Search field set ----------------------
    ui->cbox_search_condition->clear();
    QStringList strList;
    strList.append((lang_type == elanguage_type_TC)? "動作功能識別碼" :
                   ((lang_type == elanguage_type_SC)? "动作功能识别码":"Action function id"));
    strList.append((lang_type == elanguage_type_TC)? "主KEY值" :
                   ((lang_type == elanguage_type_SC)? "主KEY值":"primary_id"));    
    strList.append((lang_type == elanguage_type_TC)? "全部資料" :
                   ((lang_type == elanguage_type_SC)? "全部资料":"all data"));
    strList.append((lang_type == elanguage_type_TC)? "動作功能編號" :
                   ((lang_type == elanguage_type_SC)? "动作功能编号":"Action function Code"));
    strList.append((lang_type == elanguage_type_TC)? "異動時間" :
                   ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    ui->cbox_search_condition->addItems(strList);
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::table_dataShow_action_function_parameters()
{
    ui->tableWidget->setSortingEnabled(false);
    //----------------------------
    vector<ptr_action_function_parameters> result = _controlmodel->get_action_function_parameters_results();
    int isize = result.size();
    ui->tableWidget->setSortingEnabled(false);
    if(isize == 0){
        ui->tableWidget->setRowCount(1) ; 
        for(int i=0;i<_fiels_num;i++){
            ui->tableWidget->setItem(0,i,new QTableWidgetItem(""));   // (row,col) 
        }
    }
    else{
        ui->tableWidget->setRowCount(isize) ; 
        for(int i=0;i<isize;i++){
            ui->tableWidget->setItem(i,0,new QTableWidgetItem(QString::fromStdString(result[i]->primary_id)));   // (row,col) 
            ui->tableWidget->setItem(i,1,new QTableWidgetItem(QString::fromStdString(result[i]->unique_code)));   // (row,col) 
            ui->tableWidget->setItem(i,2,new QTableWidgetItem(QString::fromStdString(result[i]->base_name)));   // (row,col) 
            ui->tableWidget->setItem(i,3,new QTableWidgetItem(QString::number(result[i]->function_level)));   // (row,col) 
            ui->tableWidget->setItem(i,4,new QTableWidgetItem(QString::fromStdString(result[i]->function_ac_name)));   // (row,col) 
            ui->tableWidget->setItem(i,5,new QTableWidgetItem(QString::fromStdString(result[i]->function_desc_eng)));   // (row,col) 
            ui->tableWidget->setItem(i,6,new QTableWidgetItem(QString::fromStdString(result[i]->function_desc_tc)));   // (row,col) 
            ui->tableWidget->setItem(i,7,new QTableWidgetItem(QString::fromStdString(result[i]->function_desc_sc)));   // (row,col) 
            ui->tableWidget->setItem(i,8,new QTableWidgetItem(QString::fromStdString(result[i]->update_time)));   // (row,col) 
        }          
    }
    ui->tableWidget->setSortingEnabled(true);
    //-------------------------
    table_sorttype_show();
    //-- set currentItem is first item and show its detail data ---
    ui->tableWidget->selectRow(0);
    edit_frame_dataShow();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::update_procedure_action_function_parameters(db_tb_error_type &_error_type)
{ 
    ptr_action_function_parameters _data = boost::make_shared<type_action_function_parameters>();
    _data->primary_id = ui->lineEdit_0->text().toStdString();
    _data->unique_code = ui->lineEdit_1->text().toStdString();
    _data->base_name = ui->lineEdit_2->text().toStdString();
    _data->function_level = ui->lineEdit_3->text().toInt();
    _data->function_ac_name = ui->lineEdit_4->text().toStdString();
    _data->function_desc_eng = ui->lineEdit_5->text().toStdString();
    _data->function_desc_tc = ui->lineEdit_6->text().toStdString();
    _data->function_desc_sc = ui->lineEdit_7->text().toStdString();
    _data->update_time = ui->lineEdit_8->text().toStdString();

    db_tb_edit_type _edit_type = (_table_OP_type == db_table_OP_Add) ? edb_tb_edit_add : edb_tb_edit_modify ; 
    emit _controlmodel->action_function_parameters_update_Changed(_edit_type,_data);

    _error_type = _controlmodel->get_action_function_parameters_error_type();
    if(_error_type == edb_tb_err_type_none){
        std::string _primary_code,_updatetime ;
        _controlmodel->get_action_function_parameters_req_updated(_primary_code,_updatetime); 
        ui->lineEdit_0->setText(QString::fromStdString(_primary_code));
        ui->lineEdit_8->setText(QString::fromStdString(_updatetime));
        edit_table_dataShow();
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::delete_procedure_action_function_parameters(db_tb_error_type &_error_type)
{ 
    std::string delete_code =  ui->lineEdit_0->text().toStdString();    // primary key
    emit _controlmodel->action_function_parameters_delete_Changed(delete_code) ;
    _error_type = _controlmodel->get_action_function_parameters_error_type();
    if(_error_type == edb_tb_err_type_none){
        int rowIndex = ui->tableWidget->currentRow();
        if (rowIndex != -1)
            ui->tableWidget->removeRow(rowIndex);
        int row = ui->tableWidget->rowCount();
        if((row-1) >= last_table_rowno)
            ui->tableWidget->selectRow(last_table_rowno);  
        else{
            ui->tableWidget->selectRow(row);  
        }  
        _table_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_confirm_action_function_parameters(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_action_function_parameters_search_type query_opt = edynamic_action_function_parameters_search_base_name;
    int _query = ui->cbox_search_condition->currentIndex();
    if(_query < 3){
        query_base = (db_tb_search_type) _query ;
    }
    else if(_query == 3){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_action_function_parameters_search_base_name;
    }
    else if(_query == 4){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_action_function_parameters_search_uptime;
    }

    std::string search_param = ui->edit_search_from->text().toStdString() ;
    search_param += ui->edit_search_to->text().isEmpty() ? "" :
                    ","+ ui->edit_search_to->text().toStdString();

    emit _controlmodel->action_function_parameters_query_Changed(query_base,query_opt,search_param);
    _error_type = _controlmodel->get_action_function_parameters_error_type();
}
//-----------------------------------------------------------------------------
void frmDB_baseTable::search_cancel_action_function_parameters(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_action_function_parameters_search_type query_opt = edynamic_action_function_parameters_search_base_name;
    std::string search_param = "search_all" ; 

    emit _controlmodel->action_function_parameters_query_Changed(query_base,query_opt,search_param);

    _error_type = _controlmodel->get_action_function_parameters_error_type();
}
//-----------------------------------------------------------------------------

