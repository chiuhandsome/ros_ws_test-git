#include "car_db_manager/app_form/frmdb_relatetable.h"
#include "ui_frmdb_relatetable.h"
#include "car_db_manager/utility/qt_generaltools.h"
#include <QMessageBox>
#include <ros_utility_tools/ros_tools.h>
//-----------------------------------------------------------------------------
frmdb_relateTable::frmdb_relateTable(qt_app_model* app_mode,QWidget *parent) :
    QWidget(parent),
    ui(new Ui::frmdb_relateTable)
{
    ui->setupUi(this);
    _app_mode = app_mode ;    
    //---------------------
    set_style_sheet();
    vectors_m_clear();
    vectors_d_clear();
    _fiels_maxnum_m = 20 ;
    _fiels_maxnum_d = 20 ;
    //----------------------
    _table_m_OP_type = db_table_OP_None ;
    _table_d_OP_type = db_table_OP_None ;
    _table_m_sorttype = erelatetb_sort_code ;
    _table_d_sorttype = erelatetb_sort_item_mission ;

    ui->cbox_sort_cond_mast->setCurrentIndex(0);
    ui->cbox_sort_cond_detail->setCurrentIndex(0);

    b_rowno_error_false = false ;
    //--- Option lineEit and combobox status initial ---
    ui->cbox_dynamic_Key_0_id->setVisible(false);
    ui->lineEdit_dynamic_Key_0_name->setVisible(false);
    ui->cbox_dynamic_Key_1_id->setVisible(false);
    ui->lineEdit_dynamic_Key_1_name->setVisible(false);
    ui->cbox_dynamic_Key_2_id->setVisible(false);
    ui->lineEdit_dynamic_Key_2_name->setVisible(false);
    ui->cbox_dynamic_Key_3_id->setVisible(false);
    ui->lineEdit_dynamic_Key_3_name->setVisible(false);
    ui->cbox_dynamic_Key_4_id->setVisible(false);
    ui->lineEdit_dynamic_Key_4_name->setVisible(false);
    ui->cbox_dynamic_Key_5_id->setVisible(false);
    ui->lineEdit_dynamic_Key_5_name->setVisible(false);
    ui->cbox_dynamic_Key_6_id->setVisible(false);
    ui->lineEdit_dynamic_Key_6_name->setVisible(false);
    ui->cbox_dynamic_Key_7_id->setVisible(false);
    ui->lineEdit_dynamic_Key_7_name->setVisible(false);
    ui->cbox_dynamic_Key_8_id->setVisible(false);
    ui->lineEdit_dynamic_Key_8_name->setVisible(false);
    ui->cbox_dynamic_Key_9_id->setVisible(false);
    ui->lineEdit_dynamic_Key_9_name->setVisible(false);
}
//-----------------------------------------------------------------------------
frmdb_relateTable::~frmdb_relateTable()
{
    delete ui;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  public area   --- fixed                                                **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmdb_relateTable::control_model_set(ros_control_related *controlmodel,ros_controlmodel* base_controlmodel)
{
    _controlmodel = controlmodel ;
    _base_controlmodel = base_controlmodel ;
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::form_table_type_show_m()
{
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    //-- groupbox title and table title show ---
    QString gbox_title = "";
    QString table_title = "";
    if(lang_type == elanguage_type_E){
        gbox_title = _titlename_m_Vec_E[0];
        table_title = _titlename_m_Vec_E[1];
    }
    else if(lang_type == elanguage_type_TC){
        gbox_title = _titlename_m_Vec_TC[0];
        table_title = _titlename_m_Vec_TC[1];
    }
    else if(lang_type == elanguage_type_SC){
        gbox_title = _titlename_m_Vec_SC[0];
        table_title = _titlename_m_Vec_SC[1];
    }
    ui->lb_title_mname->setText(table_title);
    ui->gbox_masttable->setTitle(gbox_title);
    //-- label and lineedit show in edit_frame ----------------
    QString label_name ;
    QString lineedit_name ;
    for(int i=0;i<_fiels_maxnum_m;i++){
        lineedit_name = "lineEdit_mast_"+QString::number(i);
        label_name = "lb_mast_field_"+QString::number(i);
        QLineEdit *obj_lEdit = ui->edit_mastframe->findChild<QLineEdit *>(lineedit_name);
        QLabel *obj_label = ui->edit_mastframe->findChild<QLabel *>(label_name);
        if(obj_lEdit && obj_label){            
            bool bVisible = (i<_fiels_num_m);
            obj_lEdit->setVisible(bVisible);
            obj_label->setVisible(bVisible);
            if(bVisible){
                if(lang_type == elanguage_type_E)
                    obj_label->setText(_fieldname_m_Vec_E[i]);
                else if(lang_type == elanguage_type_TC)
                    obj_label->setText(_fieldname_m_Vec_TC[i]);
                else if(lang_type == elanguage_type_SC)
                    obj_label->setText(_fieldname_m_Vec_SC[i]);
            }
        }
    }
    //-- title show of tableWidget ----------------
    ui->mast_tableWidget->setVisible(true);
    ui->mast_tableWidget->setRowCount(1);
    ui->mast_tableWidget->setColumnCount(_fiels_num_m);
    QStringList header;    
    //QString label_name ;
    QString data ;
    for(int i=0;i<_fiels_num_m;i++){
        label_name = "lb_mast_field_"+QString::number(i);
        QLabel *obj_label = ui->edit_mastframe->findChild<QLabel *>((QString)label_name);
        data = (QString)obj_label->text();
        header.append(data);
    }
    ui->mast_tableWidget->setHorizontalHeaderLabels(header);
    ui->mast_tableWidget->setSortingEnabled(false);
    for(int i=0;i<_fiels_num_m;i++){
        ui->mast_tableWidget->setItem(0,i,new QTableWidgetItem(""));   // (row,col) 
    }
    ui->mast_tableWidget->setSortingEnabled(true);
    ui->mast_tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);  
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::form_table_type_show_d()
{
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    //-- groupbox title and table title show ---
    QString gbox_title = "";
    QString table_title = "";
    if(lang_type == elanguage_type_E){
        gbox_title = _titlename_d_Vec_E[0];
        table_title = _titlename_d_Vec_E[1];
    }
    else if(lang_type == elanguage_type_TC){
        gbox_title = _titlename_d_Vec_TC[0];
        table_title = _titlename_d_Vec_TC[1];
    }
    else if(lang_type == elanguage_type_SC){
        gbox_title = _titlename_d_Vec_SC[0];
        table_title = _titlename_d_Vec_SC[1];
    }
    ui->lb_title_dname->setText(table_title);
    ui->gbox_detailtable->setTitle(gbox_title);
    //-- label and lineedit show in edit_frame ----------------
    QString label_name ;
    QString lineedit_name ;    
    for(int i=0;i<_fiels_maxnum_d;i++){
        lineedit_name = "lineEdit_detail_"+QString::number(i);
        label_name = "lb_detail_field_"+QString::number(i);
        QLineEdit *obj_lEdit = ui->edit_detail_frame->findChild<QLineEdit *>(lineedit_name);
        QLabel *obj_label = ui->edit_detail_frame->findChild<QLabel *>(label_name);
        if(obj_lEdit && obj_label){            
            bool bVisible = (i<_fiels_num_d);
            obj_lEdit->setVisible(bVisible);
            obj_label->setVisible(bVisible);
            if(bVisible){
                //obj_label->setEnabled(bEdit);
                if(lang_type == elanguage_type_E)
                    obj_label->setText(_fieldname_d_Vec_E[i]);
                else if(lang_type == elanguage_type_TC)
                    obj_label->setText(_fieldname_d_Vec_TC[i]);
                else if(lang_type == elanguage_type_SC)
                    obj_label->setText(_fieldname_d_Vec_SC[i]);
            }
        }
    }
    //-- title show of tableWidget ----------------
    ui->detail_tableWidget->setVisible(true);
    ui->detail_tableWidget->setRowCount(1);
    ui->detail_tableWidget->setColumnCount(_fiels_num_d);
    QStringList header;    
    //QString label_name ;
    QString data ;
    for(int i=0;i<_fiels_num_d;i++){
        label_name = "lb_detail_field_"+QString::number(i);
        QLabel *obj_label = ui->edit_detail_frame->findChild<QLabel *>((QString)label_name);
        data = (QString)obj_label->text();
        header.append(data);
    }
    ui->detail_tableWidget->setHorizontalHeaderLabels(header);
    ui->detail_tableWidget->setSortingEnabled(false);
    for(int i=0;i<_fiels_num_d;i++){
        ui->detail_tableWidget->setItem(0,i,new QTableWidgetItem(""));   // (row,col) 
    }
    ui->detail_tableWidget->setSortingEnabled(true);
    ui->detail_tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::formEdit_Show()
{
    //***** main process ******
    bool bEdit = (_table_m_OP_type != db_table_OP_None) ; 
    ui->gbox_masttable->setStyleSheet( !bEdit ? groupbox_style_enable : groupbox_style_disable);
    ui->mast_tableWidget->setEnabled(!bEdit);
    //-- edit_frame edit-type show ---
    ui->lb_title_mname->setStyleSheet(!bEdit ? labeltitle_style_enable :labeltitle_style_enable)  ;
    ui->edit_mastframe->setEnabled(bEdit);
    ui->lb_table_m_edittype->setVisible(bEdit) ;   
    QString lineedit_name ;
    QString label_name ;
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    
    for(int i=0;i<_fiels_maxnum_m;i++){
        lineedit_name = "lineEdit_mast_"+QString::number(i);
        label_name = "lb_mast_field_"+QString::number(i);
        QLineEdit *obj_lEdit = ui->edit_mastframe->findChild<QLineEdit *>(lineedit_name);
        QLabel *obj_label = ui->edit_mastframe->findChild<QLabel *>(label_name);
        if(obj_lEdit && obj_label){
            if(i<_fiels_num_m){    
                obj_label->setEnabled(bEdit);
                obj_lEdit->setEnabled(bEdit);
                obj_label->setStyleSheet(bEdit ? label_style_enable : label_style_disable );
                obj_lEdit->setStyleSheet(bEdit ? lineedit_style_enable : lineedit_style_disable );
            }
        }
    }
    ui->sort_mastframe->setEnabled(!bEdit);
    //***** detail process ******
    bEdit = (_table_d_OP_type != db_table_OP_None) ;
    ui->gbox_detailtable->setStyleSheet( !bEdit ? groupbox_style_enable : groupbox_style_disable);
    ui->detail_tableWidget->setEnabled(!bEdit);
    //-- edit_frame edit-type show ---
    ui->lb_title_dname->setStyleSheet(!bEdit ? labeltitle_style_enable :labeltitle_style_enable)  ;
    ui->edit_detail_frame->setEnabled(bEdit);
    ui->lb_table_d_edittype->setVisible(bEdit) ;   
    
    for(int i=0;i<_fiels_maxnum_d;i++){
        lineedit_name = "lineEdit_detail_"+QString::number(i);
        label_name = "lb_detail_field_"+QString::number(i);
        QLineEdit *obj_lEdit = ui->edit_detail_frame->findChild<QLineEdit *>(lineedit_name);
        QLabel *obj_label = ui->edit_detail_frame->findChild<QLabel *>(label_name);
        if(obj_lEdit && obj_label){
            if(i<_fiels_num_d){    
                obj_label->setEnabled(bEdit);
                obj_lEdit->setEnabled(bEdit);
                obj_label->setStyleSheet(bEdit ? label_style_enable : label_style_disable );
                obj_lEdit->setStyleSheet(bEdit ? lineedit_style_enable : lineedit_style_disable );
            }
        }
    }
    ui->sort_detailframe->setEnabled(!bEdit);
    //-- extension Show  ---
    formEdit_QtherShow();
    
    //--- operate area ------
    if((_table_m_OP_type == db_table_OP_None) && (_table_d_OP_type == db_table_OP_None) ){
        ui->search_frame->setVisible(false);
        ui->op_frame->setVisible(true);
        ui->op_frame_d->setVisible(true);
        ui->choice_frame->setVisible(false);
        ui->close_frame->setVisible(true);
        return ;
    }
    //------------
    ui->op_frame_d->setVisible(false);
    ui->op_frame->setVisible(false);
    ui->close_frame->setVisible(false);

    ui->choice_frame->setVisible(true);
    if(_table_m_OP_type != db_table_OP_None){        
        if(_table_m_OP_type == db_table_OP_Inquire){
            ui->search_frame->setVisible(true);            
            ui->choice_frame->move(880,580);
        }
        else{
            ui->search_frame->setVisible(false);
            ui->choice_frame->move(375,580);    
        }        
    }
    else if(_table_d_OP_type != db_table_OP_None){
        ui->search_frame->setVisible(_table_m_OP_type == db_table_OP_Inquire);
        ui->choice_frame->move(880,580);
    } 

    if(!ui->search_frame->isVisible())
        return ;
    //--- Search data setting -----
    QString gbox_title = "";
    QString table_title = (_table_m_OP_type != db_table_OP_None) ? "(Mast table)" : "(Detail table)";
    gbox_title = (lang_type == elanguage_type_E) ? "Search field select" :
                 ((lang_type == elanguage_type_TC) ? "搜尋欄位選擇" : "搜寻栏位选择") ;  
    ui->gbox_search_condition->setTitle(gbox_title);

    ui->cbox_search_condition->clear();
    QStringList strList;
    if(_table_m_OP_type != db_table_OP_None){
        strList.append((lang_type == elanguage_type_TC)? "工單索引值" :
                   ((lang_type == elanguage_type_SC)? "工单索引值":"work_sheet index"));
        strList.append((lang_type == elanguage_type_TC)? "主KEY值" :
                    ((lang_type == elanguage_type_SC)? "主KEY值":"primary_id"));    
        strList.append((lang_type == elanguage_type_TC)? "全部資料" :
                    ((lang_type == elanguage_type_SC)? "全部资料":"all data"));
        strList.append((lang_type == elanguage_type_TC)? "工單名稱" :
                   ((lang_type == elanguage_type_SC)? "工单名称":"work_sheet name"));
        strList.append((lang_type == elanguage_type_TC)? "異動時間" :
                    ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    }
    else{
        strList.append((lang_type == elanguage_type_TC)? "工單索引值" :
                   ((lang_type == elanguage_type_SC)? "工单索引值":"work_sheet index"));
        strList.append((lang_type == elanguage_type_TC)? "主KEY值" :
                    ((lang_type == elanguage_type_SC)? "主KEY值":"primary_id"));    
        strList.append((lang_type == elanguage_type_TC)? "全部資料" :
                    ((lang_type == elanguage_type_SC)? "全部资料":"all data"));
        strList.append((lang_type == elanguage_type_TC)? "任務名稱" :
                   ((lang_type == elanguage_type_SC)? "任务名称":"action_function_id name"));
        strList.append((lang_type == elanguage_type_TC)? "異動時間" :
                    ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    }
    ui->cbox_search_condition->addItems(strList);
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  base conrtoller area   --- modify                                      **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmdb_relateTable::parse_config_relatetb(erelatetb_type _type)
{
    parse_relatetb_base();
    //------------------
    _relatetb_type = _type ;
    QtherShow_initSet();
    //------------------
    switch(_relatetb_type){
        case erelatetb_worksheets:{
           parse_relatedb_work_sheet_main() ;
           parse_relatedb_work_sheet_items();
           formEdit_Show();
           table_dataShow();
           edit_frame_dataShow_m(); //refesh data mast_tableWidget & detail_tableWidget
        } break;
    }
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::table_dataShow()
{
    switch(_relatetb_type){
        case erelatetb_worksheets:{
           table_dataShow_work_sheet_main() ;
        } break;
    }
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::keyPressEvent(QKeyEvent *event)
{
    if(!ui->mast_tableWidget->hasFocus() && !ui->detail_tableWidget->hasFocus()) 
        return ; 
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::keyReleaseEvent(QKeyEvent *event)
{
    if(!ui->mast_tableWidget->hasFocus() && !ui->detail_tableWidget->hasFocus()) 
        return ; 

    if(ui->mast_tableWidget->hasFocus())
        tableWidget_keyRelease(ui->mast_tableWidget,event);
    else
        tableWidget_keyRelease(ui->detail_tableWidget,event);
    
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  private   --- fixed                                                    **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmdb_relateTable::tableWidget_keyRelease(QTableWidget* tableWidget,QKeyEvent *event)
{
    int row = tableWidget->currentRow();    
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    if(event->key() == Qt::Key_Up)  
    {    
        if(tableWidget->objectName() == "mast_tableWidget")
            edit_frame_dataShow_m();     
        else 
            edit_frame_dataShow_d();   
        if(row == 0){
            if(b_rowno_error_false){
                QString message = ((lang_type == elanguage_type_TC) ? "資料已是第一筆 ！" :
                                ((lang_type == elanguage_type_SC) ? "资料已是第一笔 !" : "It is already the first record !"));
                tools->dialog_formShow(message,eMessageStyle,lang_type);    
                b_rowno_error_false = false ;    
            }
            else  b_rowno_error_false = true ;            
        }  
        else  b_rowno_error_false = false ;                         
    }
    else if(event->key() == Qt::Key_Down)  
    {    
        if(tableWidget->objectName() == "mast_tableWidget")
            edit_frame_dataShow_m();     
        else 
            edit_frame_dataShow_d();  
        int count = tableWidget->rowCount();
        if(row == (count-1)){    
            if(b_rowno_error_false){   
                QString message = ((lang_type == elanguage_type_TC) ? "資料已是最後一筆 ！" :
                                ((lang_type == elanguage_type_SC) ? "资料已是最后一笔 !" : "It is already the last record !"));
                tools->dialog_formShow(message,eMessageStyle,lang_type); 
                b_rowno_error_false = false ;    
            }
            else  b_rowno_error_false = true ; 
        }
        else  b_rowno_error_false = false ;   
    }
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::set_style_sheet()
{
    labeltitle_style_enable = "QLabel{font: bold 12pt;color:Blue;}";
    labeltitle_style_disable = "QLabel{font: bold 12pt;color:Gray;}";
    label_style_enable = "QLabel{font: bold 12pt;color:Blue;}";
    label_style_disable = "QLabel{font: bold 12pt;color:Gray;}";
    
    lineedit_style_enable = "QLineEdit{font: bold 12pt;color:Blue;\
                                       background-color:yellow}";
    lineedit_style_disable = "QLineEdit{font: bold 12pt;color:Gray;\
                                        background-color:white}";
    groupbox_style_enable = "QGroupBox{font: bold 12pt;\
                                       color:blue;\
                                       border: 1px solid silver;\
                                       border-radius: 6px;\
                                       margin-top: 6px;\
                                      }\
                              QGroupBox::title {subcontrol-origin: margin; \
                                                left: 12px;\
                                                top:  -2px;\
                                                padding: 0 5px 0 5px;\
                                               }\
                              QGroupBox::indicator:unchecked {image: url(:/png/resource/tools_png/robot_001.png);\
                                               }";
      groupbox_style_disable = "QGroupBox{font: bold 14pt;\
                                         color:gray;\
                                         border: 1px solid silver;\
                                         border-radius: 6px;\
                                         margin-top: 6px;\
                                        }\
                                QGroupBox::title {subcontrol-origin: margin; \
                                                  left: 12px;\
                                                  top:  -2px;\
                                                  padding: 0 5px 0 5px;\
                                                 }\
                                QGroupBox::indicator:unchecked {image: url(:/png/resource/tools_png/robot_001.png);\
                                                 }";
    combobox_style_enable = "QComboBox{font: bold 12pt;color:Blue;\
                                       background-color:yellow}";
    combobox_style_disable = "QComboBox{font: bold 12pt;color:Gray;\
                                        background-color:white}";
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::vectors_m_clear()
{
    _fieldname_m_Vec_E.clear();
    _fieldname_m_Vec_TC.clear();
    _fieldname_m_Vec_SC.clear();
    _titlename_m_Vec_E.clear();
    _titlename_m_Vec_TC.clear();
    _titlename_m_Vec_SC.clear();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::vectors_d_clear()
{
    _fieldname_d_Vec_E.clear();
    _fieldname_d_Vec_TC.clear();
    _fieldname_d_Vec_SC.clear();
    _titlename_d_Vec_E.clear();
    _titlename_d_Vec_TC.clear();
    _titlename_d_Vec_SC.clear();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::parse_relatetb_base()
{
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    //-- caption show of operation ----------------
    ui->btn_op_add->setText((lang_type == elanguage_type_TC)? "新增" :
                            ((lang_type == elanguage_type_SC)? "新增":"new"));
    ui->btn_op_modify->setText((lang_type == elanguage_type_TC)? "修改" :
                               ((lang_type == elanguage_type_SC)? "修改":"Modify"));
    ui->btn_op_delete->setText((lang_type == elanguage_type_TC)? "删除" :
                               ((lang_type == elanguage_type_SC)? "删除":"DDelete"));
    ui->btn_op_inquire->setText((lang_type == elanguage_type_TC)? "查詢" :
                                ((lang_type == elanguage_type_SC)? "查询":"Inquire"));

    ui->btn_op_add_d->setText((lang_type == elanguage_type_TC)? "新增" :
                            ((lang_type == elanguage_type_SC)? "新增":"new"));
    ui->btn_op_modify_d->setText((lang_type == elanguage_type_TC)? "修改" :
                               ((lang_type == elanguage_type_SC)? "修改":"Modify"));
    ui->btn_op_delete_d->setText((lang_type == elanguage_type_TC)? "删除" :
                               ((lang_type == elanguage_type_SC)? "删除":"DDelete"));
    ui->btn_op_inquire_d->setText((lang_type == elanguage_type_TC)? "查詢" :
                                ((lang_type == elanguage_type_SC)? "查询":"Inquire"));

    ui->btn_confirm->setText((lang_type == elanguage_type_TC)? "確認" :
                             ((lang_type == elanguage_type_SC)? "确认":"Confirm"));
    ui->btn_cancel->setText((lang_type == elanguage_type_TC)? "取消" :
                             ((lang_type == elanguage_type_SC)? "取消":"Cancel"));
    ui->btn_close->setText((lang_type == elanguage_type_TC)? "離開" :
                             ((lang_type == elanguage_type_SC)? "离开":"Exit"));
    //--- search_frame show -----------------------
    ui->gbox_search_condition->setTitle((lang_type == elanguage_type_TC)? " 選擇搜尋欄位 " :
                                        ((lang_type == elanguage_type_SC)? " 选择搜寻栏位 ":" Select search field "));
    ui->gbox_search_region->setTitle((lang_type == elanguage_type_TC)? " 輸入搜尋範圍 " :
                                     ((lang_type == elanguage_type_SC)? " 输入搜寻范围 ":" Enter search region "));
    ui->lb_search_from->setText((lang_type == elanguage_type_TC)? "起始" :
                                ((lang_type == elanguage_type_SC)? "起始":"from"));
    ui->lb_search_to->setText((lang_type == elanguage_type_TC)? "結束" :
                                ((lang_type == elanguage_type_SC)? "结束":"to"));  
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::edit_frame_dataShow_m()
{
    QString lineedit_name ; 
    int row = ui->mast_tableWidget->currentItem()->row();    
    for(int i=0;i<_fiels_num_m;i++){
        lineedit_name = "lineEdit_mast_"+QString::number(i);  
        QLineEdit *obj_lEdit = ui->edit_mastframe->findChild<QLineEdit *>(lineedit_name);
        if(obj_lEdit){
            obj_lEdit->setText(ui->mast_tableWidget->item(row, i)->text());    
        }
    }   
    //--- refresh table item ---
    table_items_refresh(ui->lineEdit_mast_1->text().toStdString()) ;    
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::edit_table_dataShow_m()
{
    QString lineedit_name ; 
    int row = ui->mast_tableWidget->currentItem()->row();   
    ui->mast_tableWidget->setSortingEnabled(false);  
    for(int i=0;i<_fiels_num_m;i++){
        lineedit_name = "lineEdit_mast_"+QString::number(i);  
        QLineEdit *obj_lEdit = ui->edit_mastframe->findChild<QLineEdit *>(lineedit_name);
        if(obj_lEdit){
            ui->mast_tableWidget->setItem(row,i,new QTableWidgetItem(obj_lEdit->text()));    
        }
    }       
    ui->mast_tableWidget->setSortingEnabled(true);
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::edit_table_dataShow_d()
{
    QString lineedit_name ; 
    int row = ui->detail_tableWidget->currentItem()->row();   
    ui->detail_tableWidget->setSortingEnabled(false);  
    for(int i=0;i<_fiels_num_d;i++){
        lineedit_name = "lineEdit_detail_"+QString::number(i);  
        QLineEdit *obj_lEdit = ui->edit_detail_frame->findChild<QLineEdit *>(lineedit_name);
        if(obj_lEdit){
            ui->detail_tableWidget->setItem(row,i,new QTableWidgetItem(obj_lEdit->text()));    
        }
    }       
    ui->detail_tableWidget->setSortingEnabled(true);
}
//-----------------------------------------------------------------------------
int frmdb_relateTable::get_keyvalue_tablerow_m(int col_no,QString key_value)
{
    int iRet = -1 ;
    QList<QTableWidgetItem *> LTempTable =ui->mast_tableWidget->findItems(key_value,Qt::MatchEndsWith);
    for(int i=0;i<LTempTable.count();i++){
        int row = LTempTable[i]->row();
        if(ui->mast_tableWidget->item(row, col_no)->text()==key_value){
            iRet = row ; break;   
        }
    }
    return iRet ; 
} 
//-----------------------------------------------------------------------------
int frmdb_relateTable::get_keyvalue_tablerow_d(int col_no,QString key_value)
{
    int iRet = -1 ;
    QList<QTableWidgetItem *> LTempTable =ui->detail_tableWidget->findItems(key_value,Qt::MatchEndsWith);
    for(int i=0;i<LTempTable.count();i++){
        int row = LTempTable[i]->row();
        if(ui->detail_tableWidget->item(row, col_no)->text()==key_value){
            iRet = row ; break;   
        }
    }
    return iRet ; 
} 
//-----------------------------------------------------------------------------
bool frmdb_relateTable::dbtable_move_next_m()
{
    int row = ui->mast_tableWidget->currentRow();
    int count = ui->mast_tableWidget->rowCount();
    bool bRet = (row < count) ;
    if(bRet){
        edit_frame_dataShow_m();       
    }

    return bRet ;
}
//-----------------------------------------------------------------------------
bool frmdb_relateTable::dbtable_move_next_d()
{
    int row = ui->detail_tableWidget->currentRow();
    int count = ui->detail_tableWidget->rowCount();
    bool bRet = (row < count) ;
    if(bRet){
        edit_frame_dataShow_d();       
    }

    return bRet ;
}
//-----------------------------------------------------------------------------
bool frmdb_relateTable::dbtable_move_previous_m()
{
    int row = ui->mast_tableWidget->currentRow();
    bool bRet = (row >= 0) ;
    if(bRet){
        edit_frame_dataShow_m();       
    }

    return bRet ;
}
//-----------------------------------------------------------------------------
bool frmdb_relateTable::dbtable_move_previous_d()
{
    int row = ui->detail_tableWidget->currentRow();
    bool bRet = (row >= 0) ;
    if(bRet){
        edit_frame_dataShow_d();       
    }

    return bRet ;
}
//-----------------------------------------------------------------------------
std::string frmdb_relateTable::get_pose2d_base_name_by_uniquecode(std::string uniquecode)
{
    std::string sRet = "";
    if(!uniquecode.empty()){
        db_tb_search_type search_type = edb_tb_search_unique_code ;   
        dynamic_targer_pos2d_parameters_search_type opt_search_type = edynamic_targer_pos2d_parameters_search_base_name ;  // no use
        std::string search_param = uniquecode ;
        emit _base_controlmodel->targer_pos2d_parameters_query_Changed(search_type,opt_search_type,search_param);   

        vector<ptr_targer_pos2d_parameters> result = _base_controlmodel->get_targer_pos2d_parameters_results();
        if(result.size()>0)
            sRet = result[0]->base_name ;
    }

    return sRet ;
}
//-----------------------------------------------------------------------------
std::string frmdb_relateTable::get_actionfunction_base_name_by_uniquecode(std::string uniquecode)
{
    std::string sRet = "";
    if(!uniquecode.empty()){
        db_tb_search_type search_type = edb_tb_search_unique_code ;   
        dynamic_action_function_parameters_search_type opt_search_type = edynamic_action_function_parameters_search_base_name ;  // no use
        std::string search_param = uniquecode ;
        emit _base_controlmodel->action_function_parameters_query_Changed(search_type,opt_search_type,search_param);   

        vector<ptr_action_function_parameters> result = _base_controlmodel->get_action_function_parameters_results();
        if(result.size()>0)
            sRet = result[0]->base_name ;
    }

    return sRet ;
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::QtherShow_get_pose2d_data()
{
    //-- get all data from targer_pos2d_parameters_table ---
    db_tb_search_type search_type = edb_tb_search_all ;
    dynamic_targer_pos2d_parameters_search_type opt_search_type = edynamic_targer_pos2d_parameters_search_base_name ;
    std::string search_param = "all" ;
    emit _base_controlmodel->targer_pos2d_parameters_query_Changed(search_type,opt_search_type,search_param);   
    //------------
    //ui->tableWidget->setSortingEnabled(false);
    vector<ptr_targer_pos2d_parameters> result = _base_controlmodel->get_targer_pos2d_parameters_results();
    //----------------------------
    ui->cbox_dynamic_Key_0_id->clear();
    QStringList strList;
    int isize = result.size();
    for(int i=0;i<isize;i++){
        std::string data = result[i]->unique_code + "," + result[i]->base_name ;
        strList.append(QString::fromStdString(data));
    }
    ui->cbox_dynamic_Key_0_id->addItems(strList);

}
//-----------------------------------------------------------------------------
void frmdb_relateTable::QtherShow_get_action_function_data()
{
    //-- get all data from targer_pos2d_parameters_table ---
    db_tb_search_type search_type = edb_tb_search_all ;
    dynamic_action_function_parameters_search_type opt_search_type = edynamic_action_function_parameters_search_base_name ;
    std::string search_param = "all" ;
    emit _base_controlmodel->action_function_parameters_query_Changed(search_type,opt_search_type,search_param);   
    //------------
    //ui->tableWidget->setSortingEnabled(false);
    vector<ptr_action_function_parameters> result = _base_controlmodel->get_action_function_parameters_results();
    //----------------------------
    ui->cbox_dynamic_Key_1_id->clear();
    QStringList strList;
    int isize = result.size();
    for(int i=0;i<isize;i++){
        std::string data = result[i]->unique_code + "," + result[i]->base_name ;
        strList.append(QString::fromStdString(data));
    }
    ui->cbox_dynamic_Key_1_id->addItems(strList);
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  private   --- modify                                                   **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmdb_relateTable::edit_frame_dataShow_d()
{
    QString lineedit_name ; 

    int row = ui->detail_tableWidget->currentItem()->row(); 
    for(int i=0;i<_fiels_num_d;i++){
        lineedit_name = "lineEdit_detail_"+QString::number(i);  
        QLineEdit *obj_lEdit = ui->edit_detail_frame->findChild<QLineEdit *>(lineedit_name);
        if(obj_lEdit){
            obj_lEdit->setText(ui->detail_tableWidget->item(row, i)->text());    
        }
    }  
    //-- Show option data ----
    switch(_relatetb_type){
        case erelatetb_worksheets:{
            std::string basename = get_pose2d_base_name_by_uniquecode(ui->lineEdit_detail_5->text().toStdString()) ;
            ui->lineEdit_dynamic_Key_0_name->setText(QString::fromStdString(basename));
            
            basename = get_actionfunction_base_name_by_uniquecode(ui->lineEdit_detail_6->text().toStdString());
            ui->lineEdit_dynamic_Key_1_name->setText(QString::fromStdString(basename));
        } break ;
    }
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::QtherShow_initSet()
{
    switch(_relatetb_type){
        case erelatetb_worksheets:{
            ui->lineEdit_detail_5->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);  
            ui->cbox_dynamic_Key_0_id->setParent(ui->lineEdit_detail_5->parentWidget());    
            ui->cbox_dynamic_Key_0_id->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Fixed);  
            ui->items_h_layout_5->addWidget(ui->cbox_dynamic_Key_0_id);
            ui->lineEdit_dynamic_Key_0_name->setParent(ui->lineEdit_detail_5->parentWidget());    
            ui->lineEdit_dynamic_Key_0_name->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Fixed);  
            ui->items_h_layout_5->addWidget(ui->lineEdit_dynamic_Key_0_name);

            ui->lineEdit_detail_6->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);  
            ui->cbox_dynamic_Key_1_id->setParent(ui->lineEdit_detail_6->parentWidget());    
            ui->cbox_dynamic_Key_1_id->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Fixed);  
            ui->items_h_layout_6->addWidget(ui->cbox_dynamic_Key_1_id);
            ui->lineEdit_dynamic_Key_1_name->setParent(ui->lineEdit_detail_6->parentWidget());    
            ui->lineEdit_dynamic_Key_1_name->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Fixed);  
            ui->items_h_layout_6->addWidget(ui->lineEdit_dynamic_Key_1_name);
            //-----------------
            QtherShow_get_pose2d_data();  
            QtherShow_get_action_function_data();
        } break ;   
    } 
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::formEdit_QtherShow()
{  
    switch(_relatetb_type){
        case erelatetb_worksheets:{
            ui->lb_mast_field_0->setEnabled(false) ; ui->lb_mast_field_0->setStyleSheet(label_style_disable) ;
            ui->lineEdit_mast_0->setEnabled(false) ; ui->lineEdit_mast_0->setStyleSheet(lineedit_style_disable) ;
            ui->lb_mast_field_5->setEnabled(false) ; ui->lb_mast_field_5->setStyleSheet(label_style_disable) ;
            ui->lineEdit_mast_5->setEnabled(false) ; ui->lineEdit_mast_5->setStyleSheet(lineedit_style_disable) ;

            ui->lb_detail_field_0->setEnabled(false) ; ui->lb_detail_field_0->setStyleSheet(label_style_disable) ;
            ui->lineEdit_detail_0->setEnabled(false) ; ui->lineEdit_detail_0->setStyleSheet(lineedit_style_disable) ;
            ui->lb_detail_field_1->setEnabled(false) ; ui->lb_detail_field_1->setStyleSheet(label_style_disable) ;
            ui->lineEdit_detail_1->setEnabled(false) ; ui->lineEdit_detail_1->setStyleSheet(lineedit_style_disable) ;
            ui->lb_detail_field_9->setEnabled(false) ; ui->lb_detail_field_9->setStyleSheet(label_style_disable) ;
            ui->lineEdit_detail_9->setEnabled(false) ; ui->lineEdit_detail_9->setStyleSheet(lineedit_style_disable) ;
            bool bVisile = (_table_d_OP_type == db_table_OP_Add) || (_table_d_OP_type == db_table_OP_Modify) ;

            ui->cbox_dynamic_Key_0_id->setStyleSheet(combobox_style_enable) ; 
            ui->lineEdit_dynamic_Key_0_name->setStyleSheet(lineedit_style_disable); 
            ui->cbox_dynamic_Key_1_id->setStyleSheet(combobox_style_enable) ; 
            ui->lineEdit_dynamic_Key_1_name->setStyleSheet(lineedit_style_disable); 

            if(bVisile){  
                std::string search_data_1 = ui->lineEdit_detail_5->text().toStdString();
                std::string search_data_2 = ui->lineEdit_dynamic_Key_0_name->text().toStdString();
                std::string search_data = search_data_1 + (search_data_2.empty() ? "" : ","+search_data_2);
                ui->cbox_dynamic_Key_0_id->setCurrentIndex(ui->cbox_dynamic_Key_0_id->findText(QString::fromStdString(search_data)));

                search_data_1 = ui->lineEdit_detail_6->text().toStdString();
                search_data_2 = ui->lineEdit_dynamic_Key_1_name->text().toStdString();
                search_data = search_data_1 + (search_data_2.empty() ? "" : ","+search_data_2);
                ui->cbox_dynamic_Key_1_id->setCurrentIndex(ui->cbox_dynamic_Key_1_id->findText(QString::fromStdString(search_data)));
                //--------------

                //--------------
                ui->cbox_dynamic_Key_0_id->setVisible(true); 
                ui->lineEdit_dynamic_Key_0_name->setVisible(false); 
                ui->lineEdit_detail_5->setVisible(false);

                ui->cbox_dynamic_Key_1_id->setVisible(true); 
                ui->lineEdit_dynamic_Key_1_name->setVisible(false); 
                ui->lineEdit_detail_6->setVisible(false);
            }
            else{
                ui->lineEdit_detail_5->setVisible(true); 
                ui->lineEdit_dynamic_Key_0_name->setVisible(true); 
                ui->cbox_dynamic_Key_0_id->setVisible(false); 

                ui->lineEdit_detail_6->setVisible(true); 
                ui->lineEdit_dynamic_Key_1_name->setVisible(true); 
                ui->cbox_dynamic_Key_1_id->setVisible(false); 
            }
        } break;
    }
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::table_sorttype_show_m()
{
    switch(_relatetb_type){
        case erelatetb_worksheets:{
            if(_table_m_sorttype == erelatetb_sort_code)
                ui->mast_tableWidget->sortItems(1,Qt::AscendingOrder);
            else if(_table_m_sorttype == erelatetb_sort_name)
                ui->mast_tableWidget->sortItems(2,Qt::AscendingOrder);    
            else if(_table_m_sorttype == erelatetb_sort_update)
                ui->mast_tableWidget->sortItems(5,Qt::AscendingOrder); 
        } break;
    }
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::table_sorttype_show_d()
{
    switch(_relatetb_type){
        case erelatetb_worksheets:{
            if(_table_d_sorttype == erelatetb_sort_item_mission)
                ui->detail_tableWidget->sortItems(2,Qt::AscendingOrder);
            else if(_table_d_sorttype == erelatetb_sort_item_creat)
                ui->detail_tableWidget->sortItems(3,Qt::AscendingOrder);
            else if(_table_d_sorttype == erelatetb_sort_item_exec_ser)
                ui->detail_tableWidget->sortItems(4,Qt::AscendingOrder);
            else if(_table_d_sorttype == erelatetb_sort_item_pose)
                ui->detail_tableWidget->sortItems(5,Qt::AscendingOrder);    
            else if(_table_d_sorttype == erelatetb_sort_item_function)
                ui->detail_tableWidget->sortItems(6,Qt::AscendingOrder);
            else if(_table_d_sorttype == erelatetb_sort_item_update)
                ui->detail_tableWidget->sortItems(9,Qt::AscendingOrder);  
        } break;
    }
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  GUI Component : trigger .....  modify                                  **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmdb_relateTable::on_btn_confirm_clicked()
{    
    //-- Search Confirm ------
    if(ui->search_frame->isVisible()){
        btn_search_confirm();
        return ;
    }
    //-- Normal Confirm ------
    //-- todo database table process ---
    db_tb_error_type _error_type = edb_tb_err_type_none ;
    if(_table_m_OP_type != db_table_OP_None){
        if((_table_m_OP_type == db_table_OP_Add) || (_table_m_OP_type == db_table_OP_Modify)){    
            if(_relatetb_type == erelatetb_worksheets)
                update_procedure_work_sheet_main(_error_type);
        }
        else if(_table_m_OP_type == db_table_OP_Delete){
            if(_relatetb_type == erelatetb_worksheets)
                delete_procedure_work_sheet_main(_error_type);
        }
        edit_frame_dataShow_m();
    }

    if(_table_d_OP_type != db_table_OP_None){
        if((_table_d_OP_type == db_table_OP_Add) || (_table_d_OP_type == db_table_OP_Modify)){    
            if(_relatetb_type == erelatetb_worksheets)
                update_procedure_work_sheet_items(_error_type);                
        }
        else if(_table_d_OP_type == db_table_OP_Delete){
            if(_relatetb_type == erelatetb_worksheets)
                delete_procedure_work_sheet_items(_error_type);
        }

        if(_error_type == edb_tb_err_type_none){
            int rowcnt = ui->detail_tableWidget->rowCount();
            if(rowcnt==1 && ui->lineEdit_detail_1->text().isEmpty())
                rowcnt = 0 ;    
            refresh_procedure_work_sheet_main_items_num(rowcnt);
        }
        edit_frame_dataShow_d();
    }

    //----------------------
    if(_error_type != edb_tb_err_type_none){
        qt_generaltools* tools = qt_generaltools::getInstance();
        elanguage_type lang_type = tools->getlanguage_type();
        QString message = ((lang_type == elanguage_type_TC) ? "錯誤訊息：" :
                           ((lang_type == elanguage_type_SC) ? "错误讯息：" : "Error message :"));
        message += QString::fromStdString(_controlmodel->get_error_desc((int)lang_type,_error_type)) ;  
        tools->dialog_formShow(message,eMessageStyle,lang_type);    
        return ;
    }
    //------------------
    ui->btn_cancel->click();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::btn_search_confirm()
{
    if(ui->edit_search_from->text().isEmpty()){
        qt_generaltools* tools = qt_generaltools::getInstance();
        elanguage_type lang_type = tools->getlanguage_type();
        QString message = ((lang_type == elanguage_type_TC) ? "參數資料錯誤！" :
                           ((lang_type == elanguage_type_SC) ? "参数资料错误！" : "Parameters Error !"));

        tools->dialog_formShow(message,eMessageStyle,lang_type);    
        return ;
    }
    else{
        db_tb_error_type _error_type ;
        switch(_relatetb_type){
            case erelatetb_worksheets:{
                if(_table_m_OP_type == db_table_OP_Inquire)
                    search_confirm_work_sheet_main(_error_type) ;
                else
                    search_confirm_work_sheet_items(_error_type) ;
                
                } break;
        }
        //----------------
        if(_error_type == edb_tb_err_type_none){
            switch(_relatetb_type){
                case erelatetb_worksheets:{
                    if(_table_m_OP_type == db_table_OP_Inquire)
                        table_dataShow_work_sheet_main();
                    else{
                        table_dataShow_work_sheet_items();
                        }
                        
                    } break;
            }
        }   
        else{
            qt_generaltools* tools = qt_generaltools::getInstance();
            elanguage_type lang_type = tools->getlanguage_type();
            QString message = ((lang_type == elanguage_type_TC) ? "參數資料錯誤！" :
                            ((lang_type == elanguage_type_SC) ? "参数资料错误！" : "Parameters Error !"));

            tools->dialog_formShow(message,eMessageStyle,lang_type);    
            return ;
        }
    }
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::btn_search_cancel()
{
    db_tb_error_type _error_type ;
    switch(_relatetb_type){
        case erelatetb_worksheets:{
            if(_table_m_OP_type == db_table_OP_Inquire)
                search_cancel_work_sheet_main(_error_type) ;
            else
                search_cancel_work_sheet_items(_error_type) ;
            } break;
    }

    if(_error_type == edb_tb_err_type_none){
        switch(_relatetb_type){
            case erelatetb_worksheets:{
                if(_table_m_OP_type == db_table_OP_Inquire)
                    table_dataShow_work_sheet_main();
                else{
                    table_dataShow_work_sheet_items() ;
                    }
                } break;
        }
    }   
    //---------------------------
    _table_m_OP_type = db_table_OP_None ;   
    formEdit_Show(); 
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::table_items_refresh(std::string filter_cond)
{
    switch(_relatetb_type){
        case erelatetb_worksheets:{
            work_sheet_items_refresh(filter_cond)  ;  
        } break ;
    } 
}

//-----------------------------------------------------------------------------
void frmdb_relateTable::on_cbox_dynamic_Key_0_id_activated(int index)
{
    switch(_relatetb_type){
        case erelatetb_worksheets:{
            std::string data = ui->cbox_dynamic_Key_0_id->currentText().toStdString(); 
            int found = data.find(",");
            if (found<0){
                ui->lineEdit_detail_5->setText(QString::fromStdString(data));
            }
            else{
                ui->lineEdit_detail_5->setText(QString::fromStdString(data.substr(0,found)));
            }
        } break ;
    }
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::on_cbox_dynamic_Key_1_id_activated(int index)
{
    switch(_relatetb_type){
        case erelatetb_worksheets:{
            std::string data = ui->cbox_dynamic_Key_1_id->currentText().toStdString(); 
            int found = data.find(",");
            if (found<0){        
                ui->lineEdit_detail_6->setText(QString::fromStdString(data));
            }
            else{
                ui->lineEdit_detail_6->setText(QString::fromStdString(data.substr(0,found)));
            }
        } break ;
    }
    
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  GUI Component : trigger .....  Fixed                                   **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmdb_relateTable::on_btn_close_clicked()
{
    emit _app_mode->frm_main_enable_Changed(true);
    close();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::on_btn_cancel_clicked()
{
    //-- Search Cancel ------
    if(ui->search_frame->isVisible()){
        btn_search_cancel();
        return ;
    }
    //-- Normal Cancel ------
    int actrow ;
    if(_table_m_OP_type != db_table_OP_None){
        if(_table_m_OP_type == db_table_OP_Add){            
            int row = ui->mast_tableWidget->currentRow();
            if(ui->mast_tableWidget->rowCount() > 1)  
                ui->mast_tableWidget->removeRow(row);//清除已有的行列
            int row_cnt = ui->mast_tableWidget->rowCount();        
            if(row_cnt >0){
                ui->mast_tableWidget->selectRow(last_table_rowno_m);
                ui->mast_tableWidget->setFocus();                  
            }
            else{
                ui->mast_tableWidget->setRowCount(1);  
                ui->mast_tableWidget->selectRow(0);  
            }
        }    
        //----------------------- 
        action_unique_code = ui->lineEdit_mast_0->text();    
        ui->mast_tableWidget->setSortingEnabled(true);
        int act_row = get_keyvalue_tablerow_m(0,action_unique_code);
        if(act_row < 0){ 
            act_row = get_keyvalue_tablerow_m(0,last_unique_code_m);
            if(act_row < 0)
                act_row = 0 ;
        }
        ui->mast_tableWidget->setFocus();
        ui->mast_tableWidget->selectRow(act_row);
        //-----------------------
        _table_m_OP_type = db_table_OP_None ;
        edit_frame_dataShow_m();
    }

    if(_table_d_OP_type != db_table_OP_None){
    
        if(_table_d_OP_type == db_table_OP_Add){
            int row = ui->detail_tableWidget->currentRow(); 
            if(ui->detail_tableWidget->rowCount() > 1)  
                ui->detail_tableWidget->removeRow(row);//清除已有的行列
            int row_cnt = ui->detail_tableWidget->rowCount();        
            if(row_cnt >0){
                ui->detail_tableWidget->selectRow(last_table_rowno_d);
                ui->detail_tableWidget->setFocus();          
            }
            else{
                ui->detail_tableWidget->setRowCount(1);  
                ui->detail_tableWidget->selectRow(0);       
            }
        }    
        //-----------------------         
        //action_unique_code = ui->lineEdit_detail_1->text();    
        action_unique_code = ui->lineEdit_detail_0->text();
        ui->detail_tableWidget->setSortingEnabled(true);
        int act_row = get_keyvalue_tablerow_d(0,action_unique_code);
        if(act_row < 0){ 
            act_row = get_keyvalue_tablerow_d(0,last_unique_code_d);
            if(act_row < 0)
                act_row = 0 ;
        }
        
        ui->detail_tableWidget->setFocus();
        ui->detail_tableWidget->selectRow(act_row);
        //-----------------------
        _table_d_OP_type = db_table_OP_None ;
        edit_frame_dataShow_d();
    }

    formEdit_Show();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::on_btn_op_add_clicked()
{
    last_table_rowno_m = ui->mast_tableWidget->currentRow(); 
    last_unique_code_m = ui->lineEdit_mast_1->text();
    //----------------------
    _table_m_OP_type = db_table_OP_Add ;
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    QString type_name = ((lang_type == elanguage_type_TC) ? "新增" :
                         ((lang_type == elanguage_type_SC) ? "新增" : "Add"));
    ui->lb_table_m_edittype->setText(type_name);
    //-- add a blank record to tableWidge and refresh editfram data ---
    ui->mast_tableWidget->setSortingEnabled(false);  

    int act_row ;
    if((ui->mast_tableWidget->rowCount() == 1) && (ui->lineEdit_mast_1->text().isEmpty()))
        act_row = 1 ; 
    else    
        act_row = ui->mast_tableWidget->rowCount()+1 ;
    ui->mast_tableWidget->setRowCount(act_row);
    ui->mast_tableWidget->selectRow(act_row-1);    
    
    for(int i=0;i<_fiels_num_m;i++){
            ui->mast_tableWidget->setItem(act_row-1,i,new QTableWidgetItem(QString::fromStdString("")));   // (row,col) 
        }
    //ui->tableWidget->setSortingEnabled(true);    
    ui->mast_tableWidget->setFocus();    
    //----------------------
    edit_frame_dataShow_m();
    ui->lineEdit_mast_3->setText(tools->get_updatetime_data(tools->get_unique_code()));
    //-------------     
    formEdit_Show();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::on_btn_op_modify_clicked()
{
    last_table_rowno_m = ui->mast_tableWidget->currentRow();  
    last_unique_code_m = ui->lineEdit_mast_1->text();
    //----------------------
    _table_m_OP_type = db_table_OP_Modify ;
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    QString type_name = ((lang_type == elanguage_type_TC) ? "修改" :
                         ((lang_type == elanguage_type_SC) ? "修改" : "Modify"));
    ui->lb_table_m_edittype->setText(type_name);
    //-------------     
    formEdit_Show();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::on_btn_op_delete_clicked()
{
    int row = ui->mast_tableWidget->currentRow(); 
    QString _primary_id = ui->mast_tableWidget->item(row,1)->text();

    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    QString delete_msg = (lang_type == elanguage_type_TC)? "删除此筆資料(" :
                         ((lang_type == elanguage_type_SC)? "删除此笔资料(":"Delete this record(");
    delete_msg += _primary_id+") ?" ;

    bool bRet = tools->dialog_formShow(delete_msg,eConfirmStyle,tools->getlanguage_type());
    if(bRet){
        qt_generaltools* tools = qt_generaltools::getInstance();
        elanguage_type lang_type = tools->getlanguage_type();
        QString type_name = ((lang_type == elanguage_type_TC) ? "删除" :
                            ((lang_type == elanguage_type_SC) ? "删除" : "Delete"));
        ui->lb_table_m_edittype->setText(type_name);
        //---------------------------------
        last_table_rowno_m = ui->mast_tableWidget->currentRow();  
        _table_m_OP_type = db_table_OP_Delete ;   
        formEdit_Show(); 
    }
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::on_btn_op_inquire_clicked()
{
    _table_m_OP_type = db_table_OP_Inquire ;   
    formEdit_Show();    
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::on_mast_tableWidget_clicked(const QModelIndex &index)
{
    if (index.isValid()) {     
        edit_frame_dataShow_m();     
    }   
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::on_cbox_sort_cond_mast_currentIndexChanged(int index)
{
    _table_m_sorttype = erelatetb_sorttype(index) ;
    table_sorttype_show_m();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::on_btn_op_add_d_clicked()
{
    last_table_rowno_d = ui->detail_tableWidget->currentRow(); 
    last_unique_code_d = ui->lineEdit_detail_1->text();
    //----------------------
    _table_d_OP_type = db_table_OP_Add ;
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    QString type_name = ((lang_type == elanguage_type_TC) ? "新增" :
                         ((lang_type == elanguage_type_SC) ? "新增" : "Add"));
    ui->lb_table_d_edittype->setText(type_name);
    //-- add a blank record to tableWidge and refresh editfram data ---
    ui->detail_tableWidget->setSortingEnabled(false);  

    int act_row ;
    if((ui->detail_tableWidget->rowCount() == 1) && (ui->lineEdit_detail_1->text().isEmpty()))
        act_row = 1 ; 
    else    
        act_row = ui->detail_tableWidget->rowCount()+1 ;
    ui->detail_tableWidget->setRowCount(act_row);
    ui->detail_tableWidget->selectRow(act_row-1);  
    
    for(int i=0;i<_fiels_num_d;i++){
            ui->detail_tableWidget->setItem(act_row-1,i,new QTableWidgetItem(QString::fromStdString("")));   // (row,col) 
        }
    //ui->tableWidget->setSortingEnabled(true);    
    ui->detail_tableWidget->setFocus();    
    //----------------------
    edit_frame_dataShow_d();
    ui->lineEdit_detail_1->setText(ui->lineEdit_mast_1->text());
    ui->lineEdit_detail_4->setText(tools->get_updatetime_data(tools->get_unique_code()));
    //-------------     
    formEdit_Show();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::on_btn_op_modify_d_clicked()
{
    last_table_rowno_d = ui->detail_tableWidget->currentRow();  
    last_unique_code_d = ui->lineEdit_detail_0->text();
    //----------------------
    _table_d_OP_type = db_table_OP_Modify ;
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    QString type_name = ((lang_type == elanguage_type_TC) ? "修改" :
                         ((lang_type == elanguage_type_SC) ? "修改" : "Modify"));
    ui->lb_table_d_edittype->setText(type_name);
    //-------------     
    formEdit_Show();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::on_btn_op_delete_d_clicked()
{
    int row = ui->detail_tableWidget->currentRow(); 
    //QString _primary_id = ui->detail_tableWidget->item(row,1)->text();
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    QString delete_msg = (lang_type == elanguage_type_TC)? "删除此筆資料\n(" :
                         ((lang_type == elanguage_type_SC)? "删除此笔资料\n(":"Delete this record(");
    delete_msg += ui->detail_tableWidget->item(row,2)->text() + "/" + ui->detail_tableWidget->item(row,1)->text()+ "/"+
                  ui->detail_tableWidget->item(row,0)->text()+") ?" ;

    bool bRet = tools->dialog_formShow(delete_msg,eConfirmStyle,tools->getlanguage_type());
    if(bRet){
        qt_generaltools* tools = qt_generaltools::getInstance();
        elanguage_type lang_type = tools->getlanguage_type();
        QString type_name = ((lang_type == elanguage_type_TC) ? "删除" :
                            ((lang_type == elanguage_type_SC) ? "删除" : "Delete"));
        ui->lb_table_d_edittype->setText(type_name);
        //---------------------------------
        last_table_rowno_d = ui->detail_tableWidget->currentRow();  
        _table_d_OP_type = db_table_OP_Delete ;   
        formEdit_Show(); 
    }
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::on_detail_tableWidget_clicked(const QModelIndex &index)
{
    if (index.isValid()) {     
        edit_frame_dataShow_d();     
    }   
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::on_cbox_sort_cond_detail_currentIndexChanged(int index)
{
    _table_d_sorttype = erelatetb_sort_item_type(index) ;
    table_sorttype_show_d();
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**  table function : work_sheet_main                                      **
//*****************************************************************************
//-----------------------------------------------------------------------------
void frmdb_relateTable::parse_relatedb_work_sheet_main()
{
    vectors_m_clear();

    config_filename = QApplication::applicationDirPath()+"/config/config.cfg";
    QSettings config_set(config_filename,QSettings::IniFormat);
    config_set.setIniCodec("UTF-8");
    //-- table field number ----
    int field_num = config_set.value("work_sheet_main/field_num",-1).toInt();
    if(field_num == -1){
        config_set.setValue("work_sheet_main/field_num",6);
        field_num = config_set.value("work_sheet_main/field_num").toInt();
    }
    _fiels_num_m = field_num ;

    //-- groupbox title ----
    QString prefix_key = "work_sheet_main/tablelist";
    QString tag_value = "";
    QString tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "work_sheet_main parameters manager list" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "工單頭檔 表列" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "工单头档 表列" ; }
        QString tablelist = config_set.value(tag_key,"").toString();
        if(tablelist.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablelist = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_m_Vec_E.append(tablelist); }
        else if(i==1){ _titlename_m_Vec_TC.append(tablelist); }
        else if(i==2){ _titlename_m_Vec_SC.append(tablelist); }

    }
    //-- tablename title ----
    prefix_key = "work_sheet_main/tablename";
    tag_value = "";
    tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "table name:work_sheet_main" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "資料表名稱:work_sheet_main" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "资料表名称:work_sheet_main" ; }
        QString tablename = config_set.value(tag_key,"").toString();
        if(tablename.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablename = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_m_Vec_E.append(tablename); }
        else if(i==1){ _titlename_m_Vec_TC.append(tablename); }
        else if(i==2){ _titlename_m_Vec_SC.append(tablename); }

    }
    //--- field title set ----
    QString key_value[3]={"","",""};

    for(int i=0;i<_fiels_num_m;i++){
        prefix_key = "work_sheet_main/fieldname_"+ QString::number(i);
        if(i==0){key_value[0]="primary_id";key_value[1]="主KEY值";key_value[2]="主KEY值";}
        else if(i==1){key_value[0]="work_sheet index";key_value[1]="工單索引值";key_value[2]="工单索引值";}
        else if(i==2){key_value[0]="work_sheet name";key_value[1]="工單名稱";key_value[2]="工单名称";}
        else if(i==3){key_value[0]="occur_time";key_value[1]="建立時間";key_value[2]="建立时间";}
        else if(i==4){key_value[0]="workitems_num";key_value[1]="工單細項總數";key_value[2]="工单细项总数";}
        else if(i==5){key_value[0]="update_time";key_value[1]="異動時間";key_value[2]="异动时间";}

        for(int j=0;j<3;j++){
            if(j==0){ tag_key = prefix_key+"_E" ; tag_value = key_value[0];}
            else if(j==1){ tag_key = prefix_key+"_TC" ; tag_value = key_value[1];}
            else if(j==2){ tag_key = prefix_key+"_SC" ; tag_value = key_value[2];}

            QString fieldname = config_set.value(tag_key,"").toString();
            if(fieldname.isEmpty()){
                config_set.setValue(tag_key,tag_value);
                fieldname = config_set.value(tag_key).toString();
            }
            if(j==0){ _fieldname_m_Vec_E.append(fieldname); }
            else if(j==1){ _fieldname_m_Vec_TC.append(fieldname); }
            else if(j==2){ _fieldname_m_Vec_SC.append(fieldname); }
        }
    }    
    //--- sort_frame show -----------------------
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    ui->cbox_sort_cond_mast->clear();
    QStringList strList;    
    ui->lb_sorttitle_mast->setText((lang_type == elanguage_type_TC)? "排序欄位" :
                                   ((lang_type == elanguage_type_SC)? "排序栏位":"Sort by"));

    strList.append((lang_type == elanguage_type_TC)? "工單索引值" :
                   ((lang_type == elanguage_type_SC)? "工单索引值":"work_sheet index"));    
    strList.append((lang_type == elanguage_type_TC)? "工單名稱" :
                   ((lang_type == elanguage_type_SC)? "工单名称":"work_sheet name"));    
    strList.append((lang_type == elanguage_type_TC)? "異動時間" :
                   ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    ui->cbox_sort_cond_mast->addItems(strList);   
    //-------------------------------------------
    form_table_type_show_m(); 
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::table_dataShow_work_sheet_main()
{
    ui->mast_tableWidget->setSortingEnabled(false);
    //----------------------------
    vector<ptr_work_sheet_main> result = _controlmodel->get_work_sheet_main_results();
    int isize = result.size();
    ui->mast_tableWidget->setSortingEnabled(false);
    if(isize == 0){
        ui->mast_tableWidget->setRowCount(1) ; 
        for(int i=0;i<_fiels_num_m;i++){
            ui->mast_tableWidget->setItem(0,i,new QTableWidgetItem(""));   // (row,col) 
        }
    }
    else{
        ui->mast_tableWidget->setRowCount(isize) ; 
        for(int i=0;i<isize;i++){
            ui->mast_tableWidget->setItem(i,0,new QTableWidgetItem(QString::fromStdString(result[i]->primary_id)));   // (row,col) 
            ui->mast_tableWidget->setItem(i,1,new QTableWidgetItem(QString::fromStdString(result[i]->unique_code)));   // (row,col) 
            ui->mast_tableWidget->setItem(i,2,new QTableWidgetItem(QString::fromStdString(result[i]->base_name)));   // (row,col) 
            ui->mast_tableWidget->setItem(i,3,new QTableWidgetItem(QString::fromStdString(result[i]->occur_time)));   // (row,col) 
            ui->mast_tableWidget->setItem(i,4,new QTableWidgetItem(QString::number(result[i]->workitems_num)));   // (row,col) 
            ui->mast_tableWidget->setItem(i,5,new QTableWidgetItem(QString::fromStdString(result[i]->update_time)));   // (row,col) 
        }          
    }
    ui->mast_tableWidget->setSortingEnabled(true);
    //-------------------------
    table_sorttype_show_m();
    //-- set currentItem is first item and show its detail data ---
    ui->mast_tableWidget->selectRow(0);
    edit_frame_dataShow_m();
    //--- execute work_sheet_items -----
    db_tb_search_type search_type = edb_tb_search_primary_id ;
    dynamic_work_sheet_items_search_type opt_search_type = edynamic_work_sheet_items_search_base_name ;
    std::string search_param = ui->lineEdit_mast_1->text().toStdString()+","+ui->lineEdit_mast_1->text().toStdString();
    emit _controlmodel->work_sheet_items_query_Changed(search_type,opt_search_type,search_param);   

    table_dataShow_work_sheet_items();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::refresh_procedure_work_sheet_main_items_num(int item_num)
{ 
    ptr_work_sheet_main _data = boost::make_shared<type_work_sheet_main>();
    _data->primary_id = ui->lineEdit_mast_0->text().toStdString();
    _data->unique_code = ui->lineEdit_mast_1->text().toStdString();
    _data->base_name = ui->lineEdit_mast_2->text().toStdString();
    _data->occur_time = ui->lineEdit_mast_3->text().toStdString();
    _data->workitems_num = item_num;
    _data->update_time = ui->lineEdit_mast_5->text().toStdString();

    db_tb_edit_type _edit_type = edb_tb_edit_modify ; 
    emit _controlmodel->work_sheet_main_update_Changed(_edit_type,_data);

    db_tb_error_type _error_type = _controlmodel->get_work_sheet_main_error_type();
    if(_error_type == edb_tb_err_type_none){
        std::string _primary_code,_updatetime ;
        _controlmodel->get_work_sheet_main_req_updated(_primary_code,_updatetime); 
        ui->lineEdit_mast_0->setText(QString::fromStdString(_primary_code));
        ui->lineEdit_mast_5->setText(QString::fromStdString(_updatetime));
        ui->lineEdit_mast_4->setText(QString::number(item_num));
        edit_table_dataShow_m();
        //_table_m_OP_type = db_table_OP_None ;
        //edit_frame_dataShow_m();    
    }
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::update_procedure_work_sheet_main(db_tb_error_type &_error_type)
{ 
    ptr_work_sheet_main _data = boost::make_shared<type_work_sheet_main>();
    _data->primary_id = ui->lineEdit_mast_0->text().toStdString();
    _data->unique_code = ui->lineEdit_mast_1->text().toStdString();
    _data->base_name = ui->lineEdit_mast_2->text().toStdString();
    _data->occur_time = ui->lineEdit_mast_3->text().toStdString();
    _data->workitems_num = ui->lineEdit_mast_4->text().toInt();
    _data->update_time = ui->lineEdit_mast_5->text().toStdString();

    db_tb_edit_type _edit_type = (_table_m_OP_type == db_table_OP_Add) ? edb_tb_edit_add : edb_tb_edit_modify ; 
    emit _controlmodel->work_sheet_main_update_Changed(_edit_type,_data);

    _error_type = _controlmodel->get_work_sheet_main_error_type();
    if(_error_type == edb_tb_err_type_none){
        std::string _primary_code,_updatetime ;
        _controlmodel->get_work_sheet_main_req_updated(_primary_code,_updatetime); 
        ui->lineEdit_mast_0->setText(QString::fromStdString(_primary_code));
        ui->lineEdit_mast_5->setText(QString::fromStdString(_updatetime));
        edit_table_dataShow_m();
        _table_m_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::delete_procedure_work_sheet_main(db_tb_error_type &_error_type)
{ 
    //std::string delete_code =  ui->lineEdit_mast_1->text().toStdString();
    std::string delete_code =  ui->lineEdit_mast_0->text().toStdString();
    emit _controlmodel->work_sheet_main_delete_Changed(delete_code) ;
    _error_type = _controlmodel->get_work_sheet_main_error_type();
    if(_error_type == edb_tb_err_type_none){
        int rowIndex = ui->mast_tableWidget->currentRow();
        if (rowIndex != -1)
            ui->mast_tableWidget->removeRow(rowIndex);
        int row = ui->mast_tableWidget->rowCount();
        if((row-1) >= last_table_rowno_m)
            ui->mast_tableWidget->selectRow(last_table_rowno_m);  
        else{
            ui->mast_tableWidget->selectRow(row);  
        }  
        _table_d_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::search_confirm_work_sheet_main(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_work_sheet_main_search_type query_opt = edynamic_work_sheet_main_search_base_name;
    int _query = ui->cbox_search_condition->currentIndex();
    if(_query < 3){
        query_base = (db_tb_search_type) _query ;
    }
    else if(_query == 3){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_work_sheet_main_search_base_name;
    }
    else if(_query == 4){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_work_sheet_main_search_uptime;
    }

    std::string search_param = ui->edit_search_from->text().toStdString() ;
    search_param += ui->edit_search_to->text().isEmpty() ? "" :
                    ","+ ui->edit_search_to->text().toStdString();

    emit _controlmodel->work_sheet_main_query_Changed(query_base,query_opt,search_param);
    _error_type = _controlmodel->get_work_sheet_main_error_type();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::search_cancel_work_sheet_main(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_work_sheet_main_search_type query_opt = edynamic_work_sheet_main_search_base_name;
    std::string search_param = "search_all" ; 

    emit _controlmodel->work_sheet_main_query_Changed(query_base,query_opt,search_param);

    _error_type = _controlmodel->get_work_sheet_main_error_type();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::parse_relatedb_work_sheet_items()
{
    vectors_d_clear();
    config_filename = QApplication::applicationDirPath()+"/config/config.cfg";
    QSettings config_set(config_filename,QSettings::IniFormat);
    config_set.setIniCodec("UTF-8");
    //-- table field number ----
    int field_num = config_set.value("work_sheet_item/field_num",-1).toInt();
    if(field_num == -1){
        config_set.setValue("work_sheet_item/field_num",10);//9);
        field_num = config_set.value("work_sheet_item/field_num").toInt();
    }
    
    _fiels_num_d = field_num ;

    //-- groupbox title ----
    QString prefix_key = "work_sheet_item/tablelist";
    QString tag_value = "";
    QString tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "work_sheet_item parameters manager list" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "工單細目檔 表列" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "工单细目档 表列" ; }
        QString tablelist = config_set.value(tag_key,"").toString();
        if(tablelist.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablelist = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_d_Vec_E.append(tablelist); }
        else if(i==1){ _titlename_d_Vec_TC.append(tablelist); }
        else if(i==2){ _titlename_d_Vec_SC.append(tablelist); }

    }
    //-- tablename title ----
    prefix_key = "work_sheet_item/tablename";
    tag_value = "";
    tag_key = "";
    for(int i=0;i<3;i++){
        if(i==0){ tag_key = prefix_key+"_E" ; tag_value = "table name:work_sheet_item" ; }
        else if(i==1){ tag_key = prefix_key+"_TC" ; tag_value = "資料表名稱:work_sheet_item" ; }
        else if(i==2){ tag_key = prefix_key+"_SC" ; tag_value = "资料表名称:work_sheet_item" ; }
        QString tablename = config_set.value(tag_key,"").toString();
        if(tablename.isEmpty()){
            config_set.setValue(tag_key,tag_value);
            tablename = config_set.value(tag_key).toString();
        }
        if(i==0){ _titlename_d_Vec_E.append(tablename); }
        else if(i==1){ _titlename_d_Vec_TC.append(tablename); }
        else if(i==2){ _titlename_d_Vec_SC.append(tablename); }

    }
    //--- field title set ----
    QString key_value[3]={"","",""};

    for(int i=0;i<_fiels_num_d;i++){
        prefix_key = "work_sheet_item/fieldname_"+ QString::number(i);
        if(i==0){key_value[0]="primary_id";key_value[1]="主KEY值";key_value[2]="主KEY值";}
        else if(i==1){key_value[0]="work_sheet index";key_value[1]="工單索引值";key_value[2]="工单索引值";}
        else if(i==2){key_value[0]="mission name";key_value[1]="任務名稱";key_value[2]="任务名称";}
        else if(i==3){key_value[0]="Execution order";key_value[1]="執行順序";key_value[2]="执行顺序";}
        else if(i==4){key_value[0]="occur_time";key_value[1]="建立時間";key_value[2]="建立时间";}
        else if(i==5){key_value[0]="target_pose_id";key_value[1]="目的地編號";key_value[2]="目的地编号";}
        else if(i==6){key_value[0]="action_function_id";key_value[1]="執行任務編號";key_value[2]="执行任务编号";}
        else if(i==7){key_value[0]="action_function_params";key_value[1]="執行任務參數";key_value[2]="执行任务参数";}
        else if(i==8){key_value[0]="remark";key_value[1]="備註說明";key_value[2]="备注说明";}
        else if(i==9){key_value[0]="update_time";key_value[1]="異動時間";key_value[2]="异动时间";}

        for(int j=0;j<3;j++){
            if(j==0){ tag_key = prefix_key+"_E" ; tag_value = key_value[0];}
            else if(j==1){ tag_key = prefix_key+"_TC" ; tag_value = key_value[1];}
            else if(j==2){ tag_key = prefix_key+"_SC" ; tag_value = key_value[2];}

            QString fieldname = config_set.value(tag_key,"").toString();
            if(fieldname.isEmpty()){
                config_set.setValue(tag_key,tag_value);
                fieldname = config_set.value(tag_key).toString();
            }
            if(j==0){ _fieldname_d_Vec_E.append(fieldname); }
            else if(j==1){ _fieldname_d_Vec_TC.append(fieldname); }
            else if(j==2){ _fieldname_d_Vec_SC.append(fieldname); }
        }
    }    
    //--- sort_frame show -----------------------
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type lang_type = tools->getlanguage_type();
    ui->cbox_sort_cond_detail->clear();
    QStringList strList;    
    ui->lb_sorttitle_detail->setText((lang_type == elanguage_type_TC)? "排序欄位" :
                                   ((lang_type == elanguage_type_SC)? "排序栏位":"Sort by"));

    strList.append((lang_type == elanguage_type_TC)? "任務名稱" :
                   ((lang_type == elanguage_type_SC)? "任务名称":"mission name"));
    strList.append((lang_type == elanguage_type_TC)? "執行順序" :
                   ((lang_type == elanguage_type_SC)? "执行顺序":"execution order"));
    strList.append((lang_type == elanguage_type_TC)? "建立時間" :
                   ((lang_type == elanguage_type_SC)? "建立时间":"occur_time"));
    strList.append((lang_type == elanguage_type_TC)? "目的地編號" :
                   ((lang_type == elanguage_type_SC)? "目的地编号":"target_pose_id"));    
    strList.append((lang_type == elanguage_type_TC)? "執行任務編號" :
                   ((lang_type == elanguage_type_SC)? "执行任务编号":"action_function_id"));
    strList.append((lang_type == elanguage_type_TC)? "異動時間" :
                   ((lang_type == elanguage_type_SC)? "异动时间":"update_time"));
    ui->cbox_sort_cond_detail->addItems(strList);
    //------------------------------------------
    form_table_type_show_d();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::table_dataShow_work_sheet_items()
{
    ui->detail_tableWidget->setSortingEnabled(false);
    //----------------------------
    vector<ptr_work_sheet_items> result = _controlmodel->get_work_sheet_items_results();
    int isize = result.size();
    ui->detail_tableWidget->setSortingEnabled(false); 
    if(isize == 0){
        ui->detail_tableWidget->setRowCount(1) ; 
        for(int i=0;i<_fiels_num_d;i++){            
            ui->detail_tableWidget->setItem(0,i,new QTableWidgetItem(""));   // (row,col) 
        }
    }
    else{
        ui->detail_tableWidget->setRowCount(isize) ; 
        for(int i=0;i<isize;i++){
            ui->detail_tableWidget->setItem(i,0,new QTableWidgetItem(QString::fromStdString(result[i]->primary_id)));    
            ui->detail_tableWidget->setItem(i,1,new QTableWidgetItem(QString::fromStdString(result[i]->unique_code)));              
            ui->detail_tableWidget->setItem(i,2,new QTableWidgetItem(QString::fromStdString(result[i]->base_item_name)));   
            ui->detail_tableWidget->setItem(i,3,new QTableWidgetItem(QString::number(result[i]->item_ser_no)));    
            ui->detail_tableWidget->setItem(i,4,new QTableWidgetItem(QString::fromStdString(result[i]->occur_time)));    
            ui->detail_tableWidget->setItem(i,5,new QTableWidgetItem(QString::fromStdString(result[i]->target_pose_id)));    
            ui->detail_tableWidget->setItem(i,6,new QTableWidgetItem(QString::fromStdString(result[i]->action_function_id)));   
            ui->detail_tableWidget->setItem(i,7,new QTableWidgetItem(QString::fromStdString(result[i]->action_function_params)));     
            ui->detail_tableWidget->setItem(i,8,new QTableWidgetItem(QString::fromStdString(result[i]->remark)));    
            ui->detail_tableWidget->setItem(i,9,new QTableWidgetItem(QString::fromStdString(result[i]->update_time)));    
        }          
    }
    ui->detail_tableWidget->setSortingEnabled(true);
    //-------------------------
    table_sorttype_show_d();
    //-- set currentItem is first item and show its detail data ---
    ui->detail_tableWidget->selectRow(0);
    edit_frame_dataShow_d();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::update_procedure_work_sheet_items(db_tb_error_type &_error_type)
{ 
    ptr_work_sheet_items _data = boost::make_shared<type_work_sheet_items>();
    _data->primary_id = ui->lineEdit_detail_0->text().toStdString();
    _data->unique_code = ui->lineEdit_detail_1->text().toStdString();    
    _data->base_item_name = ui->lineEdit_detail_2->text().toStdString();
    _data->item_ser_no = ui->lineEdit_detail_3->text().toInt();
    _data->occur_time = ui->lineEdit_detail_4->text().toStdString();
    _data->target_pose_id = ui->lineEdit_detail_5->text().toStdString();
    _data->action_function_id = ui->lineEdit_detail_6->text().toStdString();
    _data->action_function_params = ui->lineEdit_detail_7->text().toStdString();
    _data->remark = ui->lineEdit_detail_8->text().toStdString();
    _data->update_time = ui->lineEdit_detail_9->text().toStdString();

    db_tb_edit_type _edit_type = (_table_d_OP_type == db_table_OP_Add) ? edb_tb_edit_add : edb_tb_edit_modify ; 
    emit _controlmodel->work_sheet_items_update_Changed(_edit_type,_data);

    _error_type = _controlmodel->get_work_sheet_items_error_type();
    if(_error_type == edb_tb_err_type_none){
        std::string _primary_code,_updatetime ;
        _controlmodel->get_work_sheet_items_req_updated(_primary_code,_updatetime); 
        ui->lineEdit_detail_0->setText(QString::fromStdString(_primary_code));
        ui->lineEdit_detail_9->setText(QString::fromStdString(_updatetime));
        edit_table_dataShow_d();

        _table_d_OP_type = db_table_OP_None ;
        //-------------
        //-- update main's record counter ---

    }
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::delete_procedure_work_sheet_items(db_tb_error_type &_error_type)
{ 
    std::string delete_code =  ui->lineEdit_detail_0->text().toStdString(); //ui->lineEdit_detail_1->text().toStdString();
    emit _controlmodel->work_sheet_items_delete_Changed(delete_code) ;
    _error_type = _controlmodel->get_work_sheet_items_error_type();
    if(_error_type == edb_tb_err_type_none){
        int rowIndex = ui->detail_tableWidget->currentRow();
        if (rowIndex != -1)
            ui->detail_tableWidget->removeRow(rowIndex);
        int row = ui->detail_tableWidget->rowCount();
        if((row-1) >= last_table_rowno_d)
            ui->detail_tableWidget->selectRow(last_table_rowno_d);  
        else{
            ui->detail_tableWidget->selectRow(row);  
        } 
        
        _table_d_OP_type = db_table_OP_None ;
    }
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::search_confirm_work_sheet_items(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_work_sheet_items_search_type query_opt = edynamic_work_sheet_items_search_base_name;
    int _query = ui->cbox_search_condition->currentIndex();
    if(_query < 3){
        query_base = (db_tb_search_type) _query ;
    }
    else if(_query == 3){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_work_sheet_items_search_base_name;
    }
    else if(_query == 4){
        query_base = edb_tb_search_special ;
        query_opt = edynamic_work_sheet_items_search_uptime;
    }

    std::string search_param = ui->edit_search_from->text().toStdString() ;
    search_param += ui->edit_search_to->text().isEmpty() ? "" :
                    ","+ ui->edit_search_to->text().toStdString();

    emit _controlmodel->work_sheet_items_query_Changed(query_base,query_opt,search_param);
    _error_type = _controlmodel->get_work_sheet_items_error_type();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::search_cancel_work_sheet_items(db_tb_error_type &_error_type)
{
    db_tb_search_type query_base = edb_tb_search_all ;
    dynamic_work_sheet_items_search_type query_opt = edynamic_work_sheet_items_search_base_name;
    std::string search_param = "search_all" ; 

    emit _controlmodel->work_sheet_items_query_Changed(query_base,query_opt,search_param);

    _error_type = _controlmodel->get_work_sheet_items_error_type();
}
//-----------------------------------------------------------------------------
void frmdb_relateTable::work_sheet_items_refresh(std::string filter_cond)
{
    //-------------------    
    db_tb_error_type _error_type ;
    db_tb_search_type query_base = edb_tb_search_special ;
    dynamic_work_sheet_items_search_type query_opt = edynamic_work_sheet_items_search_base_name;

    std::string search_param = filter_cond ; 
    if(!filter_cond.empty())
        search_param = filter_cond+","+ filter_cond ; 
    else 
        return ;
    //-----------------------------    

    emit _controlmodel->work_sheet_items_query_Changed(query_base,query_opt,search_param);
    _error_type = _controlmodel->get_work_sheet_items_error_type();  
    //----------------
    if(_error_type == edb_tb_err_type_none){
        table_dataShow_work_sheet_items();
    }   
    else{
        qt_generaltools* tools = qt_generaltools::getInstance();
        elanguage_type lang_type = tools->getlanguage_type();
        QString message = ((lang_type == elanguage_type_TC) ? "work_sheet_items 细目參數資料錯誤！" :
                        ((lang_type == elanguage_type_SC) ? "work_sheet_items 细目参数资料错误！" : "work_sheet_items Detail Parameters Error !"));

        tools->dialog_formShow(message,eMessageStyle,lang_type);   
    }
}
//-----------------------------------------------------------------------------
