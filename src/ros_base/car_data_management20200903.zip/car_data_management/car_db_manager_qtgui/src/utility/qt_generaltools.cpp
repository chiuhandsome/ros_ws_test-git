#include "car_db_manager/utility/qt_generaltools.h"
//----------------------------------------------------------------------------
qt_generaltools* qt_generaltools::_instance = 0;
//----------------------------------------------------------------------------
qt_generaltools::qt_generaltools()
{

}
//----------------------------------------------------------------------------
qt_generaltools::~qt_generaltools()
{

}
//----------------------------------------------------------------------------
qt_generaltools* qt_generaltools::getInstance()
{
    if (_instance == 0){
        _instance = new qt_generaltools();
    }
    return _instance ;
}
//----------------------------------------------------------------------------
void qt_generaltools::delInstance()
{
    if (_instance != 0){
       delete _instance;
       _instance = 0;
    }
}
//---------------------------------------------------------------------------
double qt_generaltools::mod45(double modvalue, int bitnum)
{
    double z = qPow(10.0, (double)bitnum);
    double rtvalue = 0;
    modf(modvalue*z+0.5, &rtvalue);
    rtvalue = rtvalue/z;
    return rtvalue;
}
//---------------------------------------------------------------------------
bool qt_generaltools::dialog_formShow(QString str, efrmStyle frmstyle,elanguage_type language_type)
{
    bool bRet = dialog_form.formShow(str,frmstyle,language_type);
    return bRet ;
}
//---------------------------------------------------------------------------
void qt_generaltools::dialog_contextTitle_set(QString context_title,QString context_s,QString context_subtitle)
{
    dialog_form.contextTitle_set(context_title,context_s,context_subtitle);
}
//---------------------------------------------------------------------------
void qt_generaltools::dialog_formTitle_set(QString projectName)
{
    dialog_form.widgetTitle_set(projectName);
}
//-----------------------------------------------------------------------------
QString qt_generaltools::get_updatetime_data(QString  updatetime_data,bool b_Msec)
{
    QString sRet="";
    QString sYear,sMonth,sDate,sHour,sMinute,sSecond,sM_Sec;
    int length = updatetime_data.length() ;
    if(length == 17){
        sYear = updatetime_data.mid(0,4);
        sMonth = updatetime_data.mid(4,2);
        sDate = updatetime_data.mid(6,2);
        sHour = updatetime_data.mid(8,2);
        sMinute = updatetime_data.mid(10,2) ;
        sSecond = updatetime_data.mid(12,2) ;
        sM_Sec = updatetime_data.mid(14,3) ;

        sRet = sYear+"-"+sMonth+"-"+sDate+"T"+sHour+":"+sMinute+":"+sSecond ;//+":"+sM_Sec ;
        if(b_Msec)
            sRet += ":"+sM_Sec ;   
    }
    return sRet ;
}
//-----------------------------------------------------------------------------
QString qt_generaltools::get_unique_code()
{
    QString sRet="";
    QDateTime time = QDateTime::currentDateTime();
    QString str = time.toString("yyyy-MM-dd hh:mm:ss.zzz ddd");
    sRet = str.mid(0,4)+str.mid(5,2)+str.mid(8,2)+str.mid(11,2)+str.mid(14,2)+str.mid(17,2)+str.mid(20,3) ;
    if(sRet.length()!=17)
        sRet = "";
    return sRet ;
}
//-----------------------------------------------------------------------------
elanguage_type qt_generaltools::getlanguage_type()
{
    return dialog_form.getlanguage_type() ;
}
//-----------------------------------------------------------------------------
void qt_generaltools::setlanguage_type(elanguage_type language_type)
{
    return dialog_form.setlanguage_type(language_type); ;
}
//----------------------------------------------------------------------------
