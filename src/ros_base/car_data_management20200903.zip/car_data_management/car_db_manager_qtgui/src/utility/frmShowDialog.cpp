#include "car_db_manager/utility/frmShowDialog.h"
#include "ui_frmShowDialog.h"
#include <QPixmap>
#include <QMessageBox>

frmShowDialog::frmShowDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::frmShowDialog)
{
    ui->setupUi(this);
    //-----------------
    _language_type = elanguage_type_None ;
    _context_s = "\n";
    _context_title = "\n" ;
    _context_subtitle = "\n" ;

    _projectName = "" ;

    //-- set signal and slot for "Buttons"
    QObject::connect(ui->btn_confirm, SIGNAL(clicked()), this, SLOT(accept()));
    QObject::connect(ui->btn_cancel, SIGNAL(clicked()), this, SLOT(reject()));
    //--------------------------------
    /*ui->textEdit_context->setAlignment(Qt::AlignCenter);
    //ui->textEdit_context->setFrameShape(QFrame::Box);
    ui->textEdit_context->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->textEdit_context->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->textEdit_context->setLineWrapMode(QTextEdit::WidgetWidth);*/
    ui->textEdit_context->document()->setDefaultTextOption(QTextOption(Qt::AlignHCenter));
    ui->textEdit_context->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->textEdit_context->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->textEdit_context->setLineWrapMode(QTextEdit::WidgetWidth);
    ui->textEdit_context->setEnabled(false);
}

frmShowDialog::~frmShowDialog()
{
    delete ui;
}

void frmShowDialog::widgetTitle_set(QString projectName)
{
    _projectName = projectName ;
}

void frmShowDialog::contextTitle_set(QString context_title,QString context_s,QString context_subtitle)
{
    _context_title = context_title ;
    _context_s = context_title ;
    _context_subtitle = context_title ;
}

bool frmShowDialog::formShow(QString str, efrmStyle frmstyle,elanguage_type language_type)
{    
    //-- decide language_type --
    if(language_type == elanguage_type_None){
        if(_language_type == elanguage_type_None)
            _language_type = elanguage_type_E ;
    }
    else
        _language_type = language_type ;
    //--- show indicator and window's title ---
    QString png_hint ="";
    QString titlename = "";
    QString cnf_btnname = "";
    QString cnl_btnname = "";
    QString style_para_messsage = "QTextEdit{font: bold 14pt;\
                                             color:Blue;\
                                             background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, \
                                                               stop:0 lightgreen, stop:1 white);}";
    QString style_para_confirm = "QTextEdit{font: bold 14pt;\
                                            color:Green;\
                                            background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, \
                                                              stop:0 yellow, stop:1 white);}";

    ui->textEdit_context->setStyleSheet((frmstyle == eMessageStyle) ? style_para_messsage : style_para_confirm);

    png_hint = (frmstyle == eMessageStyle) ? ":/png/resource/tools_png/symbol_003.png" :
                                             ":/png/resource/tools_png/inquire_002.png" ;
    if(_language_type == elanguage_type_E){
        titlename = (frmstyle == eMessageStyle) ? "Message Dialog" : "Confirme Dialog" ;
        cnf_btnname = "Confirm" ;
        cnl_btnname = "Cancel" ;
    }
    else if(_language_type == elanguage_type_TC){
        titlename = (frmstyle == eMessageStyle) ? "訊息視窗" : "確認視窗" ;
        cnf_btnname = "確認" ;
        cnl_btnname = "取消" ;
    }
    else if(_language_type == elanguage_type_SC){
        titlename = (frmstyle == eMessageStyle) ? "讯息视窗" : "确认视窗" ;
        cnf_btnname = "确认" ;
        cnl_btnname = "取消" ;
    }

    QString style_lb_messsage = "QLabel{font: bold 14pt;color:Blue;}";
    QString style_lb_confirm = "QLabel{font: bold 14pt;color:Green;}";
    ui->lb_titlename->setStyleSheet((frmstyle == eMessageStyle) ? style_lb_messsage : style_lb_confirm);
    ui->lb_titlename->setText(titlename);
    //-- button and title show ---------
    titlename = "[ " + _projectName +" ] "+ titlename ;
    this->setWindowTitle(titlename);

    ui->btn_confirm->setText(cnf_btnname);
    ui->btn_cancel->setText(cnl_btnname);
    ui->btn_confirm->setVisible(true);
    ui->btn_cancel->setVisible(frmstyle == eConfirmStyle);
    //-- logo show ----
    QPixmap pixmap_1(":/png/resource/tools_png/hyclogo.png");
    ui->logo_label->setPixmap(pixmap_1.scaled(ui->logo_label->size(),Qt::IgnoreAspectRatio));
    ui->logo_label->setPixmap(pixmap_1);

    //QPixmap pixmap(":/png/resource/tools_png/inquire_002.png");
    QPixmap pixmap(png_hint);
    ui->lb_iconshow->setPixmap(pixmap.scaled(ui->lb_iconshow->size(),Qt::KeepAspectRatio));
    ui->lb_iconshow->setPixmap(pixmap);


    //-- set context to textEdit_context and spec. its show-format ----
    QString param =_context_s + _context_title + _context_subtitle + str;
    ui->textEdit_context->setText(param);
    // show modal window event loop and wait for button clicks
    int dialogCode = this->exec();
    // act on dialog return code
    if(dialogCode == QDialog::Accepted) { b_Return = true ; }
    if(dialogCode == QDialog::Rejected) { b_Return = false ; }
    return b_Return ;
}

elanguage_type frmShowDialog::getlanguage_type()
{
    return _language_type ;
}

void frmShowDialog::setlanguage_type(elanguage_type language_type)
{
    _language_type = language_type ;
}
