#ifndef QT_TOOLS_H
#define QT_TOOLS_H
//----------------------------------------------------------------------
#include <iostream>     // std::cout, std::ios
#include <sstream>      // std::ostringstream
#include <QString>
#include <QDateTime>
//______________________________________________________________________
//--- template function - any type --> QString -------------------------
/*template <typename T> QString convert_str(const T& t)
{
    std::ostringstream os;
    os<<t;
    return QString::fromStdString(os.str());
}*/
//-----------------------------------------------------------------------------
static QString get_updatetime_data(QString  updatetime_data)
{
    QString sRet="";
    QString sYear,sMonth,sDate,sHour,sMinute,sSecond,sM_Sec;
    int length = updatetime_data.length() ;
    if(length == 17){
        sYear = updatetime_data.mid(0,4);
        sMonth = updatetime_data.mid(4,2);
        sDate = updatetime_data.mid(6,2);
        sHour = updatetime_data.mid(8,2);
        sMinute = updatetime_data.mid(10,2) ;
        sSecond = updatetime_data.mid(12,2) ;
        sM_Sec = updatetime_data.mid(14,3) ;

        sRet = sYear+"-"+sMonth+"-"+sDate+" T "+sHour+":"+sMinute+":"+sSecond+":"+sM_Sec ;
    }
    return sRet ;
}
//-----------------------------------------------------------------------------
static QString get_unique_code()
{
    QString sRet="";
    QDateTime time = QDateTime::currentDateTime();
    QString str = time.toString("yyyy-MM-dd hh:mm:ss.zzz ddd");
    sRet = str.mid(0,4)+str.mid(5,2)+str.mid(8,2)+str.mid(11,2)+str.mid(14,2)+str.mid(17,2)+str.mid(20,3) ;
    if(sRet.length()!=17)
        sRet = "";
    return sRet ;
}
//-----------------------------------------------------------------------------
#endif
