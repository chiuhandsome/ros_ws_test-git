#include "car_db_manager/controller/ros_control_related.h"
#include <thread>
#include <QMetaType>
#include "car_db_manager/utility/qt_generaltools.h"
#include <ros_utility_tools/ros_tools.h>
#include <ros/ros.h>

//-----------------------------------------------------------------------------
ros_control_related::ros_control_related(ros::NodeHandle nh) : nh_(nh) 
{
    Load_CntParameter();
    err_type_desc_initSet();
    //--- qt QMetaType definition area ----
    qRegisterMetaType<std::string>("std::string");
    qRegisterMetaType<ros::ServiceClient>("ros::ServiceClient");
    qRegisterMetaType<db_tb_search_type>("db_tb_search_type");
    qRegisterMetaType<db_tb_edit_type>("db_tb_edit_type"); 
    //***********************************
    //**** table : work_sheet_main   ****   
    //***********************************  
    qRegisterMetaType<type_work_sheet_main>("type_work_sheet_main");
    qRegisterMetaType<type_work_sheet_main_cmd>("type_work_sheet_main_cmd");   
    qRegisterMetaType<dynamic_work_sheet_main_search_type>("dynamic_work_sheet_main_search_type");         
    qRegisterMetaType<ptr_work_sheet_main>("ptr_work_sheet_main");
    //--- declare signal & slot -------------    
    QObject::connect(this, &ros_control_related::work_sheet_main_delete_Changed, this, &ros_control_related::on_work_sheet_main_delete_action, Qt::AutoConnection);//QueuedConnection
    QObject::connect(this, &ros_control_related::work_sheet_main_query_Changed, this, &ros_control_related::on_work_sheet_main_query_action, Qt::AutoConnection);
    QObject::connect(this, &ros_control_related::work_sheet_main_update_Changed, this, &ros_control_related::on_work_sheet_main_update_action, Qt::AutoConnection);
    //--- declare and set client service ----
    work_sheet_main_cltService_name = tbname_work_sheet_main+"_service";
    work_sheet_main_cltService = nh_.serviceClient<type_work_sheet_main_cmd>(work_sheet_main_cltService_name); 
    
    //**************************************
    //**** table : work_sheet_items  ****   
    //************************************** 
    qRegisterMetaType<type_work_sheet_items>("type_work_sheet_items");
    qRegisterMetaType<type_work_sheet_items_cmd>("type_work_sheet_items_cmd");   
    qRegisterMetaType<dynamic_work_sheet_items_search_type>("dynamic_work_sheet_items_search_type");         
    qRegisterMetaType<ptr_work_sheet_items>("ptr_work_sheet_items");
    
    //--- declare signal & slot -------------    
    QObject::connect(this, &ros_control_related::work_sheet_items_delete_Changed, this, &ros_control_related::on_work_sheet_items_delete_action, Qt::AutoConnection);//QueuedConnection
    QObject::connect(this, &ros_control_related::work_sheet_items_query_Changed, this, &ros_control_related::on_work_sheet_items_query_action, Qt::AutoConnection);
    QObject::connect(this, &ros_control_related::work_sheet_items_update_Changed, this, &ros_control_related::on_work_sheet_items_update_action, Qt::AutoConnection);
    //--- declare and set client service ----
    work_sheet_items_cltService_name = tbname_work_sheet_items+"_service";
    work_sheet_items_cltService = nh_.serviceClient<type_work_sheet_items_cmd>(work_sheet_items_cltService_name); 
}
//-----------------------------------------------------------------------------
ros_control_related::~ros_control_related()
{

}
//------------------------------------------------------- 
void ros_control_related::err_type_desc_initSet()
{
    for(int i=0;i<15;i++){
        err_type_desc_TC.push_back("正常");
        err_type_desc_TC.push_back("不允許空白資料！");
        err_type_desc_TC.push_back("資料需為整數格式！");
        err_type_desc_TC.push_back("輸入參數資料錯誤!");
        err_type_desc_TC.push_back("資料索引鍵值錯誤！");
        err_type_desc_TC.push_back("表格資料錯誤！");
        err_type_desc_TC.push_back("編輯參數錯誤！");
        err_type_desc_TC.push_back("搜尋參數錯誤！");
        err_type_desc_TC.push_back("選擇搜尋參數錯誤！");
        err_type_desc_TC.push_back("無任何符合查詢資料！");
        err_type_desc_TC.push_back("新增資料錯誤！");
        err_type_desc_TC.push_back("修改資料錯誤！");
        err_type_desc_TC.push_back("删除資料錯誤！");
        err_type_desc_TC.push_back("查詢資料錯誤！");

        err_type_desc_SC.push_back("正常");
        err_type_desc_SC.push_back("不允许空白资料！");
        err_type_desc_SC.push_back("资料需为整数格式！");
        err_type_desc_SC.push_back("输入参数资料错误!");
        err_type_desc_SC.push_back("资料索引键值错误！");
        err_type_desc_SC.push_back("表格资料错误！");
        err_type_desc_SC.push_back("编辑参数错误！");
        err_type_desc_SC.push_back("搜寻参数错误！");
        err_type_desc_SC.push_back("选择搜寻参数错误！");
        err_type_desc_SC.push_back("无任何符合查询资料！");
        err_type_desc_SC.push_back("新增资料错误！");
        err_type_desc_SC.push_back("修改资料错误！");
        err_type_desc_SC.push_back("删除资料错误！");
        err_type_desc_SC.push_back("查询资料错误！");

        err_type_desc_E.push_back("normal");
        err_type_desc_E.push_back("blank data isn't allowed!");
        err_type_desc_E.push_back("Data must be in integer format！");
        err_type_desc_E.push_back("Input parameter is wrong!");
        err_type_desc_E.push_back("Data index key value error！");
        err_type_desc_E.push_back("Table data is wrong !");
        err_type_desc_E.push_back("parameter error - Edit ！");
        err_type_desc_E.push_back("parameter error - Search") ;
        err_type_desc_E.push_back("parameter error - Option Search");
        err_type_desc_E.push_back("No matching data to inquire condition！");
        err_type_desc_E.push_back("Error - add mode ");
        err_type_desc_E.push_back("Error - modify mode ");
        err_type_desc_E.push_back("Error - delete mode ");
        err_type_desc_E.push_back("Error - inquire mode");
    }
}
//------------------------------------------------------- 
std::string ros_control_related::get_error_desc(int lang_type,db_tb_error_type _type)
{
    std::string sRet = "";
    int error_ser = (int) _type ;
    if(lang_type == 1)  //elang_type_E
        sRet = err_type_desc_E[error_ser]; 	
    else if(lang_type == 2) //elang_type_TC
        sRet = err_type_desc_TC[error_ser]; 	
    else if(lang_type == 3) //elang_type_SC
        sRet = err_type_desc_SC[error_ser]; 	
    
    return sRet ;
}
//-----------------------------------------------------------------------------
void ros_control_related::Load_CntParameter()
{
    ros::NodeHandle pnh("~");   
    
    if(!pnh.getParam("tbname_work_sheet_main", tbname_work_sheet_main))
        tbname_work_sheet_main = "work_sheet_main" ;	 
    if(!pnh.getParam("tbname_work_sheet_items", tbname_work_sheet_items))
        tbname_work_sheet_items = "work_sheet_items" ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : work_sheet_main                                             ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
void ros_control_related::set_work_sheet_main_cltService(ros::ServiceClient &_cltService)
{
    work_sheet_main_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
void ros_control_related::on_work_sheet_main_update_action(db_tb_edit_type _edit_type,const ptr_work_sheet_main &_data)
{ 
    work_sheet_main_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        work_sheet_main_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    work_sheet_main_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    work_sheet_main_cmd_data.request.query_base_index = -1 ;
    work_sheet_main_cmd_data.request.query_opt_index = -1;
    work_sheet_main_cmd_data.request.query_parameter = "" ;
    work_sheet_main_cmd_data.request.req_work_sheet_main.primary_id = _data->primary_id ;
    work_sheet_main_cmd_data.request.req_work_sheet_main.unique_code = _data->unique_code ;
    work_sheet_main_cmd_data.request.req_work_sheet_main.base_name = _data->base_name ;
    work_sheet_main_cmd_data.request.req_work_sheet_main.occur_time = _data->occur_time ;
    work_sheet_main_cmd_data.request.req_work_sheet_main.workitems_num = _data->workitems_num ;
    work_sheet_main_cmd_data.request.req_work_sheet_main.update_time = _data->update_time ;
    
    work_sheet_main_cltService.call(work_sheet_main_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    work_sheet_main_error_type = (db_tb_error_type)strtoint(work_sheet_main_cmd_data.response.error_code,-1) ;
    if(work_sheet_main_error_type == edb_tb_err_type_none){        
        _update_primary_id = work_sheet_main_cmd_data.response.primary_id ;
        _update_updatetime = work_sheet_main_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void ros_control_related::on_work_sheet_main_delete_action(std::string unique_code)
{
    work_sheet_main_error_type = edb_tb_err_type_none ;

    work_sheet_main_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    work_sheet_main_cmd_data.request.query_base_index = -1 ;
    work_sheet_main_cmd_data.request.query_opt_index = -1;
    work_sheet_main_cmd_data.request.query_parameter = unique_code ;
    
    work_sheet_main_cltService.call(work_sheet_main_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    work_sheet_main_error_type = (db_tb_error_type)strtoint(work_sheet_main_cmd_data.response.error_code,-1) ;
    if(work_sheet_main_error_type != edb_tb_err_type_none){
        work_sheet_main_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void ros_control_related::on_work_sheet_main_query_action(db_tb_search_type query_base,dynamic_work_sheet_main_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    work_sheet_main_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_work_sheet_main_search_base_name) && 
                (query_opt <= edynamic_work_sheet_main_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        work_sheet_main_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        work_sheet_main_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        work_sheet_main_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        work_sheet_main_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        work_sheet_main_cmd_data.request.query_parameter = search_param ;
        
        work_sheet_main_cltService.call(work_sheet_main_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        //------------------
        work_sheet_main_error_type = (db_tb_error_type)strtoint(work_sheet_main_cmd_data.response.error_code,-1) ;
        bRet = (work_sheet_main_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            work_sheet_main_results.clear();
            int size = work_sheet_main_cmd_data.response.result_work_sheet_main.size();
            for(int i=0;i<size;i++){
                boost::shared_ptr<type_work_sheet_main> _data = boost::make_shared<type_work_sheet_main>();
                _data->primary_id = work_sheet_main_cmd_data.response.result_work_sheet_main[i].primary_id ;
                _data->unique_code = work_sheet_main_cmd_data.response.result_work_sheet_main[i].unique_code ;
                _data->base_name = work_sheet_main_cmd_data.response.result_work_sheet_main[i].base_name ;
                _data->occur_time = work_sheet_main_cmd_data.response.result_work_sheet_main[i].occur_time ;
                _data->workitems_num = work_sheet_main_cmd_data.response.result_work_sheet_main[i].workitems_num ;
                _data->update_time = work_sheet_main_cmd_data.response.result_work_sheet_main[i].update_time ;
                work_sheet_main_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        work_sheet_main_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
vector<ptr_work_sheet_main> ros_control_related::get_work_sheet_main_results()
{
    return work_sheet_main_results ;
}
//-----------------------------------------------------------------------------
void ros_control_related::get_work_sheet_main_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type ros_control_related::get_work_sheet_main_error_type() 
{
    return work_sheet_main_error_type ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : work_sheet_items                                            ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<boost::shared_ptr<type_work_sheet_items>> ros_control_related::get_work_sheet_items_results()
{
    return work_sheet_items_results ;
}
//-----------------------------------------------------------------------------
void ros_control_related::get_work_sheet_items_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type ros_control_related::get_work_sheet_items_error_type() 
{
    return work_sheet_items_error_type ;
}
//-----------------------------------------------------------------------------
void ros_control_related::on_work_sheet_items_update_action(db_tb_edit_type _edit_type,const ptr_work_sheet_items &_data)
{ 
    work_sheet_items_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        work_sheet_items_error_type = edb_tb_err_type_editparam ;
        return ;
    }   
    work_sheet_items_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    work_sheet_items_cmd_data.request.query_base_index = -1 ;
    work_sheet_items_cmd_data.request.query_opt_index = -1;
    work_sheet_items_cmd_data.request.query_parameter = "" ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.primary_id = _data->primary_id ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.unique_code = _data->unique_code ;    
    work_sheet_items_cmd_data.request.req_work_sheet_items.base_item_name = _data->base_item_name ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.item_ser_no = _data->item_ser_no ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.occur_time = _data->occur_time ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.target_pose_id = _data->target_pose_id ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.action_function_id = _data->action_function_id ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.action_function_params = _data->action_function_params ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.remark = _data->remark ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.update_time = _data->update_time ;
    
    work_sheet_items_cltService.call(work_sheet_items_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    work_sheet_items_error_type = (db_tb_error_type)strtoint(work_sheet_items_cmd_data.response.error_code,-1) ;
    if(work_sheet_items_error_type == edb_tb_err_type_none){        
        _update_primary_id = work_sheet_items_cmd_data.response.primary_id ;
        _update_updatetime = work_sheet_items_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void ros_control_related::on_work_sheet_items_delete_action(std::string unique_code)
{
    work_sheet_items_error_type = edb_tb_err_type_none ;

    work_sheet_items_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    work_sheet_items_cmd_data.request.query_base_index = -1 ;
    work_sheet_items_cmd_data.request.query_opt_index = -1;
    work_sheet_items_cmd_data.request.query_parameter = unique_code ;
    
    work_sheet_items_cltService.call(work_sheet_items_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    work_sheet_items_error_type = (db_tb_error_type)strtoint(work_sheet_items_cmd_data.response.error_code,-1) ;
    if(work_sheet_items_error_type != edb_tb_err_type_none){
        work_sheet_items_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void ros_control_related::on_work_sheet_items_query_action(db_tb_search_type query_base,dynamic_work_sheet_items_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    work_sheet_items_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_work_sheet_items_search_base_name) && 
                (query_opt <= edynamic_work_sheet_items_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        work_sheet_items_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        work_sheet_items_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        work_sheet_items_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        work_sheet_items_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        work_sheet_items_cmd_data.request.query_parameter = search_param ;
        
        work_sheet_items_cltService.call(work_sheet_items_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        //------------------
        work_sheet_items_error_type = (db_tb_error_type)strtoint(work_sheet_items_cmd_data.response.error_code,-1) ;
        bRet = (work_sheet_items_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            work_sheet_items_results.clear();
            int size = work_sheet_items_cmd_data.response.result_work_sheet_items.size();
            for(int i=0;i<size;i++){
                ptr_work_sheet_items _data = boost::make_shared<type_work_sheet_items>();
                _data->primary_id = work_sheet_items_cmd_data.response.result_work_sheet_items[i].primary_id ;
                _data->unique_code = work_sheet_items_cmd_data.response.result_work_sheet_items[i].unique_code ;                
                _data->base_item_name = work_sheet_items_cmd_data.response.result_work_sheet_items[i].base_item_name ;
                _data->item_ser_no = work_sheet_items_cmd_data.response.result_work_sheet_items[i].item_ser_no ;
                _data->occur_time = work_sheet_items_cmd_data.response.result_work_sheet_items[i].occur_time ;
                _data->target_pose_id = work_sheet_items_cmd_data.response.result_work_sheet_items[i].target_pose_id ;
                _data->action_function_id = work_sheet_items_cmd_data.response.result_work_sheet_items[i].action_function_id ;
                _data->action_function_params = work_sheet_items_cmd_data.response.result_work_sheet_items[i].action_function_params ;
                _data->remark = work_sheet_items_cmd_data.response.result_work_sheet_items[i].remark ;
                _data->update_time = work_sheet_items_cmd_data.response.result_work_sheet_items[i].update_time ;

                work_sheet_items_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        work_sheet_items_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void ros_control_related::set_work_sheet_items_cltService(ros::ServiceClient &_cltService)
{
    work_sheet_items_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
