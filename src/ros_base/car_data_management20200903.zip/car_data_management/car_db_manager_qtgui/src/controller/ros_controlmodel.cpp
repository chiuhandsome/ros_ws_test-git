#include "car_db_manager/controller/ros_controlmodel.h"
#include <thread>
#include <QMetaType>
#include "car_db_manager/utility/qt_generaltools.h"
#include <ros_utility_tools/ros_tools.h>
#include <ros/ros.h>

//-----------------------------------------------------------------------------
ros_controlmodel::ros_controlmodel(ros::NodeHandle nh) : nh_(nh) 
{
    Load_CntParameter();
    err_type_desc_initSet();
    //--- qt QMetaType definition area ----
    qRegisterMetaType<std::string>("std::string");
    qRegisterMetaType<ros::ServiceClient>("ros::ServiceClient");
    qRegisterMetaType<db_tb_search_type>("db_tb_search_type");
    qRegisterMetaType<db_tb_edit_type>("db_tb_edit_type"); 
    //***********************************
    //**** table : check_parameters  ****   
    //***********************************  
    qRegisterMetaType<type_check_parameters>("type_check_parameters");
    qRegisterMetaType<type_check_parameters_cmd>("type_check_parameters_cmd");   
    qRegisterMetaType<dynamic_check_parameters_search_type>("dynamic_check_parameters_search_type");         
    qRegisterMetaType<ptr_check_parameters>("ptr_check_parameters");
    //--- declare signal & slot -------------    
    QObject::connect(this, &ros_controlmodel::check_parameters_delete_Changed, this, &ros_controlmodel::on_check_parameters_delete_action, Qt::AutoConnection);//QueuedConnection
    QObject::connect(this, &ros_controlmodel::check_parameters_query_Changed, this, &ros_controlmodel::on_check_parameters_query_action, Qt::AutoConnection);
    QObject::connect(this, &ros_controlmodel::check_parameters_update_Changed, this, &ros_controlmodel::on_check_parameters_update_action, Qt::AutoConnection);
    //--- declare and set client service ----
    check_parameters_cltService_name = tbname_check_parameters+"_service";
    check_parameters_cltService = nh_.serviceClient<type_check_parameters_cmd>(check_parameters_cltService_name); 
    
    //**************************************
    //**** table : pid_ctrl_parameters  ****   
    //************************************** 
    qRegisterMetaType<type_pid_ctrl_parameters>("type_pid_ctrl_parameters");
    qRegisterMetaType<type_pid_ctrl_parameters_cmd>("type_pid_ctrl_parameters_cmd");   
    qRegisterMetaType<dynamic_pid_ctrl_parameters_search_type>("dynamic_pid_ctrl_parameters_search_type");         
    qRegisterMetaType<ptr_pid_ctrl_parameters>("ptr_pid_ctrl_parameters");
    
    //--- declare signal & slot -------------    
    QObject::connect(this, &ros_controlmodel::pid_ctrl_parameters_delete_Changed, this, &ros_controlmodel::on_pid_ctrl_parameters_delete_action, Qt::AutoConnection);//QueuedConnection
    QObject::connect(this, &ros_controlmodel::pid_ctrl_parameters_query_Changed, this, &ros_controlmodel::on_pid_ctrl_parameters_query_action, Qt::AutoConnection);
    QObject::connect(this, &ros_controlmodel::pid_ctrl_parameters_update_Changed, this, &ros_controlmodel::on_pid_ctrl_parameters_update_action, Qt::AutoConnection);
    //--- declare and set client service ----
    pid_ctrl_parameters_cltService_name = tbname_pid_ctrl_parameters+"_service";
    pid_ctrl_parameters_cltService = nh_.serviceClient<type_pid_ctrl_parameters_cmd>(pid_ctrl_parameters_cltService_name); 
    
    //******************************************
    //**** table : targer_pos2d_parameters  ****   
    //******************************************
    qRegisterMetaType<type_targer_pos2d_parameters>("type_targer_pos2d_parameters");
    qRegisterMetaType<type_targer_pos2d_parameters_cmd>("type_targer_pos2d_parameters_cmd");   
    qRegisterMetaType<dynamic_targer_pos2d_parameters_search_type>("dynamic_targer_pos2d_parameters_search_type");         
    qRegisterMetaType<ptr_targer_pos2d_parameters>("ptr_targer_pos2d_parameters");
    //--- declare signal & slot -------------    
    QObject::connect(this, &ros_controlmodel::targer_pos2d_parameters_delete_Changed, this, &ros_controlmodel::on_targer_pos2d_parameters_delete_action, Qt::AutoConnection);//QueuedConnection
    QObject::connect(this, &ros_controlmodel::targer_pos2d_parameters_query_Changed, this, &ros_controlmodel::on_targer_pos2d_parameters_query_action, Qt::AutoConnection);
    QObject::connect(this, &ros_controlmodel::targer_pos2d_parameters_update_Changed, this, &ros_controlmodel::on_targer_pos2d_parameters_update_action, Qt::AutoConnection);
    //--- declare and set client service ----
    targer_pos2d_parameters_cltService_name = tbname_targer_pos2d_parameters+"_service";
    targer_pos2d_parameters_cltService = nh_.serviceClient<type_targer_pos2d_parameters_cmd>(targer_pos2d_parameters_cltService_name); 
    //******************************************
    //**** table : alarmcode_parameters     ****   
    //******************************************
    qRegisterMetaType<type_alarmcode_parameters>("type_alarmcode_parameters");
    qRegisterMetaType<type_alarmcode_parameters_cmd>("type_alarmcode_parameters_cmd");   
    qRegisterMetaType<dynamic_alarmcode_parameters_search_type>("dynamic_alarmcode_parameters_search_type");         
    qRegisterMetaType<ptr_alarmcode_parameters>("ptr_alarmcode_parameters");
    //--- declare signal & slot -------------    
    QObject::connect(this, &ros_controlmodel::alarmcode_parameters_delete_Changed, this, &ros_controlmodel::on_alarmcode_parameters_delete_action, Qt::AutoConnection);//QueuedConnection
    QObject::connect(this, &ros_controlmodel::alarmcode_parameters_query_Changed, this, &ros_controlmodel::on_alarmcode_parameters_query_action, Qt::AutoConnection);
    QObject::connect(this, &ros_controlmodel::alarmcode_parameters_update_Changed, this, &ros_controlmodel::on_alarmcode_parameters_update_action, Qt::AutoConnection);
    //--- declare and set client service ----
    alarmcode_parameters_cltService_name = tbname_alarmcode_parameters+"_service";
    alarmcode_parameters_cltService = nh_.serviceClient<type_alarmcode_parameters_cmd>(alarmcode_parameters_cltService_name);    

    //******************************************
    //**** table : operatecode_parameters   ****   
    //******************************************
    qRegisterMetaType<type_operatecode_parameters>("type_operatecode_parameters");
    qRegisterMetaType<type_operatecode_parameters_cmd>("type_operatecode_parameters_cmd");   
    qRegisterMetaType<dynamic_operatecode_parameters_search_type>("dynamic_operatecode_parameters_search_type");         
    qRegisterMetaType<ptr_operatecode_parameters>("ptr_operatecode_parameters");
    //--- declare signal & slot -------------    
    QObject::connect(this, &ros_controlmodel::operatecode_parameters_delete_Changed, this, &ros_controlmodel::on_operatecode_parameters_delete_action, Qt::AutoConnection);//QueuedConnection
    QObject::connect(this, &ros_controlmodel::operatecode_parameters_query_Changed, this, &ros_controlmodel::on_operatecode_parameters_query_action, Qt::AutoConnection);
    QObject::connect(this, &ros_controlmodel::operatecode_parameters_update_Changed, this, &ros_controlmodel::on_operatecode_parameters_update_action, Qt::AutoConnection);
    //--- declare and set client service ----
    operatecode_parameters_cltService_name = tbname_operatecode_parameters+"_service";
    operatecode_parameters_cltService = nh_.serviceClient<type_operatecode_parameters_cmd>(operatecode_parameters_cltService_name) ;

    //******************************************
    //**** table : car_alarm_history   ****   
    //******************************************
    qRegisterMetaType<type_car_alarm_history>("type_car_alarm_history");
    qRegisterMetaType<type_car_alarm_history_cmd>("type_car_alarm_history_cmd");   
    qRegisterMetaType<dynamic_car_alarm_history_search_type>("dynamic_car_alarm_history_search_type");         
    qRegisterMetaType<ptr_car_alarm_history>("ptr_car_alarm_history");
    //--- declare signal & slot -------------    
    QObject::connect(this, &ros_controlmodel::car_alarm_history_delete_Changed, this, &ros_controlmodel::on_car_alarm_history_delete_action, Qt::AutoConnection);//QueuedConnection
    QObject::connect(this, &ros_controlmodel::car_alarm_history_query_Changed, this, &ros_controlmodel::on_car_alarm_history_query_action, Qt::AutoConnection);
    QObject::connect(this, &ros_controlmodel::car_alarm_history_update_Changed, this, &ros_controlmodel::on_car_alarm_history_update_action, Qt::AutoConnection);
    //--- declare and set client service ----
    car_alarm_history_cltService_name = tbname_car_alarm_history+"_service";
    car_alarm_history_cltService = nh_.serviceClient<type_car_alarm_history_cmd>(car_alarm_history_cltService_name) ;
    //******************************************
    //**** table : car_operate_history      ****   
    //******************************************
    qRegisterMetaType<type_car_operate_history>("type_car_operate_history");
    qRegisterMetaType<type_car_operate_history_cmd>("type_car_operate_history_cmd");   
    qRegisterMetaType<dynamic_car_operate_history_search_type>("dynamic_car_operate_history_search_type");         
    qRegisterMetaType<ptr_car_operate_history>("ptr_car_operate_history");
    //--- declare signal & slot -------------    
    QObject::connect(this, &ros_controlmodel::car_operate_history_delete_Changed, this, &ros_controlmodel::on_car_operate_history_delete_action, Qt::AutoConnection);//QueuedConnection
    QObject::connect(this, &ros_controlmodel::car_operate_history_query_Changed, this, &ros_controlmodel::on_car_operate_history_query_action, Qt::AutoConnection);
    QObject::connect(this, &ros_controlmodel::car_operate_history_update_Changed, this, &ros_controlmodel::on_car_operate_history_update_action, Qt::AutoConnection);
    //--- declare and set client service ----
    car_operate_history_cltService_name = tbname_car_operate_history+"_service";
    car_operate_history_cltService = nh_.serviceClient<type_car_operate_history_cmd>(car_operate_history_cltService_name) ;
    //******************************************
    //**** table : action_function_parameters***   
    //******************************************
    qRegisterMetaType<type_action_function_parameters>("type_action_function_parameters");
    qRegisterMetaType<type_action_function_parameters_cmd>("type_action_function_parameters_cmd");   
    qRegisterMetaType<dynamic_action_function_parameters_search_type>("dynamic_action_function_parameters_search_type");         
    qRegisterMetaType<ptr_action_function_parameters>("ptr_action_function_parameters");
    //--- declare signal & slot -------------    
    QObject::connect(this, &ros_controlmodel::action_function_parameters_delete_Changed, this, &ros_controlmodel::on_action_function_parameters_delete_action, Qt::AutoConnection);//QueuedConnection
    QObject::connect(this, &ros_controlmodel::action_function_parameters_query_Changed, this, &ros_controlmodel::on_action_function_parameters_query_action, Qt::AutoConnection);
    QObject::connect(this, &ros_controlmodel::action_function_parameters_update_Changed, this, &ros_controlmodel::on_action_function_parameters_update_action, Qt::AutoConnection);
    //--- declare and set client service ----
    action_function_parameters_cltService_name = tbname_action_function_parameters+"_service";
    action_function_parameters_cltService = nh_.serviceClient<type_action_function_parameters_cmd>(action_function_parameters_cltService_name) ;
}
//-----------------------------------------------------------------------------
ros_controlmodel::~ros_controlmodel()
{

}
//------------------------------------------------------- 
void ros_controlmodel::err_type_desc_initSet()
{
    for(int i=0;i<15;i++){
        err_type_desc_TC.push_back("正常");
        err_type_desc_TC.push_back("不允許空白資料！");
        err_type_desc_TC.push_back("資料需為整數格式！");
        err_type_desc_TC.push_back("輸入參數資料錯誤!");
        err_type_desc_TC.push_back("資料索引鍵值錯誤！");
        err_type_desc_TC.push_back("表格資料錯誤！");
        err_type_desc_TC.push_back("編輯參數錯誤！");
        err_type_desc_TC.push_back("搜尋參數錯誤！");
        err_type_desc_TC.push_back("選擇搜尋參數錯誤！");
        err_type_desc_TC.push_back("無任何符合查詢資料！");
        err_type_desc_TC.push_back("新增資料錯誤！");
        err_type_desc_TC.push_back("修改資料錯誤！");
        err_type_desc_TC.push_back("删除資料錯誤！");
        err_type_desc_TC.push_back("查詢資料錯誤！");

        err_type_desc_SC.push_back("正常");
        err_type_desc_SC.push_back("不允许空白资料！");
        err_type_desc_SC.push_back("资料需为整数格式！");
        err_type_desc_SC.push_back("输入参数资料错误!");
        err_type_desc_SC.push_back("资料索引键值错误！");
        err_type_desc_SC.push_back("表格资料错误！");
        err_type_desc_SC.push_back("编辑参数错误！");
        err_type_desc_SC.push_back("搜寻参数错误！");
        err_type_desc_SC.push_back("选择搜寻参数错误！");
        err_type_desc_SC.push_back("无任何符合查询资料！");
        err_type_desc_SC.push_back("新增资料错误！");
        err_type_desc_SC.push_back("修改资料错误！");
        err_type_desc_SC.push_back("删除资料错误！");
        err_type_desc_SC.push_back("查询资料错误！");

        err_type_desc_E.push_back("normal");
        err_type_desc_E.push_back("blank data isn't allowed!");
        err_type_desc_E.push_back("Data must be in integer format！");
        err_type_desc_E.push_back("Input parameter is wrong!");
        err_type_desc_E.push_back("Data index key value error！");
        err_type_desc_E.push_back("Table data is wrong !");
        err_type_desc_E.push_back("parameter error - Edit ！");
        err_type_desc_E.push_back("parameter error - Search") ;
        err_type_desc_E.push_back("parameter error - Option Search");
        err_type_desc_E.push_back("No matching data to inquire condition！");
        err_type_desc_E.push_back("Error - add mode ");
        err_type_desc_E.push_back("Error - modify mode ");
        err_type_desc_E.push_back("Error - delete mode ");
        err_type_desc_E.push_back("Error - inquire mode");
    }
}
//------------------------------------------------------- 
std::string ros_controlmodel::get_error_desc(int lang_type,db_tb_error_type _type)
{
    std::string sRet = "";
    int error_ser = (int) _type ;
    if(lang_type == 1)  //elang_type_E
        sRet = err_type_desc_E[error_ser]; 	
    else if(lang_type == 2) //elang_type_TC
        sRet = err_type_desc_TC[error_ser]; 	
    else if(lang_type == 3) //elang_type_SC
        sRet = err_type_desc_SC[error_ser]; 	
    
    return sRet ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::Load_CntParameter()
{
    ros::NodeHandle pnh("~");   
    
    if(!pnh.getParam("tbname_check_parameters", tbname_check_parameters))
        tbname_check_parameters = "check_parameters" ;	 
    if(!pnh.getParam("tbname_pid_ctrl_parameters", tbname_pid_ctrl_parameters))
        tbname_pid_ctrl_parameters = "pid_ctrl_parameters" ;
    if(!pnh.getParam("tbname_targer_pos2d_parameters", tbname_targer_pos2d_parameters))
        tbname_targer_pos2d_parameters = "targer_pos2d_parameters" ;
    if(!pnh.getParam("tbname_alarmcode_parameters", tbname_alarmcode_parameters))
        tbname_alarmcode_parameters = "alarmcode_parameters" ;   
    if(!pnh.getParam("tbname_operatecode_parameters", tbname_operatecode_parameters))
        tbname_operatecode_parameters = "operatecode_parameters" ; 
    if(!pnh.getParam("tbname_car_alarm_history", tbname_car_alarm_history))
        tbname_car_alarm_history = "car_alarm_history" ;    
    if(!pnh.getParam("tbname_car_operate_history", tbname_car_operate_history))
        tbname_car_operate_history = "car_operate_history" ;  
    if(!pnh.getParam("tbname_action_function_parameters", tbname_action_function_parameters))
        tbname_action_function_parameters = "action_function_parameters" ;      
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : check_parameters                                            ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
void ros_controlmodel::set_check_parameters_cltService(ros::ServiceClient &_cltService)
{
    check_parameters_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_check_parameters_update_action(db_tb_edit_type _edit_type,const ptr_check_parameters &_data)
{  
    check_parameters_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        check_parameters_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    check_parameters_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    check_parameters_cmd_data.request.query_base_index = -1 ;
    check_parameters_cmd_data.request.query_opt_index = -1;
    check_parameters_cmd_data.request.query_parameter = "" ;
    check_parameters_cmd_data.request.req_check_parameters.primary_id = _data->primary_id ;
    check_parameters_cmd_data.request.req_check_parameters.unique_code = _data->unique_code ;
    check_parameters_cmd_data.request.req_check_parameters.base_name = _data->base_name ;
    check_parameters_cmd_data.request.req_check_parameters.out_of_times = _data->out_of_times ;
    check_parameters_cmd_data.request.req_check_parameters.timeout = _data->timeout ;
    check_parameters_cmd_data.request.req_check_parameters.update_time = _data->update_time ;
    
    check_parameters_cltService.call(check_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    check_parameters_error_type = (db_tb_error_type)strtoint(check_parameters_cmd_data.response.error_code,-1) ;
    if(check_parameters_error_type == edb_tb_err_type_none){        
        _update_primary_id = check_parameters_cmd_data.response.primary_id ;
        _update_updatetime = check_parameters_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_check_parameters_delete_action(std::string unique_code)
{
    check_parameters_error_type = edb_tb_err_type_none ;

    check_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    check_parameters_cmd_data.request.query_base_index = -1 ;
    check_parameters_cmd_data.request.query_opt_index = -1;
    check_parameters_cmd_data.request.query_parameter = unique_code ;
    
    check_parameters_cltService.call(check_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    check_parameters_error_type = (db_tb_error_type)strtoint(check_parameters_cmd_data.response.error_code,-1) ;
    if(check_parameters_error_type != edb_tb_err_type_none){
        check_parameters_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_check_parameters_query_action(db_tb_search_type query_base,dynamic_check_parameters_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    check_parameters_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_check_parameters_search_base_name) && 
                (query_opt <= edynamic_check_parameters_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        check_parameters_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        check_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        check_parameters_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        check_parameters_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        check_parameters_cmd_data.request.query_parameter = search_param ;
        //ROS_INFO("<=== %d %f ===>",check_parameters_cmd_data.request.cmd_id,check_parameters_cmd_data.request.query_base_index,
        //                           check_parameters_cmd_data.request.query_opt_index,check_parameters_cmd_data.request.query_parameter.c_str());
        check_parameters_cltService.call(check_parameters_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        //------------------
        check_parameters_error_type = (db_tb_error_type)strtoint(check_parameters_cmd_data.response.error_code,-1) ;
        bRet = (check_parameters_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            check_parameters_results.clear();
            int size = check_parameters_cmd_data.response.result_check_parameters.size();
            for(int i=0;i<size;i++){
                boost::shared_ptr<type_check_parameters> _data = boost::make_shared<type_check_parameters>();
                _data->primary_id = check_parameters_cmd_data.response.result_check_parameters[i].primary_id ;
                _data->unique_code = check_parameters_cmd_data.response.result_check_parameters[i].unique_code ;
                _data->base_name = check_parameters_cmd_data.response.result_check_parameters[i].base_name ;
                _data->out_of_times = check_parameters_cmd_data.response.result_check_parameters[i].out_of_times ;
                _data->timeout = check_parameters_cmd_data.response.result_check_parameters[i].timeout ;
                _data->update_time = check_parameters_cmd_data.response.result_check_parameters[i].update_time ;
                //ROS_INFO("<=== %d %f ===>",_data->out_of_times,_data->timeout);
                check_parameters_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        check_parameters_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
vector<ptr_check_parameters> ros_controlmodel::get_check_parameters_results()
{
    return check_parameters_results ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::get_check_parameters_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type ros_controlmodel::get_check_parameters_error_type() 
{
    return check_parameters_error_type ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : pid_ctrl_parameters                                         ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<boost::shared_ptr<type_pid_ctrl_parameters>> ros_controlmodel::get_pid_ctrl_parameters_results()
{
    return pid_ctrl_parameters_results ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::get_pid_ctrl_parameters_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type ros_controlmodel::get_pid_ctrl_parameters_error_type() 
{
    return pid_ctrl_parameters_error_type ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_pid_ctrl_parameters_update_action(db_tb_edit_type _edit_type,const ptr_pid_ctrl_parameters &_data)
{   
    pid_ctrl_parameters_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        pid_ctrl_parameters_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    pid_ctrl_parameters_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    pid_ctrl_parameters_cmd_data.request.query_base_index = -1 ;
    pid_ctrl_parameters_cmd_data.request.query_opt_index = -1;
    pid_ctrl_parameters_cmd_data.request.query_parameter = "" ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.primary_id = _data->primary_id ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.unique_code = _data->unique_code ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.base_name = _data->base_name ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.target = _data->target ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.tolerance = _data->tolerance ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.min_bound = _data->min_bound ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.max_bound = _data->max_bound ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.d_KP = _data->d_KP ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.d_KI = _data->d_KI ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.d_KD = _data->d_KD ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.b_compensation = _data->b_compensation ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.update_time = _data->update_time ;
    
    pid_ctrl_parameters_cltService.call(pid_ctrl_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    pid_ctrl_parameters_error_type = (db_tb_error_type)strtoint(pid_ctrl_parameters_cmd_data.response.error_code,-1) ;
    if(pid_ctrl_parameters_error_type == edb_tb_err_type_none){        
        _update_primary_id = pid_ctrl_parameters_cmd_data.response.primary_id ;
        _update_updatetime = pid_ctrl_parameters_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_pid_ctrl_parameters_delete_action(std::string unique_code)
{
    pid_ctrl_parameters_error_type = edb_tb_err_type_none ;

    pid_ctrl_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    pid_ctrl_parameters_cmd_data.request.query_base_index = -1 ;
    pid_ctrl_parameters_cmd_data.request.query_opt_index = -1;
    pid_ctrl_parameters_cmd_data.request.query_parameter = unique_code ;
    
    pid_ctrl_parameters_cltService.call(pid_ctrl_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    pid_ctrl_parameters_error_type = (db_tb_error_type)strtoint(pid_ctrl_parameters_cmd_data.response.error_code,-1) ;
    if(pid_ctrl_parameters_error_type != edb_tb_err_type_none){
        pid_ctrl_parameters_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_pid_ctrl_parameters_query_action(db_tb_search_type query_base,dynamic_pid_ctrl_parameters_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    pid_ctrl_parameters_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_pid_ctrl_parameters_search_base_name) && 
                (query_opt <= edynamic_pid_ctrl_parameters_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        pid_ctrl_parameters_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        pid_ctrl_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        pid_ctrl_parameters_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        pid_ctrl_parameters_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        pid_ctrl_parameters_cmd_data.request.query_parameter = search_param ;
        
        pid_ctrl_parameters_cltService.call(pid_ctrl_parameters_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        //------------------
        pid_ctrl_parameters_error_type = (db_tb_error_type)strtoint(pid_ctrl_parameters_cmd_data.response.error_code,-1) ;
        bRet = (pid_ctrl_parameters_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            pid_ctrl_parameters_results.clear();
            int size = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters.size();
            for(int i=0;i<size;i++){
                ptr_pid_ctrl_parameters _data = boost::make_shared<type_pid_ctrl_parameters>();
                _data->primary_id = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].primary_id ;
                _data->unique_code = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].unique_code ;
                _data->base_name = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].base_name ;
                _data->target = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].target ;
                _data->tolerance = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].tolerance ;
                _data->min_bound = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].min_bound ;
                _data->max_bound = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].max_bound ;
                _data->d_KP = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].d_KP ;
                _data->d_KI = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].d_KI ;
                _data->d_KD = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].d_KD ;
                _data->b_compensation = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].b_compensation ;
                _data->update_time = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].update_time ;

                pid_ctrl_parameters_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        pid_ctrl_parameters_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void ros_controlmodel::set_pid_ctrl_parameters_cltService(ros::ServiceClient &_cltService)
{
    pid_ctrl_parameters_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : targer_pos2d_parameters                                     ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<ptr_targer_pos2d_parameters> ros_controlmodel::get_targer_pos2d_parameters_results()
{
    return targer_pos2d_parameters_results ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::get_targer_pos2d_parameters_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type ros_controlmodel::get_targer_pos2d_parameters_error_type() 
{
    return targer_pos2d_parameters_error_type ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_targer_pos2d_parameters_update_action(db_tb_edit_type _edit_type,const ptr_targer_pos2d_parameters &_data)
{   
    targer_pos2d_parameters_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        targer_pos2d_parameters_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    targer_pos2d_parameters_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    targer_pos2d_parameters_cmd_data.request.query_base_index = -1 ;
    targer_pos2d_parameters_cmd_data.request.query_opt_index = -1;
    targer_pos2d_parameters_cmd_data.request.query_parameter = "" ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.primary_id = _data->primary_id ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.unique_code = _data->unique_code ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.base_name = _data->base_name ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.pos_x = _data->pos_x ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.pos_y = _data->pos_y ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.theta = _data->theta ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.rotate_flag = _data->rotate_flag ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.update_time = _data->update_time ;
    
    targer_pos2d_parameters_cltService.call(targer_pos2d_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    targer_pos2d_parameters_error_type = (db_tb_error_type)strtoint(targer_pos2d_parameters_cmd_data.response.error_code,-1) ;
    if(targer_pos2d_parameters_error_type == edb_tb_err_type_none){        
        _update_primary_id = targer_pos2d_parameters_cmd_data.response.primary_id ;
        _update_updatetime = targer_pos2d_parameters_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_targer_pos2d_parameters_delete_action(std::string unique_code)
{
    targer_pos2d_parameters_error_type = edb_tb_err_type_none ;

    targer_pos2d_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    targer_pos2d_parameters_cmd_data.request.query_base_index = -1 ;
    targer_pos2d_parameters_cmd_data.request.query_opt_index = -1;
    targer_pos2d_parameters_cmd_data.request.query_parameter = unique_code ;
    
    targer_pos2d_parameters_cltService.call(targer_pos2d_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    targer_pos2d_parameters_error_type = (db_tb_error_type)strtoint(targer_pos2d_parameters_cmd_data.response.error_code,-1) ;
    if(targer_pos2d_parameters_error_type != edb_tb_err_type_none){
        targer_pos2d_parameters_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_targer_pos2d_parameters_query_action(db_tb_search_type query_base,dynamic_targer_pos2d_parameters_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    targer_pos2d_parameters_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_targer_pos2d_parameters_search_base_name) && 
                (query_opt <= edynamic_targer_pos2d_parameters_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        targer_pos2d_parameters_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        targer_pos2d_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        targer_pos2d_parameters_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        targer_pos2d_parameters_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        targer_pos2d_parameters_cmd_data.request.query_parameter = search_param ;
        
        targer_pos2d_parameters_cltService.call(targer_pos2d_parameters_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        //------------------
        targer_pos2d_parameters_error_type = (db_tb_error_type)strtoint(targer_pos2d_parameters_cmd_data.response.error_code,-1) ;
        bRet = (targer_pos2d_parameters_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            targer_pos2d_parameters_results.clear();
            int size = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters.size();
            for(int i=0;i<size;i++){
                ptr_targer_pos2d_parameters _data = boost::make_shared<type_targer_pos2d_parameters>();
                _data->primary_id = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].primary_id ;
                _data->unique_code = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].unique_code ;
                _data->base_name = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].base_name ;
                _data->pos_x = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].pos_x ;
                _data->pos_y = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].pos_y ;
                _data->theta = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].theta ;
                _data->rotate_flag = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].rotate_flag ;
                _data->update_time = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].update_time ;

                targer_pos2d_parameters_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        targer_pos2d_parameters_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void ros_controlmodel::set_targer_pos2d_parameters_cltService(ros::ServiceClient &_cltService)
{
    targer_pos2d_parameters_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : alarmcode_parameters                                        ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<ptr_alarmcode_parameters> ros_controlmodel::get_alarmcode_parameters_results()
{
    return alarmcode_parameters_results ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::get_alarmcode_parameters_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type ros_controlmodel::get_alarmcode_parameters_error_type() 
{
    return alarmcode_parameters_error_type ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_alarmcode_parameters_update_action(db_tb_edit_type _edit_type, const ptr_alarmcode_parameters &_data)
{   
    alarmcode_parameters_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        alarmcode_parameters_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    alarmcode_parameters_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    alarmcode_parameters_cmd_data.request.query_base_index = -1 ;
    alarmcode_parameters_cmd_data.request.query_opt_index = -1;
    alarmcode_parameters_cmd_data.request.query_parameter = "" ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.primary_id = _data->primary_id ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.unique_code = _data->unique_code ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.base_name = _data->base_name ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.alarm_level = _data->alarm_level ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.alarm_desc_eng = _data->alarm_desc_eng ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.alarm_desc_tc = _data->alarm_desc_tc ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.alarm_desc_sc = _data->alarm_desc_sc ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.update_time = _data->update_time ;
    
    alarmcode_parameters_cltService.call(alarmcode_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    alarmcode_parameters_error_type = (db_tb_error_type)strtoint(alarmcode_parameters_cmd_data.response.error_code,-1) ;
    if(alarmcode_parameters_error_type == edb_tb_err_type_none){        
        _update_primary_id = alarmcode_parameters_cmd_data.response.primary_id ;
        _update_updatetime = alarmcode_parameters_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_alarmcode_parameters_delete_action(std::string unique_code)
{
    alarmcode_parameters_error_type = edb_tb_err_type_none ;

    alarmcode_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    alarmcode_parameters_cmd_data.request.query_base_index = -1 ;
    alarmcode_parameters_cmd_data.request.query_opt_index = -1;
    alarmcode_parameters_cmd_data.request.query_parameter = unique_code ;
    
    alarmcode_parameters_cltService.call(alarmcode_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    alarmcode_parameters_error_type = (db_tb_error_type)strtoint(alarmcode_parameters_cmd_data.response.error_code,-1) ;
    if(alarmcode_parameters_error_type != edb_tb_err_type_none){
        alarmcode_parameters_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_alarmcode_parameters_query_action(db_tb_search_type query_base,dynamic_alarmcode_parameters_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    alarmcode_parameters_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_alarmcode_parameters_search_base_name) && 
                (query_opt <= edynamic_alarmcode_parameters_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        alarmcode_parameters_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        alarmcode_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        alarmcode_parameters_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        alarmcode_parameters_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        alarmcode_parameters_cmd_data.request.query_parameter = search_param ;
        
        alarmcode_parameters_cltService.call(alarmcode_parameters_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        //------------------
        alarmcode_parameters_error_type = (db_tb_error_type)strtoint(alarmcode_parameters_cmd_data.response.error_code,-1) ;
        bRet = (alarmcode_parameters_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            alarmcode_parameters_results.clear();
            int size = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters.size();
            for(int i=0;i<size;i++){
                ptr_alarmcode_parameters _data = boost::make_shared<type_alarmcode_parameters>();
                _data->primary_id = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].primary_id ;
                _data->unique_code = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].unique_code ;
                _data->base_name = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].base_name ;
                _data->alarm_level = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].alarm_level ;
                _data->alarm_desc_eng = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].alarm_desc_eng ;
                _data->alarm_desc_tc = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].alarm_desc_tc ;
                _data->alarm_desc_sc = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].alarm_desc_sc ;
                _data->update_time = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].update_time ;

                alarmcode_parameters_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        alarmcode_parameters_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void ros_controlmodel::set_alarmcode_parameters_cltService(ros::ServiceClient &_cltService)
{
    alarmcode_parameters_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : operatecode_parameters                                      ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<ptr_operatecode_parameters> ros_controlmodel::get_operatecode_parameters_results()
{
    return operatecode_parameters_results ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::get_operatecode_parameters_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type ros_controlmodel::get_operatecode_parameters_error_type() 
{
    return operatecode_parameters_error_type ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_operatecode_parameters_update_action(db_tb_edit_type _edit_type,const ptr_operatecode_parameters &_data)
{   
    operatecode_parameters_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        operatecode_parameters_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    operatecode_parameters_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    operatecode_parameters_cmd_data.request.query_base_index = -1 ;
    operatecode_parameters_cmd_data.request.query_opt_index = -1;
    operatecode_parameters_cmd_data.request.query_parameter = "" ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.primary_id = _data->primary_id ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.unique_code = _data->unique_code ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.base_name = _data->base_name ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.operate_level = _data->operate_level ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.operate_desc_eng = _data->operate_desc_eng ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.operate_desc_tc = _data->operate_desc_tc ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.operate_desc_sc = _data->operate_desc_sc ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.update_time = _data->update_time ;
    
    operatecode_parameters_cltService.call(operatecode_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    operatecode_parameters_error_type = (db_tb_error_type)strtoint(operatecode_parameters_cmd_data.response.error_code,-1) ;
    if(operatecode_parameters_error_type == edb_tb_err_type_none){        
        _update_primary_id = operatecode_parameters_cmd_data.response.primary_id ;
        _update_updatetime = operatecode_parameters_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_operatecode_parameters_delete_action(std::string unique_code)
{
    operatecode_parameters_error_type = edb_tb_err_type_none ;

    operatecode_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    operatecode_parameters_cmd_data.request.query_base_index = -1 ;
    operatecode_parameters_cmd_data.request.query_opt_index = -1;
    operatecode_parameters_cmd_data.request.query_parameter = unique_code ;
    
    operatecode_parameters_cltService.call(operatecode_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    operatecode_parameters_error_type = (db_tb_error_type)strtoint(operatecode_parameters_cmd_data.response.error_code,-1) ;
    if(operatecode_parameters_error_type != edb_tb_err_type_none){
        operatecode_parameters_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_operatecode_parameters_query_action(db_tb_search_type query_base,dynamic_operatecode_parameters_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    operatecode_parameters_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_operatecode_parameters_search_base_name) && 
                (query_opt <= edynamic_operatecode_parameters_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        operatecode_parameters_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        operatecode_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        operatecode_parameters_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        operatecode_parameters_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        operatecode_parameters_cmd_data.request.query_parameter = search_param ;
        operatecode_parameters_cltService.call(operatecode_parameters_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        //------------------
        operatecode_parameters_error_type = (db_tb_error_type)strtoint(operatecode_parameters_cmd_data.response.error_code,-1) ;
        bRet = (operatecode_parameters_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            operatecode_parameters_results.clear();
            int size = operatecode_parameters_cmd_data.response.result_operatecode_parameters.size();
            for(int i=0;i<size;i++){
                ptr_operatecode_parameters _data = boost::make_shared<type_operatecode_parameters>();
                _data->primary_id = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].primary_id ;
                _data->unique_code = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].unique_code ;
                _data->base_name = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].base_name ;
                _data->operate_level = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].operate_level ;
                _data->operate_desc_eng = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].operate_desc_eng ;
                _data->operate_desc_tc = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].operate_desc_tc ;
                _data->operate_desc_sc = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].operate_desc_sc ;
                _data->update_time = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].update_time ;

                operatecode_parameters_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        operatecode_parameters_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void ros_controlmodel::set_operatecode_parameters_cltService(ros::ServiceClient &_cltService)
{
    operatecode_parameters_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : car_alarm_history                                           ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<ptr_car_alarm_history> ros_controlmodel::get_car_alarm_history_results()
{
    return car_alarm_history_results ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::get_car_alarm_history_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type ros_controlmodel::get_car_alarm_history_error_type() 
{
    return car_alarm_history_error_type ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_car_alarm_history_update_action(db_tb_edit_type _edit_type,const ptr_car_alarm_history &_data)
{   
    car_alarm_history_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        car_alarm_history_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    car_alarm_history_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    car_alarm_history_cmd_data.request.query_base_index = -1 ;
    car_alarm_history_cmd_data.request.query_opt_index = -1;
    car_alarm_history_cmd_data.request.query_parameter = "" ;
    car_alarm_history_cmd_data.request.req_car_alarm_history.primary_id = _data->primary_id ;
    car_alarm_history_cmd_data.request.req_car_alarm_history.unique_code = _data->unique_code ;
    car_alarm_history_cmd_data.request.req_car_alarm_history.base_name = _data->base_name ;
    car_alarm_history_cmd_data.request.req_car_alarm_history.occur_time = _data->occur_time ;
    car_alarm_history_cmd_data.request.req_car_alarm_history.alarm_remark = _data->alarm_remark ;
    car_alarm_history_cmd_data.request.req_car_alarm_history.update_time = _data->update_time ;
    
    car_alarm_history_cltService.call(car_alarm_history_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    car_alarm_history_error_type = (db_tb_error_type)strtoint(car_alarm_history_cmd_data.response.error_code,-1) ;
    if(car_alarm_history_error_type == edb_tb_err_type_none){        
        _update_primary_id = car_alarm_history_cmd_data.response.primary_id ;
        _update_updatetime = car_alarm_history_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_car_alarm_history_delete_action(std::string unique_code)
{
    car_alarm_history_error_type = edb_tb_err_type_none ;

    car_alarm_history_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    car_alarm_history_cmd_data.request.query_base_index = -1 ;
    car_alarm_history_cmd_data.request.query_opt_index = -1;
    car_alarm_history_cmd_data.request.query_parameter = unique_code ;
    
    car_alarm_history_cltService.call(car_alarm_history_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    car_alarm_history_error_type = (db_tb_error_type)strtoint(car_alarm_history_cmd_data.response.error_code,-1) ;
    if(car_alarm_history_error_type != edb_tb_err_type_none){
        car_alarm_history_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_car_alarm_history_query_action(db_tb_search_type query_base,dynamic_car_alarm_history_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    car_alarm_history_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_car_alarm_history_search_base_name) && 
                (query_opt <= edynamic_car_alarm_history_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        car_alarm_history_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        car_alarm_history_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        car_alarm_history_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        car_alarm_history_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        car_alarm_history_cmd_data.request.query_parameter = search_param ;        
        
        car_alarm_history_cltService.call(car_alarm_history_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        //------------------
        car_alarm_history_error_type = (db_tb_error_type)strtoint(car_alarm_history_cmd_data.response.error_code,-1) ;
        bRet = (car_alarm_history_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            car_alarm_history_results.clear();
            int size = car_alarm_history_cmd_data.response.result_car_alarm_history.size();
            for(int i=0;i<size;i++){
                ptr_car_alarm_history _data = boost::make_shared<type_car_alarm_history>();
                _data->primary_id = car_alarm_history_cmd_data.response.result_car_alarm_history[i].primary_id ;
                _data->unique_code = car_alarm_history_cmd_data.response.result_car_alarm_history[i].unique_code ;
                _data->base_name = car_alarm_history_cmd_data.response.result_car_alarm_history[i].base_name ;
                _data->occur_time = car_alarm_history_cmd_data.response.result_car_alarm_history[i].occur_time ;
                _data->alarm_remark = car_alarm_history_cmd_data.response.result_car_alarm_history[i].alarm_remark ;
                _data->update_time = car_alarm_history_cmd_data.response.result_car_alarm_history[i].update_time ;

                car_alarm_history_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        car_alarm_history_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void ros_controlmodel::set_car_alarm_history_cltService(ros::ServiceClient &_cltService)
{
    car_alarm_history_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : car_operate_history                                         ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<ptr_car_operate_history> ros_controlmodel::get_car_operate_history_results()
{
    return car_operate_history_results ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::get_car_operate_history_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type ros_controlmodel::get_car_operate_history_error_type() 
{
    return car_operate_history_error_type ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_car_operate_history_update_action(db_tb_edit_type _edit_type,const ptr_car_operate_history &_data)
{   
    car_operate_history_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        car_operate_history_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    car_operate_history_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    car_operate_history_cmd_data.request.query_base_index = -1 ;
    car_operate_history_cmd_data.request.query_opt_index = -1;
    car_operate_history_cmd_data.request.query_parameter = "" ;
    car_operate_history_cmd_data.request.req_car_operate_history.primary_id = _data->primary_id ;
    car_operate_history_cmd_data.request.req_car_operate_history.unique_code = _data->unique_code ;
    car_operate_history_cmd_data.request.req_car_operate_history.base_name = _data->base_name ;
    car_operate_history_cmd_data.request.req_car_operate_history.occur_time = _data->occur_time ;
    car_operate_history_cmd_data.request.req_car_operate_history.alarm_remark = _data->alarm_remark ;
    car_operate_history_cmd_data.request.req_car_operate_history.update_time = _data->update_time ;
    
    car_operate_history_cltService.call(car_operate_history_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    car_operate_history_error_type = (db_tb_error_type)strtoint(car_operate_history_cmd_data.response.error_code,-1) ;
    if(car_operate_history_error_type == edb_tb_err_type_none){        
        _update_primary_id = car_operate_history_cmd_data.response.primary_id ;
        _update_updatetime = car_operate_history_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_car_operate_history_delete_action(std::string unique_code)
{
    car_operate_history_error_type = edb_tb_err_type_none ;

    car_operate_history_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    car_operate_history_cmd_data.request.query_base_index = -1 ;
    car_operate_history_cmd_data.request.query_opt_index = -1;
    car_operate_history_cmd_data.request.query_parameter = unique_code ;
    
    car_operate_history_cltService.call(car_operate_history_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    car_operate_history_error_type = (db_tb_error_type)strtoint(car_operate_history_cmd_data.response.error_code,-1) ;
    if(car_operate_history_error_type != edb_tb_err_type_none){
        car_operate_history_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_car_operate_history_query_action(db_tb_search_type query_base,dynamic_car_operate_history_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    car_operate_history_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_car_operate_history_search_base_name) && 
                (query_opt <= edynamic_car_operate_history_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        car_operate_history_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        car_operate_history_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        car_operate_history_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        car_operate_history_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        car_operate_history_cmd_data.request.query_parameter = search_param ;        
        
        car_operate_history_cltService.call(car_operate_history_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        //------------------
        car_operate_history_error_type = (db_tb_error_type)strtoint(car_operate_history_cmd_data.response.error_code,-1) ;
        bRet = (car_operate_history_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            car_operate_history_results.clear();
            int size = car_operate_history_cmd_data.response.result_car_operate_history.size();
            for(int i=0;i<size;i++){
                ptr_car_operate_history _data = boost::make_shared<type_car_operate_history>();
                _data->primary_id = car_operate_history_cmd_data.response.result_car_operate_history[i].primary_id ;
                _data->unique_code = car_operate_history_cmd_data.response.result_car_operate_history[i].unique_code ;
                _data->base_name = car_operate_history_cmd_data.response.result_car_operate_history[i].base_name ;
                _data->occur_time = car_operate_history_cmd_data.response.result_car_operate_history[i].occur_time ;
                _data->alarm_remark = car_operate_history_cmd_data.response.result_car_operate_history[i].alarm_remark ;
                _data->update_time = car_operate_history_cmd_data.response.result_car_operate_history[i].update_time ;

                car_operate_history_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        car_operate_history_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void ros_controlmodel::set_car_operate_history_cltService(ros::ServiceClient &_cltService)
{
    car_operate_history_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : action_function_parameters                                  ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<ptr_action_function_parameters> ros_controlmodel::get_action_function_parameters_results()
{
    return action_function_parameters_results ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::get_action_function_parameters_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type ros_controlmodel::get_action_function_parameters_error_type() 
{
    return action_function_parameters_error_type ;
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_action_function_parameters_update_action(db_tb_edit_type _edit_type,const ptr_action_function_parameters &_data)
{   
    action_function_parameters_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        action_function_parameters_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    action_function_parameters_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    action_function_parameters_cmd_data.request.query_base_index = -1 ;
    action_function_parameters_cmd_data.request.query_opt_index = -1;
    action_function_parameters_cmd_data.request.query_parameter = "" ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.primary_id = _data->primary_id ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.unique_code = _data->unique_code ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.base_name = _data->base_name ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.function_level = _data->function_level ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.function_ac_name = _data->function_ac_name ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.function_desc_eng = _data->function_desc_eng ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.function_desc_tc = _data->function_desc_tc ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.function_desc_sc = _data->function_desc_sc ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.update_time = _data->update_time ;
    
    action_function_parameters_cltService.call(action_function_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    action_function_parameters_error_type = (db_tb_error_type)strtoint(action_function_parameters_cmd_data.response.error_code,-1) ;
    if(action_function_parameters_error_type == edb_tb_err_type_none){        
        _update_primary_id = action_function_parameters_cmd_data.response.primary_id ;
        _update_updatetime = action_function_parameters_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_action_function_parameters_delete_action(std::string unique_code)
{
    action_function_parameters_error_type = edb_tb_err_type_none ;

    action_function_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    action_function_parameters_cmd_data.request.query_base_index = -1 ;
    action_function_parameters_cmd_data.request.query_opt_index = -1;
    action_function_parameters_cmd_data.request.query_parameter = unique_code ;
    
    action_function_parameters_cltService.call(action_function_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    action_function_parameters_error_type = (db_tb_error_type)strtoint(action_function_parameters_cmd_data.response.error_code,-1) ;
    if(action_function_parameters_error_type != edb_tb_err_type_none){
        action_function_parameters_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void ros_controlmodel::on_action_function_parameters_query_action(db_tb_search_type query_base,dynamic_action_function_parameters_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    action_function_parameters_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_action_function_parameters_search_base_name) && 
                (query_opt <= edynamic_action_function_parameters_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        action_function_parameters_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        action_function_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        action_function_parameters_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        action_function_parameters_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        action_function_parameters_cmd_data.request.query_parameter = search_param ;        
        
        action_function_parameters_cltService.call(action_function_parameters_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        //------------------
        action_function_parameters_error_type = (db_tb_error_type)strtoint(action_function_parameters_cmd_data.response.error_code,-1) ;
        bRet = (action_function_parameters_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            action_function_parameters_results.clear();
            int size = action_function_parameters_cmd_data.response.result_action_function_parameters.size();
            for(int i=0;i<size;i++){
                ptr_action_function_parameters _data = boost::make_shared<type_action_function_parameters>();
                _data->primary_id = action_function_parameters_cmd_data.response.result_action_function_parameters[i].primary_id ;
                _data->unique_code = action_function_parameters_cmd_data.response.result_action_function_parameters[i].unique_code ;
                _data->base_name = action_function_parameters_cmd_data.response.result_action_function_parameters[i].base_name ;
                _data->function_level = action_function_parameters_cmd_data.response.result_action_function_parameters[i].function_level ;
                _data->function_ac_name = action_function_parameters_cmd_data.response.result_action_function_parameters[i].function_ac_name ;
                _data->function_desc_eng = action_function_parameters_cmd_data.response.result_action_function_parameters[i].function_desc_eng ;
                _data->function_desc_tc = action_function_parameters_cmd_data.response.result_action_function_parameters[i].function_desc_tc ;
                _data->function_desc_sc = action_function_parameters_cmd_data.response.result_action_function_parameters[i].function_desc_sc ;
                _data->update_time = action_function_parameters_cmd_data.response.result_action_function_parameters[i].update_time ;

                action_function_parameters_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        action_function_parameters_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void ros_controlmodel::set_action_function_parameters_cltService(ros::ServiceClient &_cltService)
{
    action_function_parameters_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
