#include <car_db_manager/car_db_manager_qtgui_bridge.h>
#include <ros_utility_tools/ros_tools.h>

//#include "car_db_manager/qt_ros_test.h"
#include "car_db_manager/mainwindow.h"
#include <QApplication>
#include <QSystemSemaphore>
#include <QSharedMemory>
#include <QMessageBox>
#include "car_db_manager/utility/qt_generaltools.h"
//-----------------------------------------------------------------------------
//*****************************************************************************
//** main class crlt_messagemanager                                          ** 
//*****************************************************************************
//-----------------------------------------------------------------------------
car_db_manager_qtgui_bridge::car_db_manager_qtgui_bridge(ros::NodeHandle &nh,ros_controlmodel* controlmodel) : nh_(nh),
                                                      crlt_qtgui_Interface(nh),
                                                      _controlmodel(controlmodel)
{ 
    Load_CntParameter();
}
//-----------------------------------------------------------------------------
car_db_manager_qtgui_bridge::~car_db_manager_qtgui_bridge()
{
     
}
//-----------------------------------------------------------------------------
void car_db_manager_qtgui_bridge::Load_CntParameter()
{
    ros::NodeHandle pnh("~");
	//if(!pnh.getParam("udp_PORT_OPEN_RETRY", udp_PORT_OPEN_RETRY))
    //    udp_PORT_OPEN_RETRY = 5 ;	
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//** main enterpoint of this crlt_messagemanager_node                        ** 
//*****************************************************************************
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <QDesktopWidget>
#include <QSettings>
//----------------------------------
bool check_system_run()
{
    const char filename[]  = "/tmp/lockfile";
    int fd = open (filename, O_WRONLY | O_CREAT , 0644);
    if (fd == -1) {
        perror("open lockfile/n");
        return false;
    }
    int flock = lockf(fd, F_TLOCK, 0 );
    if (flock == -1) {
        perror("lock file error/n");
        return false;
    }
    return true ;
}
//----------------------------------
void language_init_set()
{
    QString config_filename = QApplication::applicationDirPath()+"/config/config.cfg";
    QSettings config_set(config_filename,QSettings::IniFormat);
    int lang_type = config_set.value("language/type",-1).toInt();
    if(lang_type == -1){
        config_set.setValue("language/type", (int)elanguage_type_TC);
        lang_type = config_set.value("language/type").toInt();
    }
    qt_generaltools* tools = qt_generaltools::getInstance();
    tools->setlanguage_type((elanguage_type)lang_type);
}
//-----------------------------------------------------------------------------
int main(int argc, char **argv)
{    
    //*** run qt process ********************    
    QApplication app(argc, argv);
    language_init_set();        // language type set   
    //-- Program repeated execution check --
    if(check_system_run()==false){
        qt_generaltools* tools = qt_generaltools::getInstance();
        elanguage_type lang_type = tools->getlanguage_type();
        QString Err_msg = (lang_type == elanguage_type_TC)? "程式運行中，如有需要請依正常程序退出 !" :
                            ((lang_type == elanguage_type_SC)? "程式运行中，如有需要请依正常程序退出":
                               "The program is running, if necessary, please exit according to the normal procedure !");
        QString title_msg  = (lang_type == elanguage_type_TC)? "程式執行錯誤" :
                            ((lang_type == elanguage_type_SC)? "程式执行错误":"Program execution error");
        QMessageBox::information(0,title_msg,Err_msg);
        return 0;
    }
    //*** run ros process *******************
    ros::init(argc, argv, "car_db_manager_qtgui_bridge_node");
    ros::NodeHandle nh;
    ros_controlmodel* _ros_controlmodel = new ros_controlmodel(nh);
    ros_control_related* _ros_control_related = new ros_control_related(nh);
    car_db_manager_qtgui_bridge _qtgui_bridge(nh,_ros_controlmodel);
    
    ros::spinOnce();
    //*** create qt main window for operating GUI ******
    MainWindow win_main;
    win_main.set_ros_controlmodel(_ros_controlmodel,_ros_control_related);
    //-- Place the window in the center of the screen -----
    int width,height ;
    QDesktopWidget* desktop = QApplication::desktop();
    QRect screenRect = desktop->screenGeometry();
    width = screenRect.width();
    height = screenRect.height();
    win_main.move((width - win_main.width()) / 2 , (height - win_main.height()) / 2);
    QPoint point = QPoint((width - win_main.width()) / 2,(height - win_main.height()) / 2);
    win_main.move(point); 
    //----------------------------------------------------
    win_main.show();
    //------------------------
    return app.exec();
}
//-----------------------------------------------------------------------------
