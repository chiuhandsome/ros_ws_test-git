#include "car_db_manager/mainwindow.h"
#include "ui_mainwindow.h"
#include<QSettings>
#include<QWidget>
#include<QPushButton>
#include<QHBoxLayout>
#include <QMessageBox>
#include <QGridLayout>
#include <QDockWidget>
//#include <QLabel>
#include "car_db_manager/qt_app_model.h"
#include "car_db_manager/utility/qt_generaltools.h"
//-----------------------------------------------------------------------------
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowIcon(QIcon(":/png/resource/tools_png/robot_001.png"));
    this->setWindowFlags(Qt::WindowMinMaxButtonsHint);  // only show min & max button

    mainLayout = new QVBoxLayout(ui->module_widget);
    //------------------
    config_filedata_set();
    app_mode = new qt_app_model();
    //------------------
    set_style_sheet();

    b_frm_main_enable = true ;

    QObject::connect(app_mode,SIGNAL(frm_main_enable_Changed(bool)),this,SLOT(set_frm_main_enable(bool)),Qt::QueuedConnection);
    QObject::connect(app_mode,SIGNAL(frm_refresh_Changed()),this,SLOT(set_frm_refresh()),Qt::QueuedConnection);
    //--- declare tool-bar and set close to right side --
    QWidget *spacerWidget = new QWidget(this);
    spacerWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    spacerWidget->setVisible(true);
    ui->mainToolBar->addWidget(spacerWidget);
    ui->mainToolBar->addAction(ui->actionSystem_Close);
    //--- declare status bar --------------------
    _statusbar_lang_title = new QLabel();
    _statusbar_lang_value = new QLabel();
    _statusbar_lang_title->setStyleSheet(_ststus_bar_label_1_ss);
    _statusbar_lang_value->setStyleSheet(_ststus_bar_label_2_ss);
    ui->statusBar->addPermanentWidget(_statusbar_lang_title);
    ui->statusBar->addPermanentWidget(_statusbar_lang_value);
    //----- set init_language --------------------
    qt_generaltools* tools = qt_generaltools::getInstance();
    tools->setlanguage_type(_language_init);
    //----- Form Show ----------------------------
    formshow(_language_init);

    ui->module_widget->setVisible(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::set_style_sheet()
{
    /*QString para1 = "QGroupBox{font: bold 18pt;\
                               color:green;\
                               border: 1px solid silver;\
                               border-radius: 6px;\
                               margin-top: 6px;}";
    QString para2 = "QGroupBox::title {subcontrol-origin: margin; \
                                       left: 12px;\
                                       top:  -8px;\
                                       padding: 0 5px 0 5px;\
                                       }";
    QString para3 = "QGroupBox::indicator:unchecked {image: url(:/png/resource/tools_png/robot_001.png);\
                                       }";
    ui->groupBox->setStyleSheet(para1+" "+para2+" "+para3);*/
    //--------------------------
    _ststus_bar_label_1_ss= "QLabel{font: bold 12pt; color:blue;}";
    _ststus_bar_label_2_ss= "QLabel{font: bold 12pt; color:Green;}";
}

void MainWindow::config_filedata_set()
{
    config_filename = QApplication::applicationDirPath()+"/config/config.cfg";
    QSettings config_set(config_filename,QSettings::IniFormat);
    int lang_type = config_set.value("language/type",-1).toInt();
    if(lang_type == -1){
        config_set.setValue("language/type", (int)elanguage_type_TC);
        lang_type = config_set.value("language/type").toInt();
    }
    _language_init = (elanguage_type)lang_type ;
}

void MainWindow::formshow(elanguage_type language)
{
    main_window_Show();
    status_bar_show();
}

void MainWindow::system_close()
{
    close() ;
}

void MainWindow::on_actionSystem_Close_triggered()
{
    system_close();
}

void MainWindow::set_frm_main_enable(bool b_enable)
{
    ui->menuBar->setEnabled(b_enable);
    ui->mainToolBar->setEnabled(b_enable);
}

void MainWindow::set_frm_refresh()
{
    form_refresh();
}

void MainWindow::on_actionEnglish_triggered()
{
    qt_generaltools* tools = qt_generaltools::getInstance();
    tools->setlanguage_type(elanguage_type_E);
    emit app_mode->frm_refresh_Changed();
}

void MainWindow::on_actionTraditional_Chinese_triggered()
{
    qt_generaltools* tools = qt_generaltools::getInstance();
    tools->setlanguage_type(elanguage_type_TC);
    emit app_mode->frm_refresh_Changed();
}

void MainWindow::on_actionSimplified_Chinese_triggered()
{
    qt_generaltools* tools = qt_generaltools::getInstance();
    tools->setlanguage_type(elanguage_type_SC);
    emit app_mode->frm_refresh_Changed();
}

void MainWindow::status_bar_show()
{
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type language = tools->getlanguage_type() ;
    QString show_key,show_value ;
    if(language == elanguage_type_E){
        show_key = "Language:";
        show_value = "English";
    }
    else if(language == elanguage_type_TC){
        show_key = "語系:";
        show_value = "繁體中文";
    }
    else if(language == elanguage_type_SC){
        show_key = "语系:";
        show_value = "简体中文";
    }
    _statusbar_lang_title->setText(show_key);
    _statusbar_lang_value->setText(show_value);
}

void MainWindow::parse_cofig_language()
{
    config_filename = QApplication::applicationDirPath()+"/config/config.cfg";
    QSettings config_set(config_filename,QSettings::IniFormat);
    config_set.setIniCodec("UTF-8");

    int lang_type = config_set.value("language/type",-1).toInt();
    if(lang_type == -1){
        config_set.setValue("language/type", (int)elanguage_type_TC);
        lang_type = config_set.value("language/type").toInt();
    }
    _language_init = (elanguage_type)lang_type ;
}

void MainWindow::form_refresh()
{
    main_window_Show();
    status_bar_show();
}


void MainWindow::on_actionAlam_Basecode_triggered()
{
    //-- get all data from alarmcode_parameters_table ---
    db_tb_search_type search_type = edb_tb_search_all ;
    dynamic_alarmcode_parameters_search_type opt_search_type = edynamic_alarmcode_parameters_search_base_name ;
    std::string search_param = "all" ;
    emit _ros_controlmodel->alarmcode_parameters_query_Changed(search_type,opt_search_type,search_param);   

    //-- set type of basetable and form show ----   
    frmDB_baseTable* DB_baseTable_form = new frmDB_baseTable(app_mode);
    DB_baseTable_form->control_model_set(_ros_controlmodel);  
    //-------------
    DB_baseTable_form->parse_config_basetable(ebasetb_alarmcode_parameters);
    DB_baseTable_form->form_tabletype_show() ;   
    DB_baseTable_form->setParent(ui->centralWidget);
    DB_baseTable_form->setVisible(true);
    DB_baseTable_form->show();  
    //-- set its parent to disable -------------------
    emit app_mode->frm_main_enable_Changed(false);    
}

void MainWindow::on_actionParameter_check_triggered()
{
    //-- get all data from check_parameters_table ---
    db_tb_search_type search_type = edb_tb_search_all ;
    dynamic_check_parameters_search_type opt_search_type = edynamic_check_parameters_search_base_name ;
    std::string search_param = "all" ;
    emit _ros_controlmodel->check_parameters_query_Changed(search_type,opt_search_type,search_param);   

    //-- set type of basetable and form show ----   
    frmDB_baseTable* DB_baseTable_form = new frmDB_baseTable(app_mode);
    DB_baseTable_form->control_model_set(_ros_controlmodel);  
    //-------------
    DB_baseTable_form->parse_config_basetable(ebasetb_check_parameters);
    DB_baseTable_form->form_tabletype_show() ;   
    DB_baseTable_form->setParent(ui->centralWidget);
    DB_baseTable_form->setVisible(true);
    DB_baseTable_form->show();  
    //-- set its parent to disable -------------------
    emit app_mode->frm_main_enable_Changed(false);
}
//----------------------------------------------------------------------------
void MainWindow::on_actionParameter_PID_triggered()
{
    //-- get all data from pid_ctrl_parameters_table ---
    db_tb_search_type search_type = edb_tb_search_all ;
    dynamic_pid_ctrl_parameters_search_type opt_search_type = edynamic_pid_ctrl_parameters_search_base_name ;
    std::string search_param = "all" ;
    emit _ros_controlmodel->pid_ctrl_parameters_query_Changed(search_type,opt_search_type,search_param);   

    //-- set type of basetable and form show ----   
    frmDB_baseTable* DB_baseTable_form = new frmDB_baseTable(app_mode);
    DB_baseTable_form->control_model_set(_ros_controlmodel);  
    //-------------
    DB_baseTable_form->parse_config_basetable(ebasetb_pid_ctrl_parameters);
    DB_baseTable_form->form_tabletype_show() ;   
    DB_baseTable_form->setParent(ui->centralWidget);
    DB_baseTable_form->setVisible(true);
    DB_baseTable_form->show();  
    //-- set its parent to disable -------------------
    emit app_mode->frm_main_enable_Changed(false);
}
//----------------------------------------------------------------------------
void MainWindow::on_actionParameter_Target_pose_triggered()
{
    //-- get all data from targer_pos2d_parameters_table ---
    db_tb_search_type search_type = edb_tb_search_all ;
    dynamic_targer_pos2d_parameters_search_type opt_search_type = edynamic_targer_pos2d_parameters_search_base_name ;
    std::string search_param = "all" ;
    emit _ros_controlmodel->targer_pos2d_parameters_query_Changed(search_type,opt_search_type,search_param);   

    //-- set type of basetable and form show ----   
    frmDB_baseTable* DB_baseTable_form = new frmDB_baseTable(app_mode);
    DB_baseTable_form->control_model_set(_ros_controlmodel);  
    //-------------
    DB_baseTable_form->parse_config_basetable(ebasetb_targer_pos2d_parameters);
    DB_baseTable_form->form_tabletype_show() ;   
    DB_baseTable_form->setParent(ui->centralWidget);
    DB_baseTable_form->setVisible(true);
    DB_baseTable_form->show();  
    //-- set its parent to disable -------------------
    emit app_mode->frm_main_enable_Changed(false);
}

void MainWindow::on_actionOperate_Basecode_triggered()
{
    //-- get all data from operatecode_parameters_table ---
    db_tb_search_type search_type = edb_tb_search_all ;
    dynamic_operatecode_parameters_search_type opt_search_type = edynamic_operatecode_parameters_search_base_name ;
    std::string search_param = "all" ;
    emit _ros_controlmodel->operatecode_parameters_query_Changed(search_type,opt_search_type,search_param);   

    //-- set type of basetable and form show ----   
    frmDB_baseTable* DB_baseTable_form = new frmDB_baseTable(app_mode);
    DB_baseTable_form->control_model_set(_ros_controlmodel);  
    //-------------
    DB_baseTable_form->parse_config_basetable(ebasetb_operatecode_parameters);
    DB_baseTable_form->form_tabletype_show() ;   
    DB_baseTable_form->setParent(ui->centralWidget);
    DB_baseTable_form->setVisible(true);
    DB_baseTable_form->show();  
    //-- set its parent to disable -------------------
    emit app_mode->frm_main_enable_Changed(false);
}

void MainWindow::on_actionAlarm_History_triggered()
{
    //-- get all data from car_alarm_history_table ---
    db_tb_search_type search_type = edb_tb_search_all ;
    dynamic_car_alarm_history_search_type opt_search_type = edynamic_car_alarm_history_search_base_name ;
    std::string search_param = "all" ;
    emit _ros_controlmodel->car_alarm_history_query_Changed(search_type,opt_search_type,search_param);   

    //-- set type of basetable and form show ----   
    frmDB_baseTable* DB_baseTable_form = new frmDB_baseTable(app_mode);
    DB_baseTable_form->control_model_set(_ros_controlmodel);  
    //-------------
    DB_baseTable_form->parse_config_basetable(ebasetb_car_alarm_history);
    DB_baseTable_form->form_tabletype_show() ;   
    DB_baseTable_form->setParent(ui->centralWidget);
    DB_baseTable_form->setVisible(true);
    DB_baseTable_form->show();  
    //-- set its parent to disable -------------------
    emit app_mode->frm_main_enable_Changed(false);
}

void MainWindow::on_actionOperation_History_triggered()
{
    //-- get all data from car_operate_history_table ---
    db_tb_search_type search_type = edb_tb_search_all ;
    dynamic_car_operate_history_search_type opt_search_type = edynamic_car_operate_history_search_base_name ;
    std::string search_param = "all" ;
    emit _ros_controlmodel->car_operate_history_query_Changed(search_type,opt_search_type,search_param);   

    //-- set type of basetable and form show ----   
    frmDB_baseTable* DB_baseTable_form = new frmDB_baseTable(app_mode);
    DB_baseTable_form->control_model_set(_ros_controlmodel);  
    //-------------
    DB_baseTable_form->parse_config_basetable(ebasetb_car_operate_history);
    DB_baseTable_form->form_tabletype_show() ;   
    DB_baseTable_form->setParent(ui->centralWidget);
    DB_baseTable_form->setVisible(true);
    DB_baseTable_form->show();  
    //-- set its parent to disable -------------------
    emit app_mode->frm_main_enable_Changed(false);    
}

void MainWindow::on_actionFunction_Basecode_triggered()
{
    //-- get all data from action_function_parameters_table ---
    db_tb_search_type search_type = edb_tb_search_all ;
    dynamic_action_function_parameters_search_type opt_search_type = edynamic_action_function_parameters_search_base_name ;
    std::string search_param = "all" ;
    emit _ros_controlmodel->action_function_parameters_query_Changed(search_type,opt_search_type,search_param);   

    //-- set type of basetable and form show ----   
    frmDB_baseTable* DB_baseTable_form = new frmDB_baseTable(app_mode);
    DB_baseTable_form->control_model_set(_ros_controlmodel);  
    //-------------
    DB_baseTable_form->parse_config_basetable(ebasetb_action_function_parameters);
    DB_baseTable_form->form_tabletype_show() ;   
    DB_baseTable_form->setParent(ui->centralWidget);
    DB_baseTable_form->setVisible(true);
    DB_baseTable_form->show();  
    //-- set its parent to disable -------------------
    emit app_mode->frm_main_enable_Changed(false);    
}

void MainWindow::on_actionWorksheet_Manager_triggered()
{
    //-- get all data from action_function_parameters_table ---
    db_tb_search_type search_type = edb_tb_search_all ;
    dynamic_work_sheet_main_search_type opt_search_type = edynamic_work_sheet_main_search_base_name ;
    std::string search_param = "all" ;
    emit _ros_control_related->work_sheet_main_query_Changed(search_type,opt_search_type,search_param);   

    //-- set type of basetable and form show ----   
    frmdb_relateTable* DB_relatetable_form = new frmdb_relateTable(app_mode);
    DB_relatetable_form->control_model_set(_ros_control_related,_ros_controlmodel);  
    //-------------
    DB_relatetable_form->parse_config_relatetb(erelatetb_worksheets);
    DB_relatetable_form->setParent(ui->centralWidget);
    DB_relatetable_form->setVisible(true);
    DB_relatetable_form->show();  
    //-- set its parent to disable -------------------
    emit app_mode->frm_main_enable_Changed(false);    
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//** Self - added functions                                                  **
//*****************************************************************************
//-----------------------------------------------------------------------------
void MainWindow::set_ros_controlmodel(ros_controlmodel* controlmodel,ros_control_related* control_related)
{
    _ros_controlmodel = controlmodel ;
    _ros_control_related = control_related ;
}
//-----------------------------------------------------------------------------
void MainWindow::main_window_Show()
{
    qt_generaltools* tools = qt_generaltools::getInstance();
    elanguage_type language = tools->getlanguage_type() ;
    //---------------------------------------------------
    ui->menuDatabase_Manager->setTitle((language == elanguage_type_TC)? "資料庫管理" :
                                       ((language == elanguage_type_SC)? "资料库管理":"&Database Manager"));
        ui->menuBasis_Data->setTitle((language == elanguage_type_TC)? "基本資料管理" :
                                    ((language == elanguage_type_SC)? "基本资料管理":"&Tables Manager"));
            ui->actionParameter_check->setText((language == elanguage_type_TC)? "錯誤回復參數管理" :
                                               ((language == elanguage_type_SC)? "错误回复参数管理":"&Action Recovery parameters manager"));
            ui->actionParameter_PID->setText((language == elanguage_type_TC)? "PID 控制參數管理" :
                                               ((language == elanguage_type_SC)? "PID 控制参数管理":"&PID control parameter manager"));
            ui->actionParameter_Target_pose->setText((language == elanguage_type_TC)? "目標平面座標參數管理" :
                                               ((language == elanguage_type_SC)? "目标平面座标参数管理":"&Parameter_Target_pose2d manager"));
            ui->actionAlam_Basecode->setText((language == elanguage_type_TC)? "警報編號資料管理" :
                                               ((language == elanguage_type_SC)? "警报编号管理":"&Alarm Code Manager"));
            ui->actionFunction_Basecode->setText((language == elanguage_type_TC)? "功能編號資料管理" :
                                               ((language == elanguage_type_SC)? "功能编号管理":"&Function Code Manager"));
            ui->actionOperate_Basecode->setText((language == elanguage_type_TC)? "操作編號資料管理" :
                                               ((language == elanguage_type_SC)? "操作编号管理":"&Operate Code Manager"));
            //ui->actionAGV_Type_Basecode->setText((language == elanguage_type_TC)? "AGV 編號資料管理" :
            //                                   ((language == elanguage_type_SC)? "AGV 编号管理":"&AGV Code Manager"));
            //ui->actionCell_Controller_Basecode->setText((language == elanguage_type_TC)? "區域控制室編號資料管理" :
            //                                   ((language == elanguage_type_SC)? "区域控制室编号管理":"&Cell-Controller Code Manager"));
        ui->menuAGV_Data->setTitle((language == elanguage_type_TC)? "AGV 基本資料管理" :
                                    ((language == elanguage_type_SC)? "AGV 基本资料管理":"&AGV Basedata Manager"));
            ui->actionWorksheet_Manager->setText((language == elanguage_type_TC)? "AGV 工單資料管理" :
                                                ((language == elanguage_type_SC)? "AGV 工单资料管理":"AGV Work_Sheet Manager"));
    //---------------------------------------------------
    ui->menuSet_up->setTitle((language == elanguage_type_TC)? "設定" :
                                       ((language == elanguage_type_SC)? "设定":"&Set Up"));
        ui->actionparameters_set->setText((language == elanguage_type_TC)? "控制參數設定" :
                                       ((language == elanguage_type_SC)? "控制参数设定":"&parameters setting"));
    //---------------------------------------------------                                   
    ui->menuOperation->setTitle((language == elanguage_type_TC)? "操作" :
                                       ((language == elanguage_type_SC)? "操作":"&Operate"));
        ui->actionProduction_Order_Manager->setText((language == elanguage_type_TC)? "訂單－生產 管理維護" :
                                               ((language == elanguage_type_SC)? "订单－生产 管理维护":"&Order - Product Manager"));
        ui->actionSystem_Close->setText((language == elanguage_type_TC)? "系統離開" :
                                               ((language == elanguage_type_SC)? "系统离开":"&System Exit"));
    //---------------------------------------------------                                           
    ui->menuMaintain->setTitle((language == elanguage_type_TC)? "維護" :
                                       ((language == elanguage_type_SC)? "维护":"&Maintain"));
       ui->actionDevice_Maintain_Manager->setText((language == elanguage_type_TC)? "元件保養維護管理" :
                                       ((language == elanguage_type_SC)? "元件保养维护管理":"&DEvices maintenance and management")); 
    //---------------------------------------------------                                           
    ui->menuInquire->setTitle((language == elanguage_type_TC)? "查詢" :
                                       ((language == elanguage_type_SC)? "查询":"&Inquire"));
        ui->actionAlarm_History->setText((language == elanguage_type_TC)? "警報歷史資料查詢" :
                                               ((language == elanguage_type_SC)? "警报历史资料查询":"&Alarm History Inquirer"));
        ui->actionOperation_History->setText((language == elanguage_type_TC)? "操作歷史資料查詢" :
                                               ((language == elanguage_type_SC)? "操作历史资料查询":"&Operating History Inquirer"));
        ui->actionDevice_maintain_History->setText((language == elanguage_type_TC)? "元件維護歷史資料查詢" :
                                               ((language == elanguage_type_SC)? "元件维护历史资料查询":"&Device maintain History Inquirer"));
    //---------------------------------------------------
    ui->menutools->setTitle((language == elanguage_type_TC)? "工具" :
                                       ((language == elanguage_type_SC)? "工具":"&Tools"));
        ui->menuLanguages->setTitle((language == elanguage_type_TC)? "語系切換" :
                                    ((language == elanguage_type_SC)? "语系切换":"&Language"));
            ui->actionEnglish->setText((language == elanguage_type_TC)? "英文" :
                                               ((language == elanguage_type_SC)? "英文":"&Englisg"));
            ui->actionTraditional_Chinese->setText((language == elanguage_type_TC)? "繁體中文" :
                                               ((language == elanguage_type_SC)? "繁体中文":"&Traditional Chinese"));
            ui->actionSimplified_Chinese->setText((language == elanguage_type_TC)? "簡體中文" :
                                               ((language == elanguage_type_SC)? "简体中文":"&Simple Chinese"));
    //---------------------------------------------------
    ui->menuHelp->setTitle((language == elanguage_type_TC)? "幫助" :
                                       ((language == elanguage_type_SC)? "帮助":"&Help"));
        ui->actionHelp->setText((language == elanguage_type_TC)? "幫助" :
                                               ((language == elanguage_type_SC)? "帮助":"&Help"));
        ui->actionAbout->setText((language == elanguage_type_TC)? "關於" :
                                            ((language == elanguage_type_SC)? "关于":"&About"));
}
//-----------------------------------------------------------------------------
