#include "car_db_manager/qt_app_model.h"

qt_app_model::qt_app_model()
{
    b_frm_main_enable = true ;
}

qt_app_model::~qt_app_model()
{

}

/*void qt_app_model::set_frm_main_enable(bool b_enable)
{
     if (b_frm_main_enable != b_enable) {
         b_frm_main_enable = b_enable;
         emit frm_main_enable_Changed(b_frm_main_enable);
     }
}*/
