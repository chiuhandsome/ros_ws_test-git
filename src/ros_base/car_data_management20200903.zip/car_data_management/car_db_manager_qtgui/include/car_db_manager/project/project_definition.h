#ifndef project_definition_H
#define project_definition_H
//----------------------------------------------------------------------------
typedef enum {
	db_table_OP_None = 0 , db_table_OP_Add ,db_table_OP_Modify , 
        db_table_OP_Delete ,db_table_OP_Inquire
}  db_table_OP_type;
//----------------------------------------------------------------------------
#endif  
