#include <car_db_manager_action.h>
#include <ros_utility_tools/ros_tools.h>
//-----------------------------------------------------------------------------
//*****************************************************************************
//** main class car_db_manager_action                                        ** 
//*****************************************************************************
//-----------------------------------------------------------------------------
car_db_manager_action::car_db_manager_action(ros::NodeHandle &nh) : nh_(nh),
                                                      crlt_action_Interface(nh,"db_process") 
{ 
    Load_CntParameter();
    //crlt_action_Interface = new car_db_manager_action_if(nh,car_db_process_name);
}
//-----------------------------------------------------------------------------
car_db_manager_action::~car_db_manager_action()
{
    //if(crlt_action_Interface)   
    //    delete crlt_action_Interface ;  
}
//-----------------------------------------------------------------------------
void car_db_manager_action::Load_CntParameter()
{
    ros::NodeHandle pnh("~");
    if(!pnh.getParam("car_db_process_name", car_db_process_name))
        car_db_process_name = "/db_process" ;	 
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//** main enterpoint of this car_db_manager_action                        ** 
//*****************************************************************************
//-----------------------------------------------------------------------------
int main(int argc, char **argv)
{
    ros::init(argc, argv, "car_db_manager_action_node");
    ros::NodeHandle nh;
    car_db_manager_action car_db_manager_action(nh);
    
    ros::spin();
    return 0;
}
//-----------------------------------------------------------------------------
