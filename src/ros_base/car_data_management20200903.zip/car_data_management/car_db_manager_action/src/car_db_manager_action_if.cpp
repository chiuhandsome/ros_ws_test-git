#include <car_db_manager_action_if.h>
#include <ros_utility_tools/ros_tools.h>
//-----------------------------------------------------------------------------
car_db_manager_action_if::car_db_manager_action_if(ros::NodeHandle &nh,std::string car_db_process_name) : 
                          nh_(nh), _car_db_crtl_module(nh),
                          car_db_process_as_(nh_,car_db_process_name, boost::bind(&car_db_manager_action_if::car_db_process_CB, this, _1), false),
                          car_db_process_rcvr_as_(nh_,car_db_process_name+"_rcvr", boost::bind(&car_db_manager_action_if::car_db_process_rcvr_CB, this, _1), false)
{
    Load_CntParameter();
    //-----------------
    _current_times = 0 ;
    _retry_times = 2 ;
    //-------------------
    //ROS_INFO("car_db_process_name:%s",car_db_process_name.c_str());
    //car_db_process_as_.start();
    //car_db_process_as_start();
    //car_db_process_rcvr_as_start();
    ROS_INFO("car_db_process_as_.start()");
    car_db_process_as_.start();
    ROS_INFO("car_db_process_rcvr_as_.start()");
    car_db_process_rcvr_as_.start();
    
}
//-----------------------------------------------------------------------------
//-- robot_qtgui_Interface de-constructor ---------------
car_db_manager_action_if::~car_db_manager_action_if()
{
    //delete _mongodbstore_client ;    
}
//-----------------------------------------------------------------------------
void car_db_manager_action_if::car_db_process_as_start()
{
    ROS_INFO("car_db_process_as_.start()");
    car_db_process_as_.start();
}
//-----------------------------------------------------------------------------
void car_db_manager_action_if::car_db_process_rcvr_as_start()
{
    ROS_INFO("car_db_process_rcvr_as_.start()");
    car_db_process_rcvr_as_.start();
}
//-----------------------------------------------------------------------------
void car_db_manager_action_if::Load_CntParameter()
{
    ros::NodeHandle pnh("~");
}
//-----------------------------------------------------------------------------
void car_db_manager_action_if::paras_to_proc_data_vector(std::string parameter)
{
    //ROS_INFO("paras_to_proc_data_vector:%s",parameter.c_str());
    proc_data_vector.clear();
    int found = parameter.find(",");
    while(found!=std::string::npos){
        proc_data_vector.push_back(parameter.substr(found-1));    
        parameter = parameter.substr(found+1,parameter.length()-found-1);
        found = parameter.find(",");
    }
    proc_data_vector.push_back(parameter);  
    /*for(int i=0;i<proc_data_vector.size();i++){
        ROS_INFO("proc_data_vector[%d]:%s",i,proc_data_vector[i].c_str());    
    }*/
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : check_parameters                                            ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::check_parameters_update_action(db_tb_edit_type _edit_type)
{    
    boost::shared_ptr<type_check_parameters> _data = boost::make_shared<type_check_parameters>();
    _data->primary_id = "" ;
    _data->unique_code = proc_data_vector[0] ;
    _data->base_name = proc_data_vector[1] ;
    _data->out_of_times =strtoint(proc_data_vector[2],0) ;
    _data->timeout = strtofloat(proc_data_vector[3],0) ;
    _data->update_time = "" ;

    _car_db_crtl_module.on_check_parameters_update_action(_edit_type,_data); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_check_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::check_parameters_delete_action(std::string unique_code)
{
    _car_db_crtl_module.on_check_parameters_delete_action(unique_code); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_check_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::check_parameters_query_action(db_tb_search_type query_base,dynamic_check_parameters_search_type query_opt,
                                                             std::string search_param)
{
    _car_db_crtl_module.on_check_parameters_query_action(query_base,query_opt,search_param) ;
    db_tb_error_type _error_type = _car_db_crtl_module.get_check_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::table_process_check_parameters(const car_db_manager_msgs::car_db_processGoalConstPtr& goal)//,
		                                                      //car_db_manager_msgs::car_db_processResult _result)
{
    int cmd_id = goal->cmd_id ;
    bool b_result = false ;
    //-- Data Update (1 & 2) ------
    if((cmd_id == (int)edb_tb_edit_add) || (cmd_id == (int)edb_tb_edit_modify)){
        paras_to_proc_data_vector(goal->update_data);
        b_result = check_parameters_update_action((db_tb_edit_type)cmd_id);
    }
    //-- Data Delete (3) ------
    else if(cmd_id == (int)edb_tb_edit_delete){
        b_result = check_parameters_delete_action(goal->query_parameter);
    }
    //-- Data Search (4) ------
    else if(cmd_id == (int)edb_tb_edit_query){
        //ROS_INFO("edb_tb_edit_query");
        db_tb_search_type query_base = (db_tb_search_type)goal->query_base_index ; 
        dynamic_check_parameters_search_type query_opt = (dynamic_check_parameters_search_type)goal->query_opt_index; 
        std::string search_param = goal->query_parameter ;
        b_result = check_parameters_query_action(query_base,query_opt,search_param);
        //ROS_INFO("b_result:%d",b_result);
        if(b_result){
            result_data_vector.clear();
            vector<ptr_check_parameters> act_result = _car_db_crtl_module.get_check_parameters_results();
            int isize = act_result.size();
            //ROS_INFO("isize:%d",isize);
            for(int i=0;i<isize;i++){   
                //std::string timeout = std::to_string(act_result[i]->timeout);
                //std::string out_of_times = std::to_string(act_result[i]->out_of_times);
                //ROS_INFO("out_of_times:%s timeout:%s",out_of_times.c_str(),timeout.c_str());
                std::string _data = act_result[i]->primary_id + "," + act_result[i]->unique_code + "," +
                                    act_result[i]->base_name + "," + std::to_string(act_result[i]->out_of_times) + "," +
                                    std::to_string(act_result[i]->timeout) + "," +act_result[i]->update_time ;
                
                result_data_vector.push_back(_data);
                //ROS_INFO("result_data:%s",_data.c_str());
            }   
        }
    }
    return b_result ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : pid_ctrl_parameters                                         ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::pid_ctrl_parameters_update_action(db_tb_edit_type _edit_type)
{    
    boost::shared_ptr<type_pid_ctrl_parameters> _data = boost::make_shared<type_pid_ctrl_parameters>();
    _data->primary_id = "" ;
    _data->unique_code = proc_data_vector[0] ;
    _data->base_name = proc_data_vector[1] ;
    _data->target =strtoint(proc_data_vector[2],0) ;
    _data->tolerance = strtofloat(proc_data_vector[3],0) ;
    _data->min_bound = strtofloat(proc_data_vector[4],0) ;
    _data->max_bound = strtofloat(proc_data_vector[5],0) ;
    _data->d_KP = strtofloat(proc_data_vector[6],0) ;
    _data->d_KI =strtoint(proc_data_vector[7],0) ;
    _data->d_KD =strtoint(proc_data_vector[8],0) ;
    _data->b_compensation = strtofloat(proc_data_vector[9],0) ;
    _data->update_time = "" ;

    _car_db_crtl_module.on_pid_ctrl_parameters_update_action(_edit_type,_data); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_pid_ctrl_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::pid_ctrl_parameters_delete_action(std::string unique_code)
{
    _car_db_crtl_module.on_pid_ctrl_parameters_delete_action(unique_code); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_pid_ctrl_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::pid_ctrl_parameters_query_action(db_tb_search_type query_base,dynamic_pid_ctrl_parameters_search_type query_opt,
                                                             std::string search_param)
{
    _car_db_crtl_module.on_pid_ctrl_parameters_query_action(query_base,query_opt,search_param) ;
    db_tb_error_type _error_type = _car_db_crtl_module.get_pid_ctrl_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::table_process_pid_ctrl_parameters(const car_db_manager_msgs::car_db_processGoalConstPtr& goal,
		                                                      car_db_manager_msgs::car_db_processResult _result)
{
    int cmd_id = goal->cmd_id ;
    bool b_result = false ;
    //-- Data Update (1 & 2) ------
    if((cmd_id == (int)edb_tb_edit_add) || (cmd_id == (int)edb_tb_edit_modify)){
        paras_to_proc_data_vector(goal->update_data);
        b_result = pid_ctrl_parameters_update_action((db_tb_edit_type)cmd_id);
    }
    //-- Data Delete (3) ------
    else if(cmd_id == (int)edb_tb_edit_delete){
        b_result = pid_ctrl_parameters_delete_action(goal->query_parameter);
    }
    //-- Data Search (4) ------
    else if(cmd_id == (int)edb_tb_edit_query){
        db_tb_search_type query_base = (db_tb_search_type)goal->query_base_index;
        dynamic_pid_ctrl_parameters_search_type query_opt = (dynamic_pid_ctrl_parameters_search_type)goal->query_opt_index; 
        std::string search_param = goal->query_parameter ;
        b_result = pid_ctrl_parameters_query_action(query_base,query_opt,search_param);
        if(b_result){
            result_data_vector.clear();
            vector<ptr_pid_ctrl_parameters> act_result = _car_db_crtl_module.get_pid_ctrl_parameters_results();
            int isize = act_result.size();
            for(int i=0;i<isize;i++){
                /*std::string _data = act_result[i]->primary_id + "," + act_result[i]->unique_code + "," +
                                    act_result[i]->base_name + "," + std::to_string(act_result[i]->target) + "," +
                                    std::to_string(act_result[i]->tolerance) + "," + std::to_string(act_result[i]->min_bound) + "," +
                                    std::to_string(act_result[i]->max_bound) + "," + std::to_string((long double)act_result[i]->d_KP) + "," +
                                    std::to_string(act_result[i]->d_KI) + "," + std::to_string(act_result[i]->d_KD) + "," +
                                    std::to_string(act_result[i]->b_compensation) + "," + act_result[i]->update_time ;                */
                std::string _data = act_result[i]->primary_id + "," + act_result[i]->unique_code + "," +
                                    act_result[i]->base_name + "," + std::to_string(act_result[i]->target) + "," +
                                    std::to_string(act_result[i]->tolerance) + "," + std::to_string(act_result[i]->min_bound) + "," +
                                    std::to_string(act_result[i]->max_bound) + "," + double_str_prec(act_result[i]->d_KP,8) + "," +
                                    double_str_prec(act_result[i]->d_KI,8) + "," + double_str_prec(act_result[i]->d_KD,8) + "," +
                                    std::to_string(act_result[i]->b_compensation) + "," + act_result[i]->update_time ;                     
                result_data_vector.push_back(_data);
                //ROS_INFO("act_result[i]->d_KP:%g",act_result[i]->d_KP);
                //std::string aa = double_str_prec(act_result[i]->d_KP,8) ;
                //ROS_INFO("act_result[i]->d_KP:%s",aa.c_str());
                //ROS_INFO("_data==>%s",_data.c_str());
            }   
        }
    }
    return b_result ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : targer_pos2d_parameters                                         ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::targer_pos2d_parameters_update_action(db_tb_edit_type _edit_type)
{    
    boost::shared_ptr<type_targer_pos2d_parameters> _data = boost::make_shared<type_targer_pos2d_parameters>();
    _data->primary_id = "" ;
    _data->unique_code = proc_data_vector[0] ;
    _data->base_name = proc_data_vector[1] ;
    _data->pos_x =strtoint(proc_data_vector[2],0) ;
    _data->pos_y = strtofloat(proc_data_vector[3],0) ;
    _data->theta = strtofloat(proc_data_vector[4],0) ;
    _data->rotate_flag = strtofloat(proc_data_vector[5],0) ;
    _data->update_time = "" ;

    _car_db_crtl_module.on_targer_pos2d_parameters_update_action(_edit_type,_data); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_targer_pos2d_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::targer_pos2d_parameters_delete_action(std::string unique_code)
{
    _car_db_crtl_module.on_targer_pos2d_parameters_delete_action(unique_code); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_targer_pos2d_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::targer_pos2d_parameters_query_action(db_tb_search_type query_base,dynamic_targer_pos2d_parameters_search_type query_opt,
                                                             std::string search_param)
{
    _car_db_crtl_module.on_targer_pos2d_parameters_query_action(query_base,query_opt,search_param) ;
    db_tb_error_type _error_type = _car_db_crtl_module.get_targer_pos2d_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::table_process_targer_pos2d_parameters(const car_db_manager_msgs::car_db_processGoalConstPtr& goal,
		                                                      car_db_manager_msgs::car_db_processResult _result)
{
    //ROS_INFO("table_process_targer_pos2d_parameters");
    int cmd_id = goal->cmd_id ;
    bool b_result = false ;
    //-- Data Update (1 & 2) ------
    if((cmd_id == (int)edb_tb_edit_add) || (cmd_id == (int)edb_tb_edit_modify)){
        paras_to_proc_data_vector(goal->update_data);
        b_result = targer_pos2d_parameters_update_action((db_tb_edit_type)cmd_id);
    }
    //-- Data Delete (3) ------
    else if(cmd_id == (int)edb_tb_edit_delete){
        b_result = targer_pos2d_parameters_delete_action(goal->query_parameter);
    }
    //-- Data Search (4) ------
    else if(cmd_id == (int)edb_tb_edit_query){
        //ROS_INFO("edb_tb_edit_query");
        db_tb_search_type query_base = (db_tb_search_type)goal->query_base_index;
        dynamic_targer_pos2d_parameters_search_type query_opt = (dynamic_targer_pos2d_parameters_search_type)goal->query_opt_index; 
        std::string search_param = goal->query_parameter ;
        b_result = targer_pos2d_parameters_query_action(query_base,query_opt,search_param);
        //ROS_INFO("b_result:%d",b_result);
        if(b_result){
            //_result.result_data.clear();
            result_data_vector.clear();
            vector<ptr_targer_pos2d_parameters> act_result = _car_db_crtl_module.get_targer_pos2d_parameters_results();
            int isize = act_result.size();
            //ROS_INFO("isize:%d",isize);
            for(int i=0;i<isize;i++){
                std::string _data = act_result[i]->primary_id + "," + act_result[i]->unique_code + "," +
                                    act_result[i]->base_name + "," + std::to_string(act_result[i]->pos_x) + "," +
                                    std::to_string(act_result[i]->pos_y) + "," + std::to_string(act_result[i]->theta) + "," +
                                    std::to_string(act_result[i]->rotate_flag) + "," + act_result[i]->update_time ;  
                result_data_vector.push_back(_data);
                //ROS_INFO("result_data:%s",_data.c_str()); 
            }   
        }
    }
    



    return b_result ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : alarmcode_parameters                                        ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::alarmcode_parameters_update_action(db_tb_edit_type _edit_type)
{    
    boost::shared_ptr<type_alarmcode_parameters> _data = boost::make_shared<type_alarmcode_parameters>();
    _data->primary_id = "" ;
    _data->unique_code = proc_data_vector[0] ;
    _data->base_name = proc_data_vector[1] ;
    _data->alarm_level =strtoint(proc_data_vector[2],0) ;
    _data->alarm_desc_eng = proc_data_vector[3] ;
    _data->alarm_desc_tc = proc_data_vector[4] ;
    _data->alarm_desc_sc = proc_data_vector[5] ;
    _data->update_time = "" ;

    _car_db_crtl_module.on_alarmcode_parameters_update_action(_edit_type,_data); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_alarmcode_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::alarmcode_parameters_delete_action(std::string unique_code)
{
    _car_db_crtl_module.on_alarmcode_parameters_delete_action(unique_code); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_alarmcode_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::alarmcode_parameters_query_action(db_tb_search_type query_base,dynamic_alarmcode_parameters_search_type query_opt,
                                                             std::string search_param)
{
    _car_db_crtl_module.on_alarmcode_parameters_query_action(query_base,query_opt,search_param) ;
    db_tb_error_type _error_type = _car_db_crtl_module.get_alarmcode_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::table_process_alarmcode_parameters(const car_db_manager_msgs::car_db_processGoalConstPtr& goal,
		                                                      car_db_manager_msgs::car_db_processResult _result)
{
    int cmd_id = goal->cmd_id ;
    bool b_result = false ;
    //-- Data Update (1 & 2) ------
    if((cmd_id == (int)edb_tb_edit_add) || (cmd_id == (int)edb_tb_edit_modify)){
        paras_to_proc_data_vector(goal->update_data);
        b_result = alarmcode_parameters_update_action((db_tb_edit_type)cmd_id);
    }
    //-- Data Delete (3) ------
    else if(cmd_id == (int)edb_tb_edit_delete){
        b_result = alarmcode_parameters_delete_action(goal->query_parameter);
    }
    //-- Data Search (4) ------
    else if(cmd_id == (int)edb_tb_edit_query){
        db_tb_search_type query_base = (db_tb_search_type)goal->query_base_index;
        dynamic_alarmcode_parameters_search_type query_opt = (dynamic_alarmcode_parameters_search_type)goal->query_opt_index; 
        std::string search_param = goal->query_parameter ;
        b_result = alarmcode_parameters_query_action(query_base,query_opt,search_param);
        if(b_result){
            result_data_vector.clear();
            vector<ptr_alarmcode_parameters> act_result = _car_db_crtl_module.get_alarmcode_parameters_results();
            int isize = act_result.size();
            for(int i=0;i<isize;i++){
                std::string _data = act_result[i]->primary_id + "," + act_result[i]->unique_code + "," +
                                    act_result[i]->base_name + "," + std::to_string(act_result[i]->alarm_level) + "," +
                                    act_result[i]->alarm_desc_eng + "," + act_result[i]->alarm_desc_tc + "," +
                                    act_result[i]->alarm_desc_sc + "," + act_result[i]->update_time ;                
                result_data_vector.push_back(_data);
                //ROS_INFO("result_data:%s",_data.c_str());
            }   
        }
    }
    return b_result ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : operatecode_parameters                                      ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::operatecode_parameters_update_action(db_tb_edit_type _edit_type)
{    
    boost::shared_ptr<type_operatecode_parameters> _data = boost::make_shared<type_operatecode_parameters>();
    _data->primary_id = "" ;
    _data->unique_code = proc_data_vector[0] ;
    _data->base_name = proc_data_vector[1] ;
    _data->operate_level =strtoint(proc_data_vector[2],0) ;
    _data->operate_desc_eng = proc_data_vector[3] ;
    _data->operate_desc_tc = proc_data_vector[4] ;
    _data->operate_desc_sc = proc_data_vector[5] ;
    _data->update_time = "" ;

    _car_db_crtl_module.on_operatecode_parameters_update_action(_edit_type,_data); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_operatecode_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::operatecode_parameters_delete_action(std::string unique_code)
{
    _car_db_crtl_module.on_operatecode_parameters_delete_action(unique_code); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_operatecode_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::operatecode_parameters_query_action(db_tb_search_type query_base,dynamic_operatecode_parameters_search_type query_opt,
                                                             std::string search_param)
{
    _car_db_crtl_module.on_operatecode_parameters_query_action(query_base,query_opt,search_param) ;
    db_tb_error_type _error_type = _car_db_crtl_module.get_operatecode_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::table_process_operatecode_parameters(const car_db_manager_msgs::car_db_processGoalConstPtr& goal,
		                                                      car_db_manager_msgs::car_db_processResult _result)
{
    int cmd_id = goal->cmd_id ;
    bool b_result = false ;
    //-- Data Update (1 & 2) ------
    if((cmd_id == (int)edb_tb_edit_add) || (cmd_id == (int)edb_tb_edit_modify)){
        paras_to_proc_data_vector(goal->update_data);
        b_result = operatecode_parameters_update_action((db_tb_edit_type)cmd_id);
    }
    //-- Data Delete (3) ------
    else if(cmd_id == (int)edb_tb_edit_delete){
        b_result = operatecode_parameters_delete_action(goal->query_parameter);
    }
    //-- Data Search (4) ------
    else if(cmd_id == (int)edb_tb_edit_query){
        db_tb_search_type query_base = (db_tb_search_type)goal->query_base_index;
        dynamic_operatecode_parameters_search_type query_opt = (dynamic_operatecode_parameters_search_type)goal->query_opt_index; 
        std::string search_param = goal->query_parameter ;
        b_result = operatecode_parameters_query_action(query_base,query_opt,search_param);
        if(b_result){
            result_data_vector.clear();
            vector<ptr_operatecode_parameters> act_result = _car_db_crtl_module.get_operatecode_parameters_results();
            int isize = act_result.size();
            for(int i=0;i<isize;i++){
                std::string _data = act_result[i]->primary_id + "," + act_result[i]->unique_code + "," +
                                    act_result[i]->base_name + "," + std::to_string(act_result[i]->operate_level) + "," +
                                    act_result[i]->operate_desc_eng + "," + act_result[i]->operate_desc_tc + "," +
                                    act_result[i]->operate_desc_sc + "," + act_result[i]->update_time ;                
                result_data_vector.push_back(_data);
                //ROS_INFO("result_data:%s",_data.c_str());
            }   
        }
    }
    return b_result ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : car_alarm_history                                      ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::car_alarm_history_update_action(db_tb_edit_type _edit_type)
{    
    //ROS_INFO("car_alarm_history_update_action"); 
    bool bRet = ((_edit_type == edb_tb_edit_add) && (proc_data_vector.size() == 1)) ||
                ((_edit_type == edb_tb_edit_modify) && (proc_data_vector.size() == 3)) ;
    if(!bRet)   return false ;
    //--------------------------------
    boost::shared_ptr<type_car_alarm_history> _data = boost::make_shared<type_car_alarm_history>();
    _data->primary_id = "" ;
    if(_edit_type == edb_tb_edit_add){
        std::string unique_key = get_UniqueKey();
        //ROS_INFO("get_UniqueKey():%s",unique_key.c_str()); 
        _data->unique_code = unique_key ;
        _data->base_name = proc_data_vector[0] ;
        _data->occur_time = get_Now_LocalTime() ;        
    }
    else{
        _data->unique_code = proc_data_vector[0] ;
        _data->base_name = proc_data_vector[1] ;
        _data->occur_time = proc_data_vector[2] ;     
    }
    _data->alarm_remark = "";
    _data->update_time = "" ; 

    //ROS_INFO("_car_db_crtl_module.on_car_alarm_history_update_action"); 
    _car_db_crtl_module.on_car_alarm_history_update_action(_edit_type,_data); 
    //ROS_INFO("_car_db_crtl_module.on_car_alarm_history_update_action ===>");
    db_tb_error_type _error_type = _car_db_crtl_module.get_car_alarm_history_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::car_alarm_history_delete_action(std::string unique_code)
{
    _car_db_crtl_module.on_car_alarm_history_delete_action(unique_code); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_car_alarm_history_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::car_alarm_history_query_action(db_tb_search_type query_base,dynamic_car_alarm_history_search_type query_opt,
                                                             std::string search_param)
{
    _car_db_crtl_module.on_car_alarm_history_query_action(query_base,query_opt,search_param) ;
    db_tb_error_type _error_type = _car_db_crtl_module.get_car_alarm_history_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::table_process_car_alarm_history(const car_db_manager_msgs::car_db_processGoalConstPtr& goal,
		                                                      car_db_manager_msgs::car_db_processResult _result)
{
    int cmd_id = goal->cmd_id ;
    bool b_result = false ;
    //ROS_INFO("car_alarm_history cmd_id:%d",cmd_id);    
    //-- Data Update (1 & 2) ------
    if((cmd_id == (int)edb_tb_edit_add) || (cmd_id == (int)edb_tb_edit_modify)){
        //ROS_INFO("goal->update_data" );    
        paras_to_proc_data_vector(goal->update_data);
        //ROS_INFO("goal->update_data ==>" );  
        b_result = car_alarm_history_update_action((db_tb_edit_type)cmd_id);
    }
    //-- Data Delete (3) ------
    else if(cmd_id == (int)edb_tb_edit_delete){
        b_result = car_alarm_history_delete_action(goal->query_parameter);
    }
    //-- Data Search (4) ------
    else if(cmd_id == (int)edb_tb_edit_query){
        db_tb_search_type query_base = (db_tb_search_type)goal->query_base_index;
        dynamic_car_alarm_history_search_type query_opt = (dynamic_car_alarm_history_search_type)goal->query_opt_index; 
        std::string search_param = goal->query_parameter ;
        b_result = car_alarm_history_query_action(query_base,query_opt,search_param);
        if(b_result){
            result_data_vector.clear();
            vector<ptr_car_alarm_history> act_result = _car_db_crtl_module.get_car_alarm_history_results();
            int isize = act_result.size();
            for(int i=0;i<isize;i++){
                std::string _data = act_result[i]->primary_id + "," + act_result[i]->unique_code + "," +
                                    act_result[i]->base_name + "," + act_result[i]->occur_time + "," +
                                    act_result[i]->alarm_remark + "," + act_result[i]->update_time ;                
                result_data_vector.push_back(_data);
                //ROS_INFO("result_data:%s",_data.c_str());
            }
        }        
    }
    return b_result ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : car_operate_history                                         ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::car_operate_history_update_action(db_tb_edit_type _edit_type)
{    
    //ROS_INFO("car_operate_history_update_action"); 
    bool bRet = ((_edit_type == edb_tb_edit_add) && (proc_data_vector.size() == 1)) ||
                ((_edit_type == edb_tb_edit_modify) && (proc_data_vector.size() == 3)) ;
    if(!bRet)   return false ;
    //--------------------------------
    boost::shared_ptr<type_car_operate_history> _data = boost::make_shared<type_car_operate_history>();
    _data->primary_id = "" ;
    if(_edit_type == edb_tb_edit_add){
        std::string unique_key = get_UniqueKey();
        //ROS_INFO("get_UniqueKey():%s",unique_key.c_str()); 
        _data->unique_code = unique_key ;
        _data->base_name = proc_data_vector[0] ;
        _data->occur_time = get_Now_LocalTime() ;        
    }
    else{
        _data->unique_code = proc_data_vector[0] ;
        _data->base_name = proc_data_vector[1] ;
        _data->occur_time = proc_data_vector[2] ;     
    }
    _data->alarm_remark = "";
    _data->update_time = "" ; 
    
    //ROS_INFO("_car_db_crtl_module.on_car_operate_history_update_action"); 
    _car_db_crtl_module.on_car_operate_history_update_action(_edit_type,_data); 
    //ROS_INFO("_car_db_crtl_module.on_car_operate_history_update_action ===>");
    db_tb_error_type _error_type = _car_db_crtl_module.get_car_operate_history_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::car_operate_history_delete_action(std::string unique_code)
{
    _car_db_crtl_module.on_car_operate_history_delete_action(unique_code); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_car_operate_history_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::car_operate_history_query_action(db_tb_search_type query_base,dynamic_car_operate_history_search_type query_opt,
                                                             std::string search_param)
{
    _car_db_crtl_module.on_car_operate_history_query_action(query_base,query_opt,search_param) ;
    db_tb_error_type _error_type = _car_db_crtl_module.get_car_operate_history_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::table_process_car_operate_history(const car_db_manager_msgs::car_db_processGoalConstPtr& goal,
		                                                      car_db_manager_msgs::car_db_processResult _result)
{
    int cmd_id = goal->cmd_id ;
    bool b_result = false ;
    //-- Data Update (1 & 2) ------
    if((cmd_id == (int)edb_tb_edit_add) || (cmd_id == (int)edb_tb_edit_modify)){
        paras_to_proc_data_vector(goal->update_data);
        b_result = car_operate_history_update_action((db_tb_edit_type)cmd_id);
    }
    //-- Data Delete (3) ------
    else if(cmd_id == (int)edb_tb_edit_delete){
        b_result = car_operate_history_delete_action(goal->query_parameter);
    }
    //-- Data Search (4) ------
    else if(cmd_id == (int)edb_tb_edit_query){
        db_tb_search_type query_base = (db_tb_search_type)goal->query_base_index;
        dynamic_car_operate_history_search_type query_opt = (dynamic_car_operate_history_search_type)goal->query_opt_index; 
        std::string search_param = goal->query_parameter ;
        b_result = car_operate_history_query_action(query_base,query_opt,search_param);
        if(b_result){
            result_data_vector.clear();
            vector<ptr_car_operate_history> act_result = _car_db_crtl_module.get_car_operate_history_results();
            int isize = act_result.size();
            for(int i=0;i<isize;i++){
                std::string _data = act_result[i]->primary_id + "," + act_result[i]->unique_code + "," +
                                    act_result[i]->base_name + "," + act_result[i]->occur_time + "," +
                                    act_result[i]->alarm_remark + "," + act_result[i]->update_time ;                
                result_data_vector.push_back(_data);
                //ROS_INFO("result_data:%s",_data.c_str());
            }
        }
    }
    return b_result ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : action_function_parameters                                  ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::action_function_parameters_update_action(db_tb_edit_type _edit_type)
{    
    boost::shared_ptr<type_action_function_parameters> _data = boost::make_shared<type_action_function_parameters>();
    _data->primary_id = "" ;
    _data->unique_code = proc_data_vector[0] ;
    _data->base_name = proc_data_vector[1] ;
    _data->function_level =strtoint(proc_data_vector[2],0) ;
    _data->function_ac_name =strtoint(proc_data_vector[3],0) ;
    _data->function_desc_eng = proc_data_vector[4] ;
    _data->function_desc_tc = proc_data_vector[5] ;
    _data->function_desc_sc = proc_data_vector[6] ;
    _data->update_time = proc_data_vector[7] ;

    _car_db_crtl_module.on_action_function_parameters_update_action(_edit_type,_data); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_action_function_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::action_function_parameters_delete_action(std::string unique_code)
{
    _car_db_crtl_module.on_action_function_parameters_delete_action(unique_code); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_action_function_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::action_function_parameters_query_action(db_tb_search_type query_base,dynamic_action_function_parameters_search_type query_opt,
                                                             std::string search_param)
{
    _car_db_crtl_module.on_action_function_parameters_query_action(query_base,query_opt,search_param) ;
    db_tb_error_type _error_type = _car_db_crtl_module.get_action_function_parameters_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::table_process_action_function_parameters(const car_db_manager_msgs::car_db_processGoalConstPtr& goal,
		                                                      car_db_manager_msgs::car_db_processResult _result)
{
    int cmd_id = goal->cmd_id ;
    bool b_result = false ;
    //-- Data Update (1 & 2) ------
    if((cmd_id == (int)edb_tb_edit_add) || (cmd_id == (int)edb_tb_edit_modify)){
        paras_to_proc_data_vector(goal->update_data);
        b_result = action_function_parameters_update_action((db_tb_edit_type)cmd_id);
    }
    //-- Data Delete (3) ------
    else if(cmd_id == (int)edb_tb_edit_delete){
        b_result = action_function_parameters_delete_action(goal->query_parameter);
    }
    //-- Data Search (4) ------
    else if(cmd_id == (int)edb_tb_edit_query){
        db_tb_search_type query_base = (db_tb_search_type)goal->query_base_index;
        dynamic_action_function_parameters_search_type query_opt = (dynamic_action_function_parameters_search_type)goal->query_opt_index; 
        std::string search_param = goal->query_parameter ;
        b_result = action_function_parameters_query_action(query_base,query_opt,search_param);
        if(b_result){
            result_data_vector.clear();
            vector<ptr_action_function_parameters> act_result = _car_db_crtl_module.get_action_function_parameters_results();
            int isize = act_result.size();
            for(int i=0;i<isize;i++){
                std::string _data = act_result[i]->primary_id + "," + act_result[i]->unique_code + "," +
                                    act_result[i]->base_name + "," + std::to_string(act_result[i]->function_level) + "," +
                                    act_result[i]->function_ac_name + "," +act_result[i]->function_desc_eng + "," + 
                                    act_result[i]->function_desc_tc + "," +act_result[i]->function_desc_sc + "," + 
                                    act_result[i]->update_time ;                
                result_data_vector.push_back(_data);
                //ROS_INFO("result_data:%s",_data.c_str());
            }
        }        
    }
    return b_result ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : work_sheet_main                                             ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::work_sheet_main_update_action(db_tb_edit_type _edit_type)
{    
    boost::shared_ptr<type_work_sheet_main> _data = boost::make_shared<type_work_sheet_main>();
    _data->primary_id = "" ;
    _data->unique_code = proc_data_vector[0] ;
    _data->base_name = proc_data_vector[1] ;
    _data->occur_time =proc_data_vector[2] ;
    _data->workitems_num = strtoint(proc_data_vector[3],0) ;
    _data->update_time = "" ;

    _car_db_crtl_module.on_work_sheet_main_update_action(_edit_type,_data); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_work_sheet_main_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::work_sheet_main_delete_action(std::string unique_code)
{
    _car_db_crtl_module.on_work_sheet_main_delete_action(unique_code); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_work_sheet_main_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::work_sheet_main_query_action(db_tb_search_type query_base,dynamic_work_sheet_main_search_type query_opt,
                                                             std::string search_param)
{
    _car_db_crtl_module.on_work_sheet_main_query_action(query_base,query_opt,search_param) ;
    db_tb_error_type _error_type = _car_db_crtl_module.get_work_sheet_main_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::table_process_work_sheet_main(const car_db_manager_msgs::car_db_processGoalConstPtr& goal,
		                                                      car_db_manager_msgs::car_db_processResult _result)
{
    int cmd_id = goal->cmd_id ;
    bool b_result = false ;
    //-- Data Update (1 & 2) ------
    if((cmd_id == (int)edb_tb_edit_add) || (cmd_id == (int)edb_tb_edit_modify)){
        paras_to_proc_data_vector(goal->update_data);
        b_result = work_sheet_main_update_action((db_tb_edit_type)cmd_id);
    }
    //-- Data Delete (3) ------
    else if(cmd_id == (int)edb_tb_edit_delete){
        b_result = work_sheet_main_delete_action(goal->query_parameter);
    }
    //-- Data Search (4) ------
    else if(cmd_id == (int)edb_tb_edit_query){
        db_tb_search_type query_base = (db_tb_search_type)goal->query_base_index;
        dynamic_work_sheet_main_search_type query_opt = (dynamic_work_sheet_main_search_type)goal->query_opt_index; 
        std::string search_param = goal->query_parameter ;
        b_result = work_sheet_main_query_action(query_base,query_opt,search_param);
        if(b_result){
            result_data_vector.clear();
            vector<ptr_work_sheet_main> act_result = _car_db_crtl_module.get_work_sheet_main_results();
            int isize = act_result.size();
            for(int i=0;i<isize;i++){
                std::string _data = act_result[i]->primary_id + "," + act_result[i]->unique_code + "," +
                                    act_result[i]->base_name + "," + act_result[i]->occur_time + "," +
                                    std::to_string(act_result[i]->workitems_num) + "," + act_result[i]->update_time ;                
                result_data_vector.push_back(_data);
                //ROS_INFO("result_data:%s",_data.c_str());
            }
        }        
    }
    return b_result ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : work_sheet_items                                             ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::work_sheet_items_update_action(db_tb_edit_type _edit_type)
{    
    boost::shared_ptr<type_work_sheet_items> _data = boost::make_shared<type_work_sheet_items>();
    _data->primary_id = "" ;
    _data->unique_code = proc_data_vector[0] ;
    _data->base_item_name = proc_data_vector[1] ;    
    _data->item_ser_no = strtoint(proc_data_vector[2],0) ;
    _data->occur_time =proc_data_vector[3] ;
    _data->target_pose_id = proc_data_vector[4] ;
    _data->action_function_id = proc_data_vector[5] ;
    _data->action_function_params = proc_data_vector[6] ;
    _data->remark = proc_data_vector[7] ;
    _data->update_time = "" ;

    _car_db_crtl_module.on_work_sheet_items_update_action(_edit_type,_data); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_work_sheet_items_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::work_sheet_items_delete_action(std::string unique_code)
{
    _car_db_crtl_module.on_work_sheet_items_delete_action(unique_code); 
    db_tb_error_type _error_type = _car_db_crtl_module.get_work_sheet_items_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::work_sheet_items_query_action(db_tb_search_type query_base,dynamic_work_sheet_items_search_type query_opt,
                                                             std::string search_param)
{
    //ROS_INFO("query_base:%d query_opt:%d search_param:%s",query_base,query_opt,search_param.c_str());
    _car_db_crtl_module.on_work_sheet_items_query_action(query_base,query_opt,search_param) ;
    db_tb_error_type _error_type = _car_db_crtl_module.get_work_sheet_items_error_type();
    return (_error_type == edb_tb_err_type_none);
}
//-----------------------------------------------------------------------------
bool car_db_manager_action_if::table_process_work_sheet_items(const car_db_manager_msgs::car_db_processGoalConstPtr& goal,
		                                                      car_db_manager_msgs::car_db_processResult _result)
{
    int cmd_id = goal->cmd_id ;
    bool b_result = false ;
    //-- Data Update (1 & 2) ------
    if((cmd_id == (int)edb_tb_edit_add) || (cmd_id == (int)edb_tb_edit_modify)){
        paras_to_proc_data_vector(goal->update_data);
        b_result = work_sheet_items_update_action((db_tb_edit_type)cmd_id);
    }
    //-- Data Delete (3) ------
    else if(cmd_id == (int)edb_tb_edit_delete){
        b_result = work_sheet_items_delete_action(goal->query_parameter);
    }
    //-- Data Search (4) ------
    else if(cmd_id == (int)edb_tb_edit_query){
        db_tb_search_type query_base = (db_tb_search_type)goal->query_base_index;
        dynamic_work_sheet_items_search_type query_opt = (dynamic_work_sheet_items_search_type)goal->query_opt_index; 
        std::string search_param = goal->query_parameter ;
        b_result = work_sheet_items_query_action(query_base,query_opt,search_param);
        if(b_result){
            result_data_vector.clear();
            vector<ptr_work_sheet_items> act_result = _car_db_crtl_module.get_work_sheet_items_results();
            int isize = act_result.size();
            for(int i=0;i<isize;i++){
                std::string _data = act_result[i]->primary_id + "," + act_result[i]->unique_code + "," +
                                    act_result[i]->base_item_name + "," + std::to_string(act_result[i]->item_ser_no) + "," +
                                    act_result[i]->occur_time + "," + act_result[i]->target_pose_id + "," +
                                    act_result[i]->action_function_id + "," + act_result[i]->action_function_params + "," +
                                    act_result[i]->remark + "," +act_result[i]->update_time ;                
                result_data_vector.push_back(_data);
                //ROS_INFO("result_data:%s",_data.c_str());
            }
        }        
    }
    return b_result ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** callback function for car_db_process_as_ action                     ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
void car_db_manager_action_if::car_db_process_CB(const car_db_manager_msgs::car_db_processGoalConstPtr& goal)
{
    std::string table_name = goal->table_name ;
    int cmd_id = goal->cmd_id ;
    //ROS_INFO("table_name:%s , cmd_id:%d",table_name.c_str(),cmd_id);
    
    if (car_db_process_as_.isPreemptRequested() || !ros::ok()){
        ROS_ERROR("car_db_process_as_ execution preempted.");
        car_db_process_as_.setPreempted();
        return;
    }
    else{
        car_db_manager_msgs::car_db_processResult _result;
        if(_current_times >= _retry_times){
            _result.result = car_db_manager_msgs::car_db_processResult::OUT_OF_TIMES ;
            _current_times = 0 ;
            car_db_process_as_.setAborted(_result);  
        }
        else{  	    
            bool b_result = false ;   
            //ROS_INFO("<< car_db_managment_action pre-waiting 10 >>");
            //ros::Duration(10).sleep();   //for test	          
            if(table_name == "check_parameters"){
                //ROS_INFO("check_parameters");    
                b_result = table_process_check_parameters(goal);//,_result);
            }
            else if(table_name == "pid_ctrl_parameters"){
                b_result = table_process_pid_ctrl_parameters(goal,_result);
            }
            else if(table_name == "targer_pos2d_parameters"){
                //ROS_INFO("targer_pos2d_parameters");
                b_result = table_process_targer_pos2d_parameters(goal,_result);
            }
            else if(table_name == "alarmcode_parameters"){
                b_result = table_process_alarmcode_parameters(goal,_result);
            }
            else if(table_name == "operatecode_parameters"){
                b_result = table_process_operatecode_parameters(goal,_result);
            }
            else if(table_name == "car_alarm_history"){
                //ROS_INFO("car_alarm_history");    
                b_result = table_process_car_alarm_history(goal,_result);
            }
            else if(table_name == "car_operate_history"){
                b_result = table_process_car_operate_history(goal,_result);
            }
            else if(table_name == "action_function_parameters"){
                b_result = table_process_action_function_parameters(goal,_result);
            }
            else if(table_name == "work_sheet_main"){
                b_result = table_process_work_sheet_main(goal,_result);
            }
            else if(table_name == "work_sheet_items"){
                b_result = table_process_work_sheet_items(goal,_result);
            }
            //---------------------------
            if(b_result){
                _result.result = car_db_manager_msgs::car_db_processResult::OK ;
                _current_times = 0 ;
                _result.result_data.clear();
                //ROS_INFO("result_data_vector.size() : %d",result_data_vector.size());
                int counter = result_data_vector.size();
                for(int i=0;i<counter;i++){
                    _result.result_data.push_back(result_data_vector[i]);
                }
                //ROS_INFO("_result counter : %d",_result.result_data.size());
                car_db_process_as_.setSucceeded(_result);                                    
            }
            else{
                _result.result = car_db_manager_msgs::car_db_processResult::NOT_OK ;
                _current_times ++ ;
                car_db_process_as_.setAborted(_result);       
            }	
            //ROS_INFO("<< car_db_managment_action post-waiting 10 >>");
            //ros::Duration(10).sleep();   //for test	
            //ROS_INFO("<< car_db_managment_action end-waiting 10 >>");    	   
        }   
        
    }      
    
}
//-----------------------------------------------------------------------------
void car_db_manager_action_if::car_db_process_rcvr_CB(const car_db_manager_msgs::car_db_process_recoveryGoalConstPtr& goal)
{
    if (car_db_process_rcvr_as_.isPreemptRequested() || !ros::ok()){
        ROS_ERROR("dock_to_rcvr_as execution preempted.");
        car_db_process_rcvr_as_.setPreempted();
        return;
    }
    else{ 
        //clear_costmap_ac() ;
        car_db_manager_msgs::car_db_process_recoveryResult _result;
        _result.result = car_db_manager_msgs::car_db_process_recoveryResult::OK ;
        car_db_process_rcvr_as_.setSucceeded(_result);    
    }
}
//-----------------------------------------------------------------------------
