#include "car_db_control_module.h"
#include <ros_utility_tools/ros_tools.h>
#include <ros/ros.h>
#include <thread>
//-----------------------------------------------------------------------------
car_db_control_module::car_db_control_module(ros::NodeHandle nh) : nh_(nh) 
{
    Load_CntParameter();
    //----------------------------------
    //err_type_desc_initSet();
    //***********************************************************
    //**** declare and set client service for single table   ****   
    //***********************************************************  
    //--- declare and set client service : check_parameters  ----
    check_parameters_cltService_name = tbname_check_parameters+"_service";
    check_parameters_cltService = nh_.serviceClient<type_check_parameters_cmd>(check_parameters_cltService_name); 
    //--- declare and set client service : pid_ctrl_parameters ----
    pid_ctrl_parameters_cltService_name = tbname_pid_ctrl_parameters+"_service";
    pid_ctrl_parameters_cltService = nh_.serviceClient<type_pid_ctrl_parameters_cmd>(pid_ctrl_parameters_cltService_name); 
    //--- declare and set client service : targer_pos2d_parameters ----
    targer_pos2d_parameters_cltService_name = tbname_targer_pos2d_parameters+"_service";
    targer_pos2d_parameters_cltService = nh_.serviceClient<type_targer_pos2d_parameters_cmd>(targer_pos2d_parameters_cltService_name); 
    //--- declare and set client service : alarmcode_parameters ----
    alarmcode_parameters_cltService_name = tbname_alarmcode_parameters+"_service";
    alarmcode_parameters_cltService = nh_.serviceClient<type_alarmcode_parameters_cmd>(alarmcode_parameters_cltService_name);  
    //--- declare and set client service : operatecode_parameters ----
    operatecode_parameters_cltService_name = tbname_operatecode_parameters+"_service";
    operatecode_parameters_cltService = nh_.serviceClient<type_operatecode_parameters_cmd>(operatecode_parameters_cltService_name) ;
    //--- declare and set client service : car_alarm_history----
    car_alarm_history_cltService_name = tbname_car_alarm_history+"_service";
    car_alarm_history_cltService = nh_.serviceClient<type_car_alarm_history_cmd>(car_alarm_history_cltService_name) ;
    //--- declare and set client service : car_operate_history ----
    car_operate_history_cltService_name = tbname_car_operate_history+"_service";
    car_operate_history_cltService = nh_.serviceClient<type_car_operate_history_cmd>(car_operate_history_cltService_name) ;
    //--- declare and set client service : action_function_parameters ----
    action_function_parameters_cltService_name = tbname_action_function_parameters+"_service";
    action_function_parameters_cltService = nh_.serviceClient<type_action_function_parameters_cmd>(action_function_parameters_cltService_name) ;
    //***********************************************************
    //**** declare and set client service for related tables ****   
    //***********************************************************  
    //--- declare and set client service : work_sheet_main and  work_sheet_items----
    work_sheet_main_cltService_name = tbname_work_sheet_main+"_service";
    work_sheet_main_cltService = nh_.serviceClient<type_work_sheet_main_cmd>(work_sheet_main_cltService_name); 

    work_sheet_items_cltService_name = tbname_work_sheet_items+"_service";
    work_sheet_items_cltService = nh_.serviceClient<type_work_sheet_items_cmd>(work_sheet_items_cltService_name);
}
//-----------------------------------------------------------------------------
car_db_control_module::~car_db_control_module()
{

}
//-----------------------------------------------------------------------------
void car_db_control_module::Load_CntParameter()
{
    ros::NodeHandle pnh("~");   
    
    if(!pnh.getParam("tbname_check_parameters", tbname_check_parameters))
        tbname_check_parameters = "check_parameters" ;	 
    if(!pnh.getParam("tbname_pid_ctrl_parameters", tbname_pid_ctrl_parameters))
        tbname_pid_ctrl_parameters = "pid_ctrl_parameters" ;
    if(!pnh.getParam("tbname_targer_pos2d_parameters", tbname_targer_pos2d_parameters))
        tbname_targer_pos2d_parameters = "targer_pos2d_parameters" ;
    if(!pnh.getParam("tbname_alarmcode_parameters", tbname_alarmcode_parameters))
        tbname_alarmcode_parameters = "alarmcode_parameters" ;   
    if(!pnh.getParam("tbname_operatecode_parameters", tbname_operatecode_parameters))
        tbname_operatecode_parameters = "operatecode_parameters" ; 
    if(!pnh.getParam("tbname_car_alarm_history", tbname_car_alarm_history))
        tbname_car_alarm_history = "car_alarm_history" ;    
    if(!pnh.getParam("tbname_car_operate_history", tbname_car_operate_history))
        tbname_car_operate_history = "car_operate_history" ;  
    if(!pnh.getParam("tbname_action_function_parameters", tbname_action_function_parameters))
        tbname_action_function_parameters = "action_function_parameters" ;      
    
    if(!pnh.getParam("tbname_work_sheet_main", tbname_work_sheet_main))
        tbname_work_sheet_main = "work_sheet_main" ;	 
    if(!pnh.getParam("tbname_work_sheet_items", tbname_work_sheet_items))
        tbname_work_sheet_items = "work_sheet_items" ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : check_parameters                                            ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
void car_db_control_module::set_check_parameters_cltService(ros::ServiceClient &_cltService)
{
    check_parameters_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_check_parameters_update_action(db_tb_edit_type _edit_type,const ptr_check_parameters &_data)
{  
    check_parameters_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        check_parameters_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    check_parameters_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    check_parameters_cmd_data.request.query_base_index = -1 ;
    check_parameters_cmd_data.request.query_opt_index = -1;
    check_parameters_cmd_data.request.query_parameter = "" ;
    check_parameters_cmd_data.request.req_check_parameters.primary_id = _data->primary_id ;
    check_parameters_cmd_data.request.req_check_parameters.unique_code = _data->unique_code ;
    check_parameters_cmd_data.request.req_check_parameters.base_name = _data->base_name ;
    check_parameters_cmd_data.request.req_check_parameters.out_of_times = _data->out_of_times ;
    check_parameters_cmd_data.request.req_check_parameters.timeout = _data->timeout ;
    check_parameters_cmd_data.request.req_check_parameters.update_time = _data->update_time ;
    
    check_parameters_cltService.call(check_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    check_parameters_error_type = (db_tb_error_type)strtoint(check_parameters_cmd_data.response.error_code,-1) ;
    if(check_parameters_error_type == edb_tb_err_type_none){        
        _update_primary_id = check_parameters_cmd_data.response.primary_id ;
        _update_updatetime = check_parameters_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_check_parameters_delete_action(std::string unique_code)
{
    check_parameters_error_type = edb_tb_err_type_none ;

    check_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    check_parameters_cmd_data.request.query_base_index = -1 ;
    check_parameters_cmd_data.request.query_opt_index = -1;
    check_parameters_cmd_data.request.query_parameter = unique_code ;
    
    check_parameters_cltService.call(check_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    check_parameters_error_type = (db_tb_error_type)strtoint(check_parameters_cmd_data.response.error_code,-1) ;
    if(check_parameters_error_type != edb_tb_err_type_none){
        check_parameters_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_check_parameters_query_action(db_tb_search_type query_base,dynamic_check_parameters_search_type query_opt,
		                                          std::string search_param)
{
    //ROS_INFO("query_base:%d ,query_opt:%d, search_param:%s",query_base,query_opt,search_param.c_str());
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    check_parameters_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_check_parameters_search_base_name) && 
                (query_opt <= edynamic_check_parameters_search_uptime)) || (query_base != edb_tb_search_special);   

    //ROS_INFO("bRet:%d",bRet);
    if(!bRet){
        check_parameters_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        check_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        check_parameters_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        check_parameters_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        check_parameters_cmd_data.request.query_parameter = search_param ;
        
        check_parameters_cltService.call(check_parameters_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        //------------------
        check_parameters_error_type = (db_tb_error_type)strtoint(check_parameters_cmd_data.response.error_code,-1) ;
        bRet = (check_parameters_error_type == edb_tb_err_type_none) ;
        //ROS_INFO("bRet123:%d",bRet);
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            check_parameters_results.clear();
            int size = check_parameters_cmd_data.response.result_check_parameters.size();
            for(int i=0;i<size;i++){
                boost::shared_ptr<type_check_parameters> _data = boost::make_shared<type_check_parameters>();
                _data->primary_id = check_parameters_cmd_data.response.result_check_parameters[i].primary_id ;
                _data->unique_code = check_parameters_cmd_data.response.result_check_parameters[i].unique_code ;
                _data->base_name = check_parameters_cmd_data.response.result_check_parameters[i].base_name ;
                _data->out_of_times = check_parameters_cmd_data.response.result_check_parameters[i].out_of_times ;
                _data->timeout = check_parameters_cmd_data.response.result_check_parameters[i].timeout ;
                _data->update_time = check_parameters_cmd_data.response.result_check_parameters[i].update_time ;
                //ROS_INFO("===%f %d=======",_data->timeout,_data->out_of_times);
                check_parameters_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        check_parameters_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
vector<ptr_check_parameters> car_db_control_module::get_check_parameters_results()
{
    return check_parameters_results ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::get_check_parameters_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type car_db_control_module::get_check_parameters_error_type() 
{
    return check_parameters_error_type ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : pid_ctrl_parameters                                         ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<boost::shared_ptr<type_pid_ctrl_parameters>> car_db_control_module::get_pid_ctrl_parameters_results()
{
    return pid_ctrl_parameters_results ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::get_pid_ctrl_parameters_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type car_db_control_module::get_pid_ctrl_parameters_error_type() 
{
    return pid_ctrl_parameters_error_type ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_pid_ctrl_parameters_update_action(db_tb_edit_type _edit_type,const ptr_pid_ctrl_parameters &_data)
{   
    pid_ctrl_parameters_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        pid_ctrl_parameters_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    pid_ctrl_parameters_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    pid_ctrl_parameters_cmd_data.request.query_base_index = -1 ;
    pid_ctrl_parameters_cmd_data.request.query_opt_index = -1;
    pid_ctrl_parameters_cmd_data.request.query_parameter = "" ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.primary_id = _data->primary_id ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.unique_code = _data->unique_code ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.base_name = _data->base_name ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.target = _data->target ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.tolerance = _data->tolerance ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.min_bound = _data->min_bound ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.max_bound = _data->max_bound ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.d_KP = _data->d_KP ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.d_KI = _data->d_KI ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.d_KD = _data->d_KD ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.b_compensation = _data->b_compensation ;
    pid_ctrl_parameters_cmd_data.request.req_pid_ctrl_parameters.update_time = _data->update_time ;
    
    pid_ctrl_parameters_cltService.call(pid_ctrl_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    pid_ctrl_parameters_error_type = (db_tb_error_type)strtoint(pid_ctrl_parameters_cmd_data.response.error_code,-1) ;
    if(pid_ctrl_parameters_error_type == edb_tb_err_type_none){        
        _update_primary_id = pid_ctrl_parameters_cmd_data.response.primary_id ;
        _update_updatetime = pid_ctrl_parameters_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_pid_ctrl_parameters_delete_action(std::string unique_code)
{
    pid_ctrl_parameters_error_type = edb_tb_err_type_none ;

    pid_ctrl_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    pid_ctrl_parameters_cmd_data.request.query_base_index = -1 ;
    pid_ctrl_parameters_cmd_data.request.query_opt_index = -1;
    pid_ctrl_parameters_cmd_data.request.query_parameter = unique_code ;
    
    pid_ctrl_parameters_cltService.call(pid_ctrl_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    pid_ctrl_parameters_error_type = (db_tb_error_type)strtoint(pid_ctrl_parameters_cmd_data.response.error_code,-1) ;
    if(pid_ctrl_parameters_error_type != edb_tb_err_type_none){
        pid_ctrl_parameters_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_pid_ctrl_parameters_query_action(db_tb_search_type query_base,dynamic_pid_ctrl_parameters_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    pid_ctrl_parameters_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_pid_ctrl_parameters_search_base_name) && 
                (query_opt <= edynamic_pid_ctrl_parameters_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        pid_ctrl_parameters_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        pid_ctrl_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        pid_ctrl_parameters_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        pid_ctrl_parameters_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        pid_ctrl_parameters_cmd_data.request.query_parameter = search_param ;
        
        pid_ctrl_parameters_cltService.call(pid_ctrl_parameters_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        //------------------
        pid_ctrl_parameters_error_type = (db_tb_error_type)strtoint(pid_ctrl_parameters_cmd_data.response.error_code,-1) ;
        bRet = (pid_ctrl_parameters_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            pid_ctrl_parameters_results.clear();
            int size = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters.size();
            for(int i=0;i<size;i++){
                ptr_pid_ctrl_parameters _data = boost::make_shared<type_pid_ctrl_parameters>();
                _data->primary_id = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].primary_id ;
                _data->unique_code = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].unique_code ;
                _data->base_name = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].base_name ;
                _data->target = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].target ;
                _data->tolerance = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].tolerance ;
                _data->min_bound = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].min_bound ;
                _data->max_bound = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].max_bound ;
                _data->d_KP = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].d_KP ;
                _data->d_KI = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].d_KI ;
                _data->d_KD = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].d_KD ;
                _data->b_compensation = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].b_compensation ;
                _data->update_time = pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].update_time ;

                ROS_INFO("_data->d_KP==>%g pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].d_KP==>%g",_data->d_KP,pid_ctrl_parameters_cmd_data.response.result_pid_ctrl_parameters[i].d_KP);

                pid_ctrl_parameters_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        pid_ctrl_parameters_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void car_db_control_module::set_pid_ctrl_parameters_cltService(ros::ServiceClient &_cltService)
{
    pid_ctrl_parameters_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : targer_pos2d_parameters                                     ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<ptr_targer_pos2d_parameters> car_db_control_module::get_targer_pos2d_parameters_results()
{
    return targer_pos2d_parameters_results ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::get_targer_pos2d_parameters_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type car_db_control_module::get_targer_pos2d_parameters_error_type() 
{
    return targer_pos2d_parameters_error_type ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_targer_pos2d_parameters_update_action(db_tb_edit_type _edit_type,const ptr_targer_pos2d_parameters &_data)
{   
    targer_pos2d_parameters_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        targer_pos2d_parameters_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    targer_pos2d_parameters_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    targer_pos2d_parameters_cmd_data.request.query_base_index = -1 ;
    targer_pos2d_parameters_cmd_data.request.query_opt_index = -1;
    targer_pos2d_parameters_cmd_data.request.query_parameter = "" ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.primary_id = _data->primary_id ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.unique_code = _data->unique_code ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.base_name = _data->base_name ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.pos_x = _data->pos_x ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.pos_y = _data->pos_y ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.theta = _data->theta ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.rotate_flag = _data->rotate_flag ;
    targer_pos2d_parameters_cmd_data.request.req_targer_pos2d_parameters.update_time = _data->update_time ;
    
    targer_pos2d_parameters_cltService.call(targer_pos2d_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    targer_pos2d_parameters_error_type = (db_tb_error_type)strtoint(targer_pos2d_parameters_cmd_data.response.error_code,-1) ;
    if(targer_pos2d_parameters_error_type == edb_tb_err_type_none){        
        _update_primary_id = targer_pos2d_parameters_cmd_data.response.primary_id ;
        _update_updatetime = targer_pos2d_parameters_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_targer_pos2d_parameters_delete_action(std::string unique_code)
{
    targer_pos2d_parameters_error_type = edb_tb_err_type_none ;

    targer_pos2d_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    targer_pos2d_parameters_cmd_data.request.query_base_index = -1 ;
    targer_pos2d_parameters_cmd_data.request.query_opt_index = -1;
    targer_pos2d_parameters_cmd_data.request.query_parameter = unique_code ;
    
    targer_pos2d_parameters_cltService.call(targer_pos2d_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    targer_pos2d_parameters_error_type = (db_tb_error_type)strtoint(targer_pos2d_parameters_cmd_data.response.error_code,-1) ;
    if(targer_pos2d_parameters_error_type != edb_tb_err_type_none){
        targer_pos2d_parameters_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_targer_pos2d_parameters_query_action(db_tb_search_type query_base,dynamic_targer_pos2d_parameters_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    targer_pos2d_parameters_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_targer_pos2d_parameters_search_base_name) && 
                (query_opt <= edynamic_targer_pos2d_parameters_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        targer_pos2d_parameters_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        targer_pos2d_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        targer_pos2d_parameters_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        targer_pos2d_parameters_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        targer_pos2d_parameters_cmd_data.request.query_parameter = search_param ;
        
        targer_pos2d_parameters_cltService.call(targer_pos2d_parameters_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        //------------------
        targer_pos2d_parameters_error_type = (db_tb_error_type)strtoint(targer_pos2d_parameters_cmd_data.response.error_code,-1) ;
        bRet = (targer_pos2d_parameters_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            targer_pos2d_parameters_results.clear();
            int size = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters.size();
            for(int i=0;i<size;i++){
                ptr_targer_pos2d_parameters _data = boost::make_shared<type_targer_pos2d_parameters>();
                _data->primary_id = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].primary_id ;
                _data->unique_code = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].unique_code ;
                _data->base_name = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].base_name ;
                _data->pos_x = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].pos_x ;
                _data->pos_y = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].pos_y ;
                _data->theta = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].theta ;
                _data->rotate_flag = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].rotate_flag ;
                _data->update_time = targer_pos2d_parameters_cmd_data.response.result_targer_pos2d_parameters[i].update_time ;

                targer_pos2d_parameters_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        targer_pos2d_parameters_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void car_db_control_module::set_targer_pos2d_parameters_cltService(ros::ServiceClient &_cltService)
{
    targer_pos2d_parameters_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : alarmcode_parameters                                        ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<ptr_alarmcode_parameters> car_db_control_module::get_alarmcode_parameters_results()
{
    return alarmcode_parameters_results ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::get_alarmcode_parameters_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type car_db_control_module::get_alarmcode_parameters_error_type() 
{
    return alarmcode_parameters_error_type ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_alarmcode_parameters_update_action(db_tb_edit_type _edit_type, const ptr_alarmcode_parameters &_data)
{   
    alarmcode_parameters_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        alarmcode_parameters_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    alarmcode_parameters_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    alarmcode_parameters_cmd_data.request.query_base_index = -1 ;
    alarmcode_parameters_cmd_data.request.query_opt_index = -1;
    alarmcode_parameters_cmd_data.request.query_parameter = "" ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.primary_id = _data->primary_id ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.unique_code = _data->unique_code ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.base_name = _data->base_name ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.alarm_level = _data->alarm_level ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.alarm_desc_eng = _data->alarm_desc_eng ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.alarm_desc_tc = _data->alarm_desc_tc ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.alarm_desc_sc = _data->alarm_desc_sc ;
    alarmcode_parameters_cmd_data.request.req_alarmcode_parameters.update_time = _data->update_time ;
    
    alarmcode_parameters_cltService.call(alarmcode_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    alarmcode_parameters_error_type = (db_tb_error_type)strtoint(alarmcode_parameters_cmd_data.response.error_code,-1) ;
    if(alarmcode_parameters_error_type == edb_tb_err_type_none){        
        _update_primary_id = alarmcode_parameters_cmd_data.response.primary_id ;
        _update_updatetime = alarmcode_parameters_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_alarmcode_parameters_delete_action(std::string unique_code)
{
    alarmcode_parameters_error_type = edb_tb_err_type_none ;

    alarmcode_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    alarmcode_parameters_cmd_data.request.query_base_index = -1 ;
    alarmcode_parameters_cmd_data.request.query_opt_index = -1;
    alarmcode_parameters_cmd_data.request.query_parameter = unique_code ;
    
    alarmcode_parameters_cltService.call(alarmcode_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    alarmcode_parameters_error_type = (db_tb_error_type)strtoint(alarmcode_parameters_cmd_data.response.error_code,-1) ;
    if(alarmcode_parameters_error_type != edb_tb_err_type_none){
        alarmcode_parameters_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_alarmcode_parameters_query_action(db_tb_search_type query_base,dynamic_alarmcode_parameters_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    alarmcode_parameters_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_alarmcode_parameters_search_base_name) && 
                (query_opt <= edynamic_alarmcode_parameters_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        alarmcode_parameters_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        alarmcode_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        alarmcode_parameters_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        alarmcode_parameters_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        alarmcode_parameters_cmd_data.request.query_parameter = search_param ;
        
        alarmcode_parameters_cltService.call(alarmcode_parameters_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        //------------------
        alarmcode_parameters_error_type = (db_tb_error_type)strtoint(alarmcode_parameters_cmd_data.response.error_code,-1) ;
        bRet = (alarmcode_parameters_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            alarmcode_parameters_results.clear();
            int size = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters.size();
            for(int i=0;i<size;i++){
                ptr_alarmcode_parameters _data = boost::make_shared<type_alarmcode_parameters>();
                _data->primary_id = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].primary_id ;
                _data->unique_code = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].unique_code ;
                _data->base_name = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].base_name ;
                _data->alarm_level = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].alarm_level ;
                _data->alarm_desc_eng = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].alarm_desc_eng ;
                _data->alarm_desc_tc = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].alarm_desc_tc ;
                _data->alarm_desc_sc = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].alarm_desc_sc ;
                _data->update_time = alarmcode_parameters_cmd_data.response.result_alarmcode_parameters[i].update_time ;

                alarmcode_parameters_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        alarmcode_parameters_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void car_db_control_module::set_alarmcode_parameters_cltService(ros::ServiceClient &_cltService)
{
    alarmcode_parameters_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : operatecode_parameters                                      ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<ptr_operatecode_parameters> car_db_control_module::get_operatecode_parameters_results()
{
    return operatecode_parameters_results ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::get_operatecode_parameters_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type car_db_control_module::get_operatecode_parameters_error_type() 
{
    return operatecode_parameters_error_type ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_operatecode_parameters_update_action(db_tb_edit_type _edit_type,const ptr_operatecode_parameters &_data)
{   
    operatecode_parameters_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        operatecode_parameters_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    operatecode_parameters_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    operatecode_parameters_cmd_data.request.query_base_index = -1 ;
    operatecode_parameters_cmd_data.request.query_opt_index = -1;
    operatecode_parameters_cmd_data.request.query_parameter = "" ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.primary_id = _data->primary_id ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.unique_code = _data->unique_code ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.base_name = _data->base_name ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.operate_level = _data->operate_level ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.operate_desc_eng = _data->operate_desc_eng ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.operate_desc_tc = _data->operate_desc_tc ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.operate_desc_sc = _data->operate_desc_sc ;
    operatecode_parameters_cmd_data.request.req_operatecode_parameters.update_time = _data->update_time ;
    
    operatecode_parameters_cltService.call(operatecode_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    operatecode_parameters_error_type = (db_tb_error_type)strtoint(operatecode_parameters_cmd_data.response.error_code,-1) ;
    if(operatecode_parameters_error_type == edb_tb_err_type_none){        
        _update_primary_id = operatecode_parameters_cmd_data.response.primary_id ;
        _update_updatetime = operatecode_parameters_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_operatecode_parameters_delete_action(std::string unique_code)
{
    operatecode_parameters_error_type = edb_tb_err_type_none ;

    operatecode_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    operatecode_parameters_cmd_data.request.query_base_index = -1 ;
    operatecode_parameters_cmd_data.request.query_opt_index = -1;
    operatecode_parameters_cmd_data.request.query_parameter = unique_code ;
    
    operatecode_parameters_cltService.call(operatecode_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    operatecode_parameters_error_type = (db_tb_error_type)strtoint(operatecode_parameters_cmd_data.response.error_code,-1) ;
    if(operatecode_parameters_error_type != edb_tb_err_type_none){
        operatecode_parameters_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_operatecode_parameters_query_action(db_tb_search_type query_base,dynamic_operatecode_parameters_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    operatecode_parameters_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_operatecode_parameters_search_base_name) && 
                (query_opt <= edynamic_operatecode_parameters_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        operatecode_parameters_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        operatecode_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        operatecode_parameters_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        operatecode_parameters_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        operatecode_parameters_cmd_data.request.query_parameter = search_param ;
        operatecode_parameters_cltService.call(operatecode_parameters_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        //------------------
        operatecode_parameters_error_type = (db_tb_error_type)strtoint(operatecode_parameters_cmd_data.response.error_code,-1) ;
        bRet = (operatecode_parameters_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            operatecode_parameters_results.clear();
            int size = operatecode_parameters_cmd_data.response.result_operatecode_parameters.size();
            for(int i=0;i<size;i++){
                ptr_operatecode_parameters _data = boost::make_shared<type_operatecode_parameters>();
                _data->primary_id = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].primary_id ;
                _data->unique_code = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].unique_code ;
                _data->base_name = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].base_name ;
                _data->operate_level = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].operate_level ;
                _data->operate_desc_eng = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].operate_desc_eng ;
                _data->operate_desc_tc = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].operate_desc_tc ;
                _data->operate_desc_sc = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].operate_desc_sc ;
                _data->update_time = operatecode_parameters_cmd_data.response.result_operatecode_parameters[i].update_time ;

                operatecode_parameters_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        operatecode_parameters_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void car_db_control_module::set_operatecode_parameters_cltService(ros::ServiceClient &_cltService)
{
    operatecode_parameters_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : car_alarm_history                                           ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<ptr_car_alarm_history> car_db_control_module::get_car_alarm_history_results()
{
    return car_alarm_history_results ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::get_car_alarm_history_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type car_db_control_module::get_car_alarm_history_error_type() 
{
    return car_alarm_history_error_type ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_car_alarm_history_update_action(db_tb_edit_type _edit_type,const ptr_car_alarm_history &_data)
{   
    //ROS_INFO("on_car_alarm_history_update_action" );  
    car_alarm_history_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        car_alarm_history_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    car_alarm_history_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    car_alarm_history_cmd_data.request.query_base_index = -1 ;
    car_alarm_history_cmd_data.request.query_opt_index = -1;
    car_alarm_history_cmd_data.request.query_parameter = "" ;
    car_alarm_history_cmd_data.request.req_car_alarm_history.primary_id = _data->primary_id ;
    car_alarm_history_cmd_data.request.req_car_alarm_history.unique_code = _data->unique_code ;
    car_alarm_history_cmd_data.request.req_car_alarm_history.base_name = _data->base_name ;
    car_alarm_history_cmd_data.request.req_car_alarm_history.occur_time = _data->occur_time ;
    car_alarm_history_cmd_data.request.req_car_alarm_history.alarm_remark = _data->alarm_remark ;
    car_alarm_history_cmd_data.request.req_car_alarm_history.update_time = _data->update_time ;
    
    car_alarm_history_cltService.call(car_alarm_history_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    car_alarm_history_error_type = (db_tb_error_type)strtoint(car_alarm_history_cmd_data.response.error_code,-1) ;
    if(car_alarm_history_error_type == edb_tb_err_type_none){        
        _update_primary_id = car_alarm_history_cmd_data.response.primary_id ;
        _update_updatetime = car_alarm_history_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_car_alarm_history_delete_action(std::string unique_code)
{
    car_alarm_history_error_type = edb_tb_err_type_none ;

    car_alarm_history_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    car_alarm_history_cmd_data.request.query_base_index = -1 ;
    car_alarm_history_cmd_data.request.query_opt_index = -1;
    car_alarm_history_cmd_data.request.query_parameter = unique_code ;
    
    car_alarm_history_cltService.call(car_alarm_history_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    car_alarm_history_error_type = (db_tb_error_type)strtoint(car_alarm_history_cmd_data.response.error_code,-1) ;
    if(car_alarm_history_error_type != edb_tb_err_type_none){
        car_alarm_history_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_car_alarm_history_query_action(db_tb_search_type query_base,dynamic_car_alarm_history_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    car_alarm_history_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_car_alarm_history_search_base_name) && 
                (query_opt <= edynamic_car_alarm_history_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        car_alarm_history_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        car_alarm_history_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        car_alarm_history_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        car_alarm_history_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        car_alarm_history_cmd_data.request.query_parameter = search_param ;        
        
        car_alarm_history_cltService.call(car_alarm_history_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        //------------------
        car_alarm_history_error_type = (db_tb_error_type)strtoint(car_alarm_history_cmd_data.response.error_code,-1) ;
        bRet = (car_alarm_history_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            car_alarm_history_results.clear();
            int size = car_alarm_history_cmd_data.response.result_car_alarm_history.size();
            for(int i=0;i<size;i++){
                ptr_car_alarm_history _data = boost::make_shared<type_car_alarm_history>();
                _data->primary_id = car_alarm_history_cmd_data.response.result_car_alarm_history[i].primary_id ;
                _data->unique_code = car_alarm_history_cmd_data.response.result_car_alarm_history[i].unique_code ;
                _data->base_name = car_alarm_history_cmd_data.response.result_car_alarm_history[i].base_name ;
                _data->occur_time = car_alarm_history_cmd_data.response.result_car_alarm_history[i].occur_time ;
                _data->alarm_remark = car_alarm_history_cmd_data.response.result_car_alarm_history[i].alarm_remark ;
                _data->update_time = car_alarm_history_cmd_data.response.result_car_alarm_history[i].update_time ;

                car_alarm_history_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        car_alarm_history_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void car_db_control_module::set_car_alarm_history_cltService(ros::ServiceClient &_cltService)
{
    car_alarm_history_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : car_operate_history                                         ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<ptr_car_operate_history> car_db_control_module::get_car_operate_history_results()
{
    return car_operate_history_results ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::get_car_operate_history_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type car_db_control_module::get_car_operate_history_error_type() 
{
    return car_operate_history_error_type ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_car_operate_history_update_action(db_tb_edit_type _edit_type,const ptr_car_operate_history &_data)
{   
    car_operate_history_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        car_operate_history_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    car_operate_history_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    car_operate_history_cmd_data.request.query_base_index = -1 ;
    car_operate_history_cmd_data.request.query_opt_index = -1;
    car_operate_history_cmd_data.request.query_parameter = "" ;
    car_operate_history_cmd_data.request.req_car_operate_history.primary_id = _data->primary_id ;
    car_operate_history_cmd_data.request.req_car_operate_history.unique_code = _data->unique_code ;
    car_operate_history_cmd_data.request.req_car_operate_history.base_name = _data->base_name ;
    car_operate_history_cmd_data.request.req_car_operate_history.occur_time = _data->occur_time ;
    car_operate_history_cmd_data.request.req_car_operate_history.alarm_remark = _data->alarm_remark ;
    car_operate_history_cmd_data.request.req_car_operate_history.update_time = _data->update_time ;
    
    car_operate_history_cltService.call(car_operate_history_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    car_operate_history_error_type = (db_tb_error_type)strtoint(car_operate_history_cmd_data.response.error_code,-1) ;
    if(car_operate_history_error_type == edb_tb_err_type_none){        
        _update_primary_id = car_operate_history_cmd_data.response.primary_id ;
        _update_updatetime = car_operate_history_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_car_operate_history_delete_action(std::string unique_code)
{
    car_operate_history_error_type = edb_tb_err_type_none ;

    car_operate_history_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    car_operate_history_cmd_data.request.query_base_index = -1 ;
    car_operate_history_cmd_data.request.query_opt_index = -1;
    car_operate_history_cmd_data.request.query_parameter = unique_code ;
    
    car_operate_history_cltService.call(car_operate_history_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    car_operate_history_error_type = (db_tb_error_type)strtoint(car_operate_history_cmd_data.response.error_code,-1) ;
    if(car_operate_history_error_type != edb_tb_err_type_none){
        car_operate_history_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_car_operate_history_query_action(db_tb_search_type query_base,dynamic_car_operate_history_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    car_operate_history_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_car_operate_history_search_base_name) && 
                (query_opt <= edynamic_car_operate_history_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        car_operate_history_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        car_operate_history_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        car_operate_history_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        car_operate_history_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        car_operate_history_cmd_data.request.query_parameter = search_param ;        
        
        car_operate_history_cltService.call(car_operate_history_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        //------------------
        car_operate_history_error_type = (db_tb_error_type)strtoint(car_operate_history_cmd_data.response.error_code,-1) ;
        bRet = (car_operate_history_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            car_operate_history_results.clear();
            int size = car_operate_history_cmd_data.response.result_car_operate_history.size();
            for(int i=0;i<size;i++){
                ptr_car_operate_history _data = boost::make_shared<type_car_operate_history>();
                _data->primary_id = car_operate_history_cmd_data.response.result_car_operate_history[i].primary_id ;
                _data->unique_code = car_operate_history_cmd_data.response.result_car_operate_history[i].unique_code ;
                _data->base_name = car_operate_history_cmd_data.response.result_car_operate_history[i].base_name ;
                _data->occur_time = car_operate_history_cmd_data.response.result_car_operate_history[i].occur_time ;
                _data->alarm_remark = car_operate_history_cmd_data.response.result_car_operate_history[i].alarm_remark ;
                _data->update_time = car_operate_history_cmd_data.response.result_car_operate_history[i].update_time ;

                car_operate_history_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        car_operate_history_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void car_db_control_module::set_car_operate_history_cltService(ros::ServiceClient &_cltService)
{
    car_operate_history_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : action_function_parameters                                  ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<ptr_action_function_parameters> car_db_control_module::get_action_function_parameters_results()
{
    return action_function_parameters_results ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::get_action_function_parameters_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type car_db_control_module::get_action_function_parameters_error_type() 
{
    return action_function_parameters_error_type ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_action_function_parameters_update_action(db_tb_edit_type _edit_type,const ptr_action_function_parameters &_data)
{   
    action_function_parameters_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        action_function_parameters_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    action_function_parameters_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    action_function_parameters_cmd_data.request.query_base_index = -1 ;
    action_function_parameters_cmd_data.request.query_opt_index = -1;
    action_function_parameters_cmd_data.request.query_parameter = "" ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.primary_id = _data->primary_id ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.unique_code = _data->unique_code ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.base_name = _data->base_name ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.function_level = _data->function_level ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.function_ac_name = _data->function_ac_name ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.function_desc_eng = _data->function_desc_eng ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.function_desc_tc = _data->function_desc_tc ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.function_desc_sc = _data->function_desc_sc ;
    action_function_parameters_cmd_data.request.req_action_function_parameters.update_time = _data->update_time ;
    
    action_function_parameters_cltService.call(action_function_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    action_function_parameters_error_type = (db_tb_error_type)strtoint(action_function_parameters_cmd_data.response.error_code,-1) ;
    if(action_function_parameters_error_type == edb_tb_err_type_none){        
        _update_primary_id = action_function_parameters_cmd_data.response.primary_id ;
        _update_updatetime = action_function_parameters_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_action_function_parameters_delete_action(std::string unique_code)
{
    action_function_parameters_error_type = edb_tb_err_type_none ;

    action_function_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    action_function_parameters_cmd_data.request.query_base_index = -1 ;
    action_function_parameters_cmd_data.request.query_opt_index = -1;
    action_function_parameters_cmd_data.request.query_parameter = unique_code ;
    
    action_function_parameters_cltService.call(action_function_parameters_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    action_function_parameters_error_type = (db_tb_error_type)strtoint(action_function_parameters_cmd_data.response.error_code,-1) ;
    if(action_function_parameters_error_type != edb_tb_err_type_none){
        action_function_parameters_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_action_function_parameters_query_action(db_tb_search_type query_base,dynamic_action_function_parameters_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    action_function_parameters_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_action_function_parameters_search_base_name) && 
                (query_opt <= edynamic_action_function_parameters_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        action_function_parameters_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        action_function_parameters_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        action_function_parameters_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        action_function_parameters_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        action_function_parameters_cmd_data.request.query_parameter = search_param ;        
        
        action_function_parameters_cltService.call(action_function_parameters_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        //------------------
        action_function_parameters_error_type = (db_tb_error_type)strtoint(action_function_parameters_cmd_data.response.error_code,-1) ;
        bRet = (action_function_parameters_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            action_function_parameters_results.clear();
            int size = action_function_parameters_cmd_data.response.result_action_function_parameters.size();
            for(int i=0;i<size;i++){
                ptr_action_function_parameters _data = boost::make_shared<type_action_function_parameters>();
                _data->primary_id = action_function_parameters_cmd_data.response.result_action_function_parameters[i].primary_id ;
                _data->unique_code = action_function_parameters_cmd_data.response.result_action_function_parameters[i].unique_code ;
                _data->base_name = action_function_parameters_cmd_data.response.result_action_function_parameters[i].base_name ;
                _data->function_level = action_function_parameters_cmd_data.response.result_action_function_parameters[i].function_level ;
                _data->function_ac_name = action_function_parameters_cmd_data.response.result_action_function_parameters[i].function_ac_name ;
                _data->function_desc_eng = action_function_parameters_cmd_data.response.result_action_function_parameters[i].function_desc_eng ;
                _data->function_desc_tc = action_function_parameters_cmd_data.response.result_action_function_parameters[i].function_desc_tc ;
                _data->function_desc_sc = action_function_parameters_cmd_data.response.result_action_function_parameters[i].function_desc_sc ;
                _data->update_time = action_function_parameters_cmd_data.response.result_action_function_parameters[i].update_time ;

                action_function_parameters_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        action_function_parameters_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void car_db_control_module::set_action_function_parameters_cltService(ros::ServiceClient &_cltService)
{
    action_function_parameters_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : work_sheet_main                                             ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
void car_db_control_module::set_work_sheet_main_cltService(ros::ServiceClient &_cltService)
{
    work_sheet_main_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_work_sheet_main_update_action(db_tb_edit_type _edit_type,const ptr_work_sheet_main &_data)
{ 
    work_sheet_main_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        work_sheet_main_error_type = edb_tb_err_type_editparam ;
        return ;
    }   

    work_sheet_main_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    work_sheet_main_cmd_data.request.query_base_index = -1 ;
    work_sheet_main_cmd_data.request.query_opt_index = -1;
    work_sheet_main_cmd_data.request.query_parameter = "" ;
    work_sheet_main_cmd_data.request.req_work_sheet_main.primary_id = _data->primary_id ;
    work_sheet_main_cmd_data.request.req_work_sheet_main.unique_code = _data->unique_code ;
    work_sheet_main_cmd_data.request.req_work_sheet_main.base_name = _data->base_name ;
    work_sheet_main_cmd_data.request.req_work_sheet_main.occur_time = _data->occur_time ;
    work_sheet_main_cmd_data.request.req_work_sheet_main.workitems_num = _data->workitems_num ;
    work_sheet_main_cmd_data.request.req_work_sheet_main.update_time = _data->update_time ;
    
    work_sheet_main_cltService.call(work_sheet_main_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    work_sheet_main_error_type = (db_tb_error_type)strtoint(work_sheet_main_cmd_data.response.error_code,-1) ;
    if(work_sheet_main_error_type == edb_tb_err_type_none){        
        _update_primary_id = work_sheet_main_cmd_data.response.primary_id ;
        _update_updatetime = work_sheet_main_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_work_sheet_main_delete_action(std::string unique_code)
{
    work_sheet_main_error_type = edb_tb_err_type_none ;

    work_sheet_main_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    work_sheet_main_cmd_data.request.query_base_index = -1 ;
    work_sheet_main_cmd_data.request.query_opt_index = -1;
    work_sheet_main_cmd_data.request.query_parameter = unique_code ;
    
    work_sheet_main_cltService.call(work_sheet_main_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    work_sheet_main_error_type = (db_tb_error_type)strtoint(work_sheet_main_cmd_data.response.error_code,-1) ;
    if(work_sheet_main_error_type != edb_tb_err_type_none){
        work_sheet_main_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_work_sheet_main_query_action(db_tb_search_type query_base,dynamic_work_sheet_main_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    work_sheet_main_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_work_sheet_main_search_base_name) && 
                (query_opt <= edynamic_work_sheet_main_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        work_sheet_main_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        work_sheet_main_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        work_sheet_main_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        work_sheet_main_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        work_sheet_main_cmd_data.request.query_parameter = search_param ;
        
        work_sheet_main_cltService.call(work_sheet_main_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        //------------------
        work_sheet_main_error_type = (db_tb_error_type)strtoint(work_sheet_main_cmd_data.response.error_code,-1) ;
        bRet = (work_sheet_main_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            work_sheet_main_results.clear();
            int size = work_sheet_main_cmd_data.response.result_work_sheet_main.size();
            for(int i=0;i<size;i++){
                boost::shared_ptr<type_work_sheet_main> _data = boost::make_shared<type_work_sheet_main>();
                _data->primary_id = work_sheet_main_cmd_data.response.result_work_sheet_main[i].primary_id ;
                _data->unique_code = work_sheet_main_cmd_data.response.result_work_sheet_main[i].unique_code ;
                _data->base_name = work_sheet_main_cmd_data.response.result_work_sheet_main[i].base_name ;
                _data->occur_time = work_sheet_main_cmd_data.response.result_work_sheet_main[i].occur_time ;
                _data->workitems_num = work_sheet_main_cmd_data.response.result_work_sheet_main[i].workitems_num ;
                _data->update_time = work_sheet_main_cmd_data.response.result_work_sheet_main[i].update_time ;
                work_sheet_main_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        work_sheet_main_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
vector<ptr_work_sheet_main> car_db_control_module::get_work_sheet_main_results()
{
    return work_sheet_main_results ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::get_work_sheet_main_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type car_db_control_module::get_work_sheet_main_error_type() 
{
    return work_sheet_main_error_type ;
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//**** table : work_sheet_items                                            ****   
//*****************************************************************************  	
//-----------------------------------------------------------------------------
vector<boost::shared_ptr<type_work_sheet_items>> car_db_control_module::get_work_sheet_items_results()
{
    return work_sheet_items_results ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::get_work_sheet_items_req_updated(std::string &primary_id,std::string &updatetime)
{
    primary_id = _update_primary_id ;
    updatetime = _update_updatetime ;
}
//-----------------------------------------------------------------------------
db_tb_error_type car_db_control_module::get_work_sheet_items_error_type() 
{
    return work_sheet_items_error_type ;
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_work_sheet_items_update_action(db_tb_edit_type _edit_type,const ptr_work_sheet_items &_data)
{ 
    work_sheet_items_error_type = edb_tb_err_type_none ;
    std::string _unique_code = _data->unique_code ;
    bool bRet = !_unique_code.empty();
    if(!bRet){
        work_sheet_items_error_type = edb_tb_err_type_editparam ;
        return ;
    }   
    work_sheet_items_cmd_data.request.cmd_id = (int)_edit_type ;  // modify and add
    work_sheet_items_cmd_data.request.query_base_index = -1 ;
    work_sheet_items_cmd_data.request.query_opt_index = -1;
    work_sheet_items_cmd_data.request.query_parameter = "" ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.primary_id = _data->primary_id ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.unique_code = _data->unique_code ;    
    work_sheet_items_cmd_data.request.req_work_sheet_items.base_item_name = _data->base_item_name ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.item_ser_no = _data->item_ser_no ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.occur_time = _data->occur_time ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.target_pose_id = _data->target_pose_id ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.action_function_id = _data->action_function_id ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.action_function_params = _data->action_function_params ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.remark = _data->remark ;
    work_sheet_items_cmd_data.request.req_work_sheet_items.update_time = _data->update_time ;
    
    work_sheet_items_cltService.call(work_sheet_items_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    work_sheet_items_error_type = (db_tb_error_type)strtoint(work_sheet_items_cmd_data.response.error_code,-1) ;
    if(work_sheet_items_error_type == edb_tb_err_type_none){        
        _update_primary_id = work_sheet_items_cmd_data.response.primary_id ;
        _update_updatetime = work_sheet_items_cmd_data.response.update_time ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_work_sheet_items_delete_action(std::string unique_code)
{
    work_sheet_items_error_type = edb_tb_err_type_none ;

    work_sheet_items_cmd_data.request.cmd_id = (int)edb_tb_edit_delete ;
    work_sheet_items_cmd_data.request.query_base_index = -1 ;
    work_sheet_items_cmd_data.request.query_opt_index = -1;
    work_sheet_items_cmd_data.request.query_parameter = unique_code ;
    
    work_sheet_items_cltService.call(work_sheet_items_cmd_data) ; 
    std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    //------------------
    work_sheet_items_error_type = (db_tb_error_type)strtoint(work_sheet_items_cmd_data.response.error_code,-1) ;
    if(work_sheet_items_error_type != edb_tb_err_type_none){
        work_sheet_items_error_type = edb_tb_err_type_delete ;
    }
}
//-----------------------------------------------------------------------------
void car_db_control_module::on_work_sheet_items_query_action(db_tb_search_type query_base,dynamic_work_sheet_items_search_type query_opt,
		                                          std::string search_param)
{
    if(query_base == edb_tb_search_all)
        search_param = "search_all"  ;
    //----------------------      
    work_sheet_items_error_type = edb_tb_err_type_none ;
    bool bRet = !search_param.empty() && (query_base <= edb_tb_search_special) && (query_base >= edb_tb_search_unique_code);
    if(bRet)
        bRet = ((query_base == edb_tb_search_special) && (query_opt >= edynamic_work_sheet_items_search_base_name) && 
                (query_opt <= edynamic_work_sheet_items_search_uptime)) || (query_base != edb_tb_search_special);   

    if(!bRet){
        work_sheet_items_error_type = edb_tb_err_type_searchparam ;
        return  ;
    }
    //-------------------
    try{
        work_sheet_items_cmd_data.request.cmd_id = (int)edb_tb_edit_query ;
        work_sheet_items_cmd_data.request.query_base_index = convert_str((int)query_base) ;
        work_sheet_items_cmd_data.request.query_opt_index = convert_str((int)query_opt) ;
        work_sheet_items_cmd_data.request.query_parameter = search_param ;
        
        work_sheet_items_cltService.call(work_sheet_items_cmd_data) ; 
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        //------------------
        work_sheet_items_error_type = (db_tb_error_type)strtoint(work_sheet_items_cmd_data.response.error_code,-1) ;
        bRet = (work_sheet_items_error_type == edb_tb_err_type_none) ;
        //--- result data ==> get_find_results_vector() --
        if(bRet){
            work_sheet_items_results.clear();
            int size = work_sheet_items_cmd_data.response.result_work_sheet_items.size();
            for(int i=0;i<size;i++){
                ptr_work_sheet_items _data = boost::make_shared<type_work_sheet_items>();
                _data->primary_id = work_sheet_items_cmd_data.response.result_work_sheet_items[i].primary_id ;
                _data->unique_code = work_sheet_items_cmd_data.response.result_work_sheet_items[i].unique_code ;                
                _data->base_item_name = work_sheet_items_cmd_data.response.result_work_sheet_items[i].base_item_name ;
                _data->item_ser_no = work_sheet_items_cmd_data.response.result_work_sheet_items[i].item_ser_no ;
                _data->occur_time = work_sheet_items_cmd_data.response.result_work_sheet_items[i].occur_time ;
                _data->target_pose_id = work_sheet_items_cmd_data.response.result_work_sheet_items[i].target_pose_id ;
                _data->action_function_id = work_sheet_items_cmd_data.response.result_work_sheet_items[i].action_function_id ;
                _data->action_function_params = work_sheet_items_cmd_data.response.result_work_sheet_items[i].action_function_params ;
                _data->remark = work_sheet_items_cmd_data.response.result_work_sheet_items[i].remark ;
                _data->update_time = work_sheet_items_cmd_data.response.result_work_sheet_items[i].update_time ;

                work_sheet_items_results.emplace_back(_data);
            }
        }  
    }
    catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
        work_sheet_items_error_type = edb_tb_err_type_searchparam ;
	}
}
//-----------------------------------------------------------------------------
void car_db_control_module::set_work_sheet_items_cltService(ros::ServiceClient &_cltService)
{
    work_sheet_items_cltService = _cltService ;
}
//-----------------------------------------------------------------------------
