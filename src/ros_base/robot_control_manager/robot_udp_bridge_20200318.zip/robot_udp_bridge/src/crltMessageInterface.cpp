#include <robot_udp_bridge/crltMessageInterface.h>
#include <ros_utility_tools/ros_tools.h>
//-----------------------------------------------------------------------------
//-- interface_datatransfer constructor  -----
crltMessageInterface::crltMessageInterface(ros::NodeHandle &nh): nh_(nh),
                        udpBridge(nh_)
{
    Load_CntParameter();
    //-- subscriber for upper level - subscribe from ROS's publisher  --
    sub_cmd_vel = nh_.subscribe(sub_cmd_vel_name, sub_cmd_vel_queue, 
                                &crltMessageInterface::sub_cmd_vel_CB, this);
    sub_pid = nh_.subscribe(sub_pid_name, sub_pid_queue, 
                                &crltMessageInterface::sub_pid_CB, this);
    //-- publish to ROS from subscribe_Buffer --
    //pub_raw_velocity = nh_.advertise<lino_msgs::Velocities>(pub_raw_velocity_name, pub_raw_velocity_queue);
    pub_raw_velocity = nh_.advertise<robot_control_msgs::Velocities>(pub_raw_velocity_name, pub_raw_velocity_queue);
    pub_raw_megguider = nh_.advertise<samsungcmd_msgs::samsung_cntparamsdata>(pub_raw_megguider_name, pub_raw_megguider_queue);
    pub_raw_magnav = nh_.advertise<samsungcmd_msgs::samsung_cntparamsdata>(pub_raw_magnav_name, pub_raw_magnav_queue);
    pub_raw_reader = nh_.advertise<botcmd_msgs::bot_devicestatus>(pub_raw_reader_name, pub_raw_reader_queue);
    pub_stmudp_heartbeat = nh_.advertise<robot_control_msgs::hyc_heartbeat>(pub_stmudp_heartbeat_name, pub_stmudp_heartbeat_queue);
    pub_raw_sick = nh_.advertise<std_msgs::String>(pub_raw_sick_name, pub_raw_sick_queue);
    //-- serverService for upper level - from ROS's clientService  --
    bot_ledbar_srvService = nh_.advertiseService(bot_ledbar_srvService_name,&crltMessageInterface::srv_Eval_bot_ledbar, this);
    bot_music_srvService = nh_.advertiseService(bot_music_srvService_name,&crltMessageInterface::srv_Eval_bot_music, this);
    bot_download_srvService = nh_.advertiseService(bot_download_srvService_name,&crltMessageInterface::srv_Eval_bot_download, this);
    bot_ultrasonic_srvService = nh_.advertiseService(bot_ultrasonic_srvService_name,&crltMessageInterface::srv_Eval_bot_ultrasonic, this);
    bot_battery_srvService = nh_.advertiseService(bot_battery_srvService_name,&crltMessageInterface::srv_Eval_bot_battery, this);
    //20200317 Add
    bot_battery_info_srvService = nh_.advertiseService(bot_battery_info_srvService_name,&crltMessageInterface::srv_Eval_bot_battery_info, this);
    //-----------------
    bot_reader_status_srvService = nh_.advertiseService(bot_reader_status_srvService_name,&crltMessageInterface::srv_Eval_bot_reader_status, this);
    bot_ssr_srvService = nh_.advertiseService(bot_ssr_srvService_name,&crltMessageInterface::srv_Eval_bot_ssr, this);
    bot_imu_srvService = nh_.advertiseService(bot_imu_srvService_name,&crltMessageInterface::srv_Eval_bot_imu, this);
    bot_SetFunction_srvService = nh_.advertiseService(bot_SetFunction_srvService_name,&crltMessageInterface::srv_Eval_bot_SetFunction, this);
    bot_io_srvService = nh_.advertiseService(bot_io_srvService_name,&crltMessageInterface::srv_Eval_bot_io, this);
    bot_laserarea_srvService = nh_.advertiseService(bot_laserarea_srvService_name,&crltMessageInterface::srv_Eval_bot_laserarea, this);

    bot_motor1_srvService = nh_.advertiseService(bot_motor1_srvService_name,&crltMessageInterface::srv_Eval_bot_motor1, this);
    bot_motor2_srvService = nh_.advertiseService(bot_motor2_srvService_name,&crltMessageInterface::srv_Eval_bot_motor2, this);
    bot_motor3_srvService = nh_.advertiseService(bot_motor3_srvService_name,&crltMessageInterface::srv_Eval_bot_motor3, this);
    bot_motor4_srvService = nh_.advertiseService(bot_motor4_srvService_name,&crltMessageInterface::srv_Eval_bot_motor4, this);
    //-- clientService for upper level - from ROS's sererService  --
    bot_Upload_srvService = nh_.advertiseService(bot_Upload_cltService_name,&crltMessageInterface::srv_Eval_bot_Upload, this);
    bot_Upload_cltService = nh_.serviceClient<botcmd_msgs::bot_transfer_cmd>(bot_Upload_cltService_name);

    //bot_sysstatus_srvService = nh_.advertiseService(bot_sysstatus_cltService_name,&crltMessageInterface::srv_Eval_bot_sysstatus, this);
    //bot_sysstatus_cltService = nh_.serviceClient<botcmd_msgs::bot_do_cmd>(bot_sysstatus_cltService_name);
    //--- declare thread ---------
    //--- fire-up thread of ros's subscribe topic (send-messages form Pub_Queue of stm-control_board ) ---
    sub_received_threads = std::unique_ptr<thd::thread>( new thd::thread( thd::bind(&crltMessageInterface::sub_received_threadEntry, this)));
    //--- fire-up thread of ros's client service (send-messages form serverService_Queue of stm-control_board ) ---
	cltservice_recv_thread = std::unique_ptr<thd::thread>( new thd::thread( thd::bind(&crltMessageInterface::cltservice_recv_threadEntry, this)));
    //-- multi-thread for waiting reqests of stm's clientservice (ros' server service) (source come from stm-clientService_Queue)  --
    srvservice_recv_threads = std::unique_ptr<thd::thread>( new thd::thread( thd::bind(&crltMessageInterface::srvservice_recv_threadEntry, this,bot_Upload_cltService_name)));
    //--- control parameters for crltMessageInterface --
    crltMessage_destory = false;
    crltMessage_start = false;
    //--- control parameters for ros's client-service --
    b_ledbar_set = false ; b_ledbar_finish = false ;
    b_music_set = false ; b_music_finish = false ;
	b_download_set = false ; b_download_finish = false ;
	b_ultrasonic_set = false ; b_ultrasonic_finish = false ;
	b_battery_set = false ;b_battery_finish = false ;
    b_battery_info_set = false ;b_battery_info_finish = false ;
	b_reader_set = false ; b_reader_finish = false ;
	b_ssr_set = false ; b_ssr_finish = false ;
	b_imu_set = false ; b_imu_finish = false ;
	b_SetFunction_set, b_SetFunction_finish = false ;
    b_io_set = false ; b_io_finish = false ;
	b_laserarea_set = false ; b_laserarea_finish = false ;
	b_motor1_set = false ; b_motor1_finish = false ;
	b_motor2_set = false ; b_motor2_finish = false ;
	b_motor3_set = false ; b_motor3_finish = false ;
	b_motor4_set = false ; b_motor4_finish = false ;

    b_Upload_finish = false ;
    bManual_test = false ;
	//b_sysstatus_finish = false ;

    raw_heartbeat_msg.hb_stamp = 0 ;
    pre_heartbeat_id = 0 ;

    //ROS_INFO("crltMessageInterface");
}
//-----------------------------------------------------------------------------
//-- interface_datatransfer de-constructor ---------------
crltMessageInterface::~crltMessageInterface()
{
    //ROS_INFO("~crltMessageInterface");
    thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
	if (cltservice_recv_thread->joinable())
	{
        thd::lock_guard<thd::mutex> lock(cltservice_recv_mtx);
        crltMessage_destory = true;
        sub_received_cv.notify_one();
        cltservice_recv_cv.notify_one();
        cltservice_send_cv.notify_one();
        srvservice_recv_cv.notify_one();
    }
    cltservice_recv_thread->join(); 
    srvservice_recv_threadClose();
    sub_received_threadClose();
}
//-----------------------------------------------------------------------------
//-- server service and check finished signal from stm  --
void crltMessageInterface::crltMessage_start_set(bool bSet) 
{
    crltMessage_start = bSet ;
    //-- notify_one to 
    sub_received_cv.notify_one();
    cltservice_recv_cv.notify_one();
    cltservice_send_cv.notify_one();
    srvservice_recv_cv.notify_one();
}
//-----------------------------------------------------------------------------
//--- enter thread of ros's subscribe topic (sended messages of stm-control_board ) ---
void crltMessageInterface::sub_received_threadEntry()
{
    //ROS_INFO("sub_received_threadEntry");
    thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    while(true){
		{            
			thd::unique_lock<thd::mutex> lock(sub_received_mtx);
			sub_received_cv.wait( lock, [&] () { return (crltMessage_destory || crltMessage_start); } ); 
			if(crltMessage_destory){
				break;
            }
			else{	  
                if(udpBridge.get_Buffer_Size(eVector_sub)>0){
                    sub_received_call();
                }
			}
		}	
		//-------------------
		thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
	}
}
//-----------------------------------------------------------------------------
void crltMessageInterface::sub_received_threadClose()
{
    //ROS_INFO("sub_received_threadClose");
    thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    if (sub_received_threads->joinable()){
        thd::lock_guard<thd::mutex> lock(sub_received_mtx);
        crltMessage_destory = true;
        sub_received_cv.notify_one();
    }
    sub_received_threads->join();   
}
//-----------------------------------------------------------------------------
void crltMessageInterface::sub_received_call()
{
    //---------------
    json jsonObject ;
    SRV_PROC_Step _Step ;
    //ROS_INFO("crltMessageInterface");
    //-- publish first item of  publish_Buffer
    bool bRet = udpBridge.get_jsonObject_Buffer(0,eVector_sub,jsonObject,_Step) ;
    if(!bRet)   return ;
    //ROS_INFO(jsonObject["main_type"].c_str());
    std::string _topic_name = jsonObject["topic_name"] ;
    if(bDebug_Show){
        std::string tmp = _topic_name + " counter_thread:" + convert_str(udpBridge.get_Buffer_Size(eVector_sub)) ;
        ROS_INFO(tmp.c_str());
    }
    //---------------
    //ROS_INFO(jsonObject.dump().c_str()); 
    thd::this_thread::sleep_for(std::chrono::milliseconds(1));
    if(jsonObject["main_type"] == "topic"){
        if(jsonObject["topic_name"] == pub_raw_velocity_name){//"raw_vel_msg"){   
            /*if(bDebug_Show){           
                std::string tmp = convert_str(jsonObject["linear_x"]) ;
                ROS_INFO(tmp.c_str());
            }*/
            pub_raw_vel_topic(jsonObject) ; 
            udpBridge.erase_jsonObject_Buffer(0,eVector_sub);
            if(bDebug_Show){
                std::string tmp = _topic_name + "counter_delete:" + convert_str(udpBridge.get_Buffer_Size(eVector_sub)) ;
                ROS_INFO(tmp.c_str());
            }
        }
        else if(jsonObject["topic_name"] == pub_raw_megguider_name){//"raw_megguider_msg"){  
            pub_raw_megguider_topic(jsonObject) ; 
            udpBridge.erase_jsonObject_Buffer(0,eVector_sub);
            if(bDebug_Show){
                std::string tmp = _topic_name + "counter_delete:" + convert_str(udpBridge.get_Buffer_Size(eVector_sub)) ;
                ROS_INFO(tmp.c_str());
            }
        }
        else if(jsonObject["topic_name"] == pub_raw_magnav_name){//"raw_magnav_msg"){  
            pub_raw_magnav_topic(jsonObject) ; 
            udpBridge.erase_jsonObject_Buffer(0,eVector_sub);
            if(bDebug_Show){
                std::string tmp = _topic_name + "counter_delete:" + convert_str(udpBridge.get_Buffer_Size(eVector_sub)) ;
                ROS_INFO(tmp.c_str());
            }
        }
        else if(jsonObject["topic_name"] == pub_raw_reader_name){//"raw_reader_msg"){  
            pub_raw_reader_topic(jsonObject) ; 
            udpBridge.erase_jsonObject_Buffer(0,eVector_sub);
            if(bDebug_Show){
                std::string tmp = _topic_name + "counter_delete:" + convert_str(udpBridge.get_Buffer_Size(eVector_sub)) ;
                ROS_INFO(tmp.c_str());
            }
        }
        else if(jsonObject["topic_name"] == pub_stmudp_heartbeat_name){//"raw_heartbeat_msg"){ 
            pub_stmudp_heartbeat_topic(jsonObject) ; 
            udpBridge.erase_jsonObject_Buffer(0,eVector_sub);
            if(bDebug_Show){
                std::string tmp = _topic_name + "counter_delete:" + convert_str(udpBridge.get_Buffer_Size(eVector_sub)) ;
                ROS_INFO(tmp.c_str());
            }
        }
        else if(jsonObject["topic_name"] == pub_raw_sick_name){//"pub_raw_sick_msg"){  
            pub_raw_sick_topic(jsonObject) ; 
            udpBridge.erase_jsonObject_Buffer(0,eVector_sub);
            if(bDebug_Show){
                std::string tmp = _topic_name + "counter_delete:" + convert_str(udpBridge.get_Buffer_Size(eVector_sub)) ;
                ROS_INFO(tmp.c_str());
            }
        }
    } 
    sub_received_cv.notify_one();     
}
//-----------------------------------------------------------------------------
//--- fire-up thread of ros's client service (send-messages form serverService_Queue of stm-control_board ) ---
void crltMessageInterface::cltservice_recv_threadEntry() 
{
    //ROS_INFO("cltservice_recv_threadEntry");
    thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    while(true){
		{
			thd::unique_lock<thd::mutex> lock(cltservice_recv_mtx);
			cltservice_recv_cv.wait( lock, [&] () { return (crltMessage_destory || crltMessage_start); } ); //|| (udpBridge.get_Buffer_Size(eVector_cltService)>0)

			if(crltMessage_destory)
				break;
			else{	
				//-- run Action ----
                if(udpBridge.get_Buffer_Size(eVector_cltService)>0)
				    cltservice_recv_Check();
			}
		}	
		//-------------------
		thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
	}
}
//-----------------------------------------------------------------------------
bool crltMessageInterface::cltservice_recv_Check()
{
	SRV_PROC_Step _Step ;
    bool bRet = true ;
    if(b_ledbar_set && !b_ledbar_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_ledbar_srvService_name,_Step,eVector_cltService) ;
        b_ledbar_finish = bRet && (_Step == eSRV_PROC_Recv) ;
        if(!b_ledbar_finish){
            b_call_led_timeout = call_service_timeout_check(bot_ledbar_srvService_name);//("led");    
        }
    }
    if(b_music_set && !b_music_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_music_srvService_name,_Step,eVector_cltService) ;
        b_music_finish = bRet && (_Step == eSRV_PROC_Recv) ;
        if(!b_music_finish){
            b_call_music_timeout = call_service_timeout_check(bot_music_srvService_name);//"music");    
        }
    }
    if(b_download_set && !b_download_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_download_srvService_name,_Step,eVector_cltService) ;
        b_download_finish = bRet && (_Step == eSRV_PROC_Recv) ;
        if(!b_download_finish){
            b_call_download_timeout = call_service_timeout_check(bot_download_srvService_name); //"download");    
        }
    }
    if(b_ultrasonic_set && !b_ultrasonic_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_ultrasonic_srvService_name,_Step,eVector_cltService) ;
        b_ultrasonic_finish = bRet && (_Step == eSRV_PROC_Recv) ; 
        if(!b_ultrasonic_finish){
            b_call_ultrasonic_timeout = call_service_timeout_check(bot_ultrasonic_srvService_name) ;//"ultrasonic");    
        }
    }
    if(b_battery_set && !b_battery_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_battery_srvService_name,_Step,eVector_cltService) ;
        b_battery_finish = bRet && (_Step == eSRV_PROC_Recv) ;
        if(!b_battery_finish){
            b_call_battery_timeout = call_service_timeout_check(bot_battery_srvService_name) ;//"battery");    
        }
    }
    //--20200317 Add ----
    if(b_battery_info_set && !b_battery_info_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_battery_info_srvService_name,_Step,eVector_cltService) ;
        b_battery_info_finish = bRet && (_Step == eSRV_PROC_Recv) ;
        if(!b_battery_info_finish){
            b_call_battery_info_timeout = call_service_timeout_check(bot_battery_info_srvService_name) ;//"battery_info");    
        }
    }
    //---------------
    if(b_reader_set && !b_reader_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_reader_status_srvService_name,_Step,eVector_cltService) ;
        b_reader_finish = bRet && (_Step == eSRV_PROC_Recv) ;
        if(!b_reader_finish){
            b_call_reader_timeout = call_service_timeout_check(bot_reader_status_srvService_name); //"reader");    
        }
    }
    if(b_ssr_set && !b_ssr_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_ssr_srvService_name,_Step,eVector_cltService) ;
        b_ssr_finish = bRet && (_Step == eSRV_PROC_Recv) ;
        if(!b_ssr_finish){
            b_call_ssr_timeout = call_service_timeout_check(bot_ssr_srvService_name) ;//"ssr");    
        }
    }
    if(b_imu_set && !b_imu_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_imu_srvService_name,_Step,eVector_cltService) ;
        b_imu_finish = bRet && (_Step == eSRV_PROC_Recv) ;
        if(!b_imu_finish){
            b_call_imu_timeout = call_service_timeout_check(bot_imu_srvService_name) ;//"imu");    
        }
    }
    if(b_SetFunction_set && !b_SetFunction_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_SetFunction_srvService_name,_Step,eVector_cltService) ;
        b_SetFunction_finish = bRet && (_Step == eSRV_PROC_Recv) ; 
        if(!b_SetFunction_finish){
            b_call_SetFunction_timeout = call_service_timeout_check(bot_SetFunction_srvService_name); //"SetFunction");    
        }
    }
    if(b_io_set && !b_io_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_io_srvService_name,_Step,eVector_cltService) ;
        b_io_finish = bRet && (_Step == eSRV_PROC_Recv) ;
        if(!b_io_finish){
            b_call_io_timeout = call_service_timeout_check(bot_io_srvService_name) ;//"io");    
        }
    }
    if(b_laserarea_set && !b_laserarea_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_laserarea_srvService_name,_Step,eVector_cltService) ;
        b_laserarea_finish = bRet && (_Step == eSRV_PROC_Recv) ;
        if(!b_laserarea_finish){
            b_call_laserarea_timeout = call_service_timeout_check(bot_laserarea_srvService_name) ;//"laserarea");    
        }
    }
    if(b_motor1_set && !b_motor1_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_motor1_srvService_name,_Step,eVector_cltService) ;
        b_motor1_finish = bRet && (_Step == eSRV_PROC_Recv) ;
        if(!b_motor1_finish){
            b_call_motor1_timeout = call_service_timeout_check(bot_motor1_srvService_name) ;//"motor1");    
        }
    }
    if(b_motor2_set && !b_motor2_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_motor2_srvService_name,_Step,eVector_cltService) ;
        b_motor2_finish = bRet && (_Step == eSRV_PROC_Recv) ;
        if(!b_motor2_finish){
            b_call_motor2_timeout = call_service_timeout_check(bot_motor2_srvService_name);//"motor2");    
        }
    }
    if(b_motor3_set && !b_motor3_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_motor3_srvService_name,_Step,eVector_cltService) ;
        b_motor3_finish = bRet && (_Step == eSRV_PROC_Recv) ;
        if(!b_motor3_finish){
            b_call_motor3_timeout = call_service_timeout_check(bot_motor3_srvService_name);//"motor3");    
        }
    }
    if(b_motor4_set && !b_motor4_finish){
        bRet = udpBridge.get_SRV_PROC_Step(bot_motor4_srvService_name,_Step,eVector_cltService) ;
        b_motor4_finish = bRet && (_Step == eSRV_PROC_Recv) ;
        if(!b_motor4_finish){
            b_call_motor4_timeout = call_service_timeout_check(bot_motor4_srvService_name);//"motor4");    
        }
    }
    //-----------------------
    if(bRet && (_Step == eSRV_PROC_Recv))
        cltservice_send_cv.notify_one();
    //-----------------------    
    return bRet ; 
}
//-----------------------------------------------------------------------------
bool crltMessageInterface::set_cltservice_send_proc(std::string srvService_name,json &jsonObj)
{
    ////ROS_INFO("set_cltservice_send_proc");
    bool bRet = true ;
    //-- wait for data (received result from stm) -----
    //ROS_INFO("set_cltservice_send_proc Wait for response ...");
    thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    thd::unique_lock<thd::mutex> lock(cltservice_send_mtx);
    if(srvService_name == bot_ledbar_srvService_name){
        b_ledbar_set = true ; b_ledbar_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_ledbar_finish || b_call_led_timeout; } );   
    }
    else if(srvService_name == bot_music_srvService_name){
        b_music_set = true ; b_music_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_music_finish || b_call_music_timeout; } );   
    }
    else if(srvService_name == bot_download_srvService_name){
        b_download_set = true ; b_download_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_download_finish || b_call_download_timeout; } );   
    }
    else if(srvService_name == bot_ultrasonic_srvService_name){
        b_ultrasonic_set = true ; b_ultrasonic_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_ultrasonic_finish || b_call_ultrasonic_timeout; } );   
    }
    else if(srvService_name == bot_battery_srvService_name){
        b_battery_set = true ; b_battery_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_battery_finish || b_call_battery_timeout; } );   
    }
    //----20200317 Add 
    else if(srvService_name == bot_battery_info_srvService_name){
        b_battery_info_set = true ; b_battery_info_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_battery_info_finish || b_call_battery_info_timeout; } );   
    }
    //-----------------
    else if(srvService_name == bot_reader_status_srvService_name){
        b_reader_set = true ; b_reader_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_reader_finish || b_call_reader_timeout; } );   
    }
    else if(srvService_name == bot_ssr_srvService_name){
        b_ssr_set = true ; b_ssr_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_ssr_finish || b_call_ssr_timeout; } );   
    }
    else if(srvService_name == bot_imu_srvService_name){
        b_imu_set = true ; b_imu_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_imu_finish || b_call_imu_timeout; } );   
    }
    else if(srvService_name == bot_SetFunction_srvService_name){
        b_SetFunction_set = true ; b_SetFunction_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_SetFunction_finish || b_call_SetFunction_timeout; } );   
    }
    else if(srvService_name == bot_io_srvService_name){
        b_io_set = true ; b_io_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_io_finish || b_call_io_timeout; } );   
    }
    else if(srvService_name == bot_laserarea_srvService_name){
        b_laserarea_set = true ; b_laserarea_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_laserarea_finish || b_call_laserarea_timeout; } );   
    }
    else if(srvService_name == bot_motor1_srvService_name){
        b_motor1_set = true ; b_motor1_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_motor1_finish || b_call_motor1_timeout; } );   
    }
    else if(srvService_name == bot_motor2_srvService_name){
        b_motor2_set = true ; b_motor2_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_motor2_finish || b_call_motor2_timeout; } );   
    }
    else if(srvService_name == bot_motor3_srvService_name){
        b_motor3_set = true ; b_motor3_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_motor3_finish || b_call_motor3_timeout; } );   
    }
    else if(srvService_name == bot_motor4_srvService_name){
        b_motor4_set = true ; b_motor4_finish = false ; 
        cltservice_send_cv.wait( lock, [&] () { return crltMessage_destory || b_motor4_finish || b_call_motor4_timeout; } );   
    }
    else bRet = false ;       
    //----control status reset ------------
    //ROS_INFO("...set_cltservice_send_proc Wait finshed");
    thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    if(srvService_name == bot_ledbar_srvService_name){
        b_ledbar_set = false ; b_ledbar_finish = false ;  b_call_led_timeout =  false ;
    }
    else if(srvService_name == bot_music_srvService_name){
        b_music_set = false ; b_music_finish = false ;  b_call_music_timeout =  false ;
    }
    else if(srvService_name == bot_download_srvService_name){
        b_download_set = false ; b_download_finish = false ; b_call_download_timeout =  false ;
    }
    else if(srvService_name == bot_ultrasonic_srvService_name){
        b_ultrasonic_set = false ; b_ultrasonic_finish = false ; b_call_ultrasonic_timeout =  false ;
    }
    else if(srvService_name == bot_battery_srvService_name){
        b_battery_set = false ; b_battery_finish = false ; b_call_battery_timeout =  false ;
    }
    //--- 20200317 Add ---
    else if(srvService_name == bot_battery_info_srvService_name){
        b_battery_info_set = false ; b_battery_info_finish = false ; b_call_battery_info_timeout =  false ;
    }
    //-------------
    else if(srvService_name == bot_reader_status_srvService_name){
        b_reader_set = false ; b_reader_finish = false ; b_call_reader_timeout =  false ;
    }
    else if(srvService_name == bot_ssr_srvService_name){
        b_ssr_set = false ; b_ssr_finish = false ; b_call_ssr_timeout =  false ;
    }
    else if(srvService_name == bot_imu_srvService_name){
        b_imu_set = false ; b_imu_finish = false ; b_call_imu_timeout =  false ;  
    }
    else if(srvService_name == bot_SetFunction_srvService_name){
        b_SetFunction_set = false ; b_SetFunction_finish = false ; b_call_SetFunction_timeout =  false ;
    }
    else if(srvService_name == bot_io_srvService_name){
        b_io_set = false ; b_io_finish = false ; b_call_io_timeout =  false ;
    }
    else if(srvService_name == bot_laserarea_srvService_name){
        b_laserarea_set = false ; b_laserarea_finish = false ; b_call_laserarea_timeout =  false ;  
    }
    else if(srvService_name == bot_motor1_srvService_name){
        b_motor1_set = false ; b_motor1_finish = false ; b_call_motor1_timeout =  false ;
    }
    else if(srvService_name == bot_motor2_srvService_name){
        b_motor2_set = false ; b_motor2_finish = false ; b_call_motor2_timeout =  false ;
    }
    else if(srvService_name == bot_motor3_srvService_name){
        b_motor3_set = false ; b_motor3_finish = false ; b_call_motor3_timeout =  false ;
    }
    else if(srvService_name == bot_motor4_srvService_name){
        b_motor4_set = false ; b_motor4_finish = false ; b_call_motor4_timeout =  false ;
    }
    //--------------------------------------
    
    if(bRet){
        SRV_PROC_Step _Step;
        bRet = udpBridge.get_jsonObject_Buffer(srvService_name,eVector_cltService,jsonObj,_Step) ;
        if(bRet)
            cltservice_recv_cv.notify_one();
    }
    //-----------------------------------
    return bRet ;
}
//-----------------------------------------------------------------------------
//-- client service active check (source come from stm)  --
void crltMessageInterface::srvservice_recv_threadEntry(std::string cltService_name)
{
    //ROS_INFO("srvservice_recv_threadEntry");
    thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    while(true){
		{           
			thd::unique_lock<thd::mutex> lock(srvservice_recv_mtx);
			srvservice_recv_cv.wait( lock, [&] () { return (crltMessage_destory || crltMessage_start); } );    //|| (bRet && (_Step == eSRV_PROC_Register))

			if(crltMessage_destory)
				break;
			else{	
                if(udpBridge.get_Buffer_Size(eVector_srvService)>0){         
                    SRV_PROC_Step _Step ;
                    bool bRet = udpBridge.get_SRV_PROC_Step(cltService_name,_Step,eVector_srvService) ;
                    if(bRet && (_Step == eSRV_PROC_Register)){
                        srvservice_recv_call(cltService_name);
                    }    
                }
			}
		}	
		//-------------------
		thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
	}
}
//-----------------------------------------------------------------------------
void crltMessageInterface::srvservice_recv_threadClose()
{
    //ROS_INFO("srvservice_recv_threadClose");
    thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    if (srvservice_recv_threads->joinable()){    
        thd::lock_guard<thd::mutex> lock(srvservice_recv_mtx);
        crltMessage_destory = true;
        srvservice_recv_cv.notify_one();
    }
    srvservice_recv_threads->join();   
}
//-----------------------------------------------------------------------------
//-- callback for srv_Eval_bot_Upload from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_Upload(botcmd_msgs::bot_transfer_cmd::Request  &req,
								               botcmd_msgs::bot_transfer_cmd::Response &resp)
{    
    thd::this_thread::sleep_for(std::chrono::milliseconds(1));
    //---- Manual test -----------
    if(bManual_test){
        Upload_test_counter = req.index_ID + 10 ;
        if(Upload_test_counter > 100)
            Upload_test_counter = 0;    
        resp.result = true ;
        resp.result_Data = req.parameter + " resp. params:" + convert_str(Upload_test_counter) +
                        " result:" + convert_str((int)resp.result);
        resp.result_ID = Upload_test_counter ;
    }
    //---- real response -----------
    else{

    }

    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for srv_Eval_bot_Upload from ros's clientservice
/*bool crltMessageInterface::srv_Eval_bot_sysstatus(botcmd_msgs::bot_do_cmd::Request  &req,
								                  botcmd_msgs::bot_do_cmd::Response &resp)
{
    
    return true ;
}*/
//-----------------------------------------------------------------------------
//-- send request to ros's serverservice and wait its result --
void crltMessageInterface::srvservice_recv_call(std::string cltService_name)
{
    //ROS_INFO("==== srvservice_recv_call -- eVector_srvService =====") ;
    SRV_PROC_Step _Step;
    //json jsonObj ;
    bool bRet = udpBridge.get_jsonObject_Buffer(cltService_name,eVector_srvService,json_srv_recv_call,_Step) ;   
    if(!bRet) return ;   
    //---------------------------
    if(cltService_name == bot_Upload_cltService_name){
        bot_Upload_cmd_data.request.index_ID = json_srv_recv_call["index_ID"];
        bot_Upload_cmd_data.request.parameter = json_srv_recv_call["parameter"];
        bot_Upload_cmd_data.response.result = json_srv_recv_call["result"];
        bot_Upload_cmd_data.response.result_Data = json_srv_recv_call["result_Data"];
        bot_Upload_cmd_data.response.result_ID = json_srv_recv_call["result_ID"];

        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        bRet = bot_Upload_cltService.call(bot_Upload_cmd_data) ; 
        
        //json jsonObj1 ;
        json_srv_recv_call["main_type"] = "carcnt_service";
        json_srv_recv_call["service_name"] = bot_Upload_cltService_name ; 
        json_srv_recv_call["index_ID"] = bot_Upload_cmd_data.request.index_ID ;
        json_srv_recv_call["parameter"] = bot_Upload_cmd_data.request.parameter ;
        json_srv_recv_call["result"] = bot_Upload_cmd_data.response.result ;
        json_srv_recv_call["result_Data"] = bot_Upload_cmd_data.response.result_Data ;
        json_srv_recv_call["result_ID"] = bot_Upload_cmd_data.response.result_ID ;
        
        //ROS_INFO("==== modify_jsonObject_Buffer to eSRV_PROC_Recv -- eVector_srvService =====") ;		
        udpBridge.modify_jsonObject_Buffer(cltService_name,eVector_srvService,json_srv_recv_call,eSRV_PROC_Recv) ; 
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); //-- 2019.12.26 add importance
    }
    //else if(cltService_name == bot_sysstatus_cltService_name){ 
    //}
}

//-----------------------------------------------------------------------------
//-- load control parameters from parameter.yaml  ---------------
void crltMessageInterface::Load_CntParameter()
{
    ros::NodeHandle pnh("~");

    if(!pnh.getParam("bDebug_Show", bDebug_Show))
        bDebug_Show = false ;

    if(!pnh.getParam("sub_cmd_vel_name", sub_cmd_vel_name))
        sub_cmd_vel_name = "cmd_vel";
    if(!pnh.getParam("sub_cmd_vel_queue", sub_cmd_vel_queue))
        sub_cmd_vel_queue = 10 ;

    if(!pnh.getParam("sub_pid_name", sub_pid_name))
        sub_pid_name = "cmd_pid";
    if(!pnh.getParam("sub_pid_queue", sub_pid_queue))
        sub_pid_queue = 10 ;

    if(!pnh.getParam("pub_raw_velocity_name", pub_raw_velocity_name))
        pub_raw_velocity_name = "raw_vel_msg";
    if(!pnh.getParam("pub_raw_velocity_queue", pub_raw_velocity_queue))
        pub_raw_velocity_queue = 10 ;

    if(!pnh.getParam("pub_raw_megguider_name", pub_raw_megguider_name))
        pub_raw_megguider_name = "raw_megguider_msg";
    if(!pnh.getParam("pub_raw_megguider_queue", pub_raw_megguider_queue))
        pub_raw_megguider_queue = 10 ;

    if(!pnh.getParam("pub_raw_magnav_name", pub_raw_magnav_name))
        pub_raw_magnav_name = "raw_magnav_msg";
    if(!pnh.getParam("pub_raw_magnav_queue", pub_raw_magnav_queue))
        pub_raw_magnav_queue = 10 ;

    if(!pnh.getParam("pub_raw_reader_name", pub_raw_reader_name))
        pub_raw_reader_name = "raw_reader_msg";
    if(!pnh.getParam("pub_raw_reader_queue", pub_raw_reader_queue))
        pub_raw_reader_queue = 10 ;

    if(!pnh.getParam("pub_stmudp_heartbeat_name", pub_stmudp_heartbeat_name))
        pub_stmudp_heartbeat_name = "raw_heartbeat_msg";
    if(!pnh.getParam("pub_stmudp_heartbeat_queue", pub_stmudp_heartbeat_queue))
        pub_stmudp_heartbeat_queue = 10 ;

    if(!pnh.getParam("pub_raw_sick_name", pub_raw_sick_name))
        pub_raw_sick_name = "raw_sick_msg";
    if(!pnh.getParam("pub_raw_sick_queue", pub_raw_sick_queue))
        pub_raw_sick_queue = 10 ;


    if(!pnh.getParam("bot_ledbar_srvService_name", bot_ledbar_srvService_name))
        bot_ledbar_srvService_name = "bot_ledbar_cmdsrv";

    if(!pnh.getParam("bot_music_srvService_name", bot_music_srvService_name))
        bot_music_srvService_name = "bot_music_cmdsrv";

    if(!pnh.getParam("bot_download_srvService_name", bot_download_srvService_name))
        bot_download_srvService_name = "bot_download_cmdsrv";

    if(!pnh.getParam("bot_ultrasonic_srvService_name", bot_ultrasonic_srvService_name))
        bot_ultrasonic_srvService_name = "bot_ultrasonic_cmdsrv";

    if(!pnh.getParam("bot_battery_srvService_name", bot_battery_srvService_name))
        bot_battery_srvService_name = "bot_battery_cmdsrv";  
    //-- 20200317 Add ---
    if(!pnh.getParam("bot_battery_info_srvService_name", bot_battery_info_srvService_name))
        bot_battery_info_srvService_name = "bot_battery_info_cmdsrv";       
    //--------------------
    if(!pnh.getParam("bot_reader_status_srvService_name", bot_reader_status_srvService_name))
        bot_reader_status_srvService_name = "bot_reader_status_cmdsrv";   

    if(!pnh.getParam("bot_ssr_srvService_name", bot_ssr_srvService_name))
        bot_ssr_srvService_name = "bot_ssr_cmdsrv";   

    if(!pnh.getParam("bot_imu_srvService_name", bot_imu_srvService_name))
        bot_imu_srvService_name = "bot_imu_cmdsrv";   

    if(!pnh.getParam("bot_SetFunction_srvService_name", bot_SetFunction_srvService_name))
        bot_SetFunction_srvService_name = "bot_SetFunction_cmdsrv";   

    if(!pnh.getParam("bot_io_srvService_name", bot_io_srvService_name))
        bot_io_srvService_name = "bot_io_cmdsrv";   

    if(!pnh.getParam("bot_laserarea_srvService_name", bot_laserarea_srvService_name))
        bot_laserarea_srvService_name = "bot_laserarea_cmdsrv";  

    if(!pnh.getParam("bot_motor1_srvService_name", bot_motor1_srvService_name))
        bot_motor1_srvService_name = "bot_motor1_status_cmdsrv";   

    if(!pnh.getParam("bot_motor2_srvService_name", bot_motor2_srvService_name))
        bot_motor2_srvService_name = "bot_motor2_status_cmdsrv";   

    if(!pnh.getParam("bot_motor3_srvService_name", bot_motor3_srvService_name))
        bot_motor3_srvService_name = "bot_motor3_status_cmdsrv";   

    if(!pnh.getParam("bot_motor4_srvService_name", bot_motor4_srvService_name))
        bot_motor4_srvService_name = "bot_motor4_status_cmdsrv";   
    //--------------------
    if(!pnh.getParam("bot_Upload_cltService_name", bot_Upload_cltService_name))
        bot_Upload_cltService_name = "bot_upload_sendsrv" ;//"bot_Upload_cmd_clt";   

    //if(!pnh.getParam("bot_sysstatus_cltService_name", bot_sysstatus_cltService_name))
    //    bot_sysstatus_cltService_name = "bot_sysstatus_sendsrv" ;//"bot_sysstatus_cmd_clt";    
    //-------------------   
    if(!pnh.getParam("call_service_timeout", call_service_timeout))
        call_service_timeout = 2.0;     // unit: sec        
}

//-----------------------------------------------------------------------------
//-- callback function for subscribe - sub_cmd_vel -------- 
void crltMessageInterface::sub_cmd_vel_CB(const geometry_msgs::Twist& cmd_msg)
{
    if(!stm_heartbeat_check())
        return ;
    //-------------
    //ROS_INFO("pubROS_cmd_vel_topic ==> sub_cmd_vel_CB");
    json jsonObj;
    jsonObj["main_type"] = "topic";
    jsonObj["topic_name"] = sub_cmd_vel_name;//"cmd_vel_msg";
    jsonObj["linear_x"] = cmd_msg.linear.x;
    jsonObj["linear_y"] = cmd_msg.linear.y;
    jsonObj["linear_z"] = cmd_msg.linear.z;
    jsonObj["angular_x"] = cmd_msg.angular.x;
    jsonObj["angular_y"] = cmd_msg.angular.y;
    jsonObj["angular_z"] = cmd_msg.angular.z;
    
    //-- Send command data to publish-vector
    udpBridge.add_jsonObject_Buffer(jsonObj,eVector_pub);

    thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
}
//-----------------------------------------------------------------------------
//-- callback function for subscribe - sub_pid -------- 
void crltMessageInterface::sub_pid_CB(const robot_control_msgs::PID& pid_msg)
{ 
    if(!stm_heartbeat_check())
        return ;
    //-------------
    //ROS_INFO("pubROS_cmd_pid_topic ==> sub_pid_CB");
    json jsonObj;
    jsonObj["main_type"] = "topic";
    jsonObj["topic_name"] = sub_pid_name ;//"cmd_pid_msg";
    jsonObj["_p"] = pid_msg.p;
    jsonObj["_i"] = pid_msg.i;
    jsonObj["_d"] = pid_msg.d;

    //-- Send command data to publish-vector
    udpBridge.add_jsonObject_Buffer(jsonObj,eVector_pub);

    thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
    
}
//-----------------------------------------------------------------------------
//-- publish topic - pub_raw_velocity -------- 
void crltMessageInterface::pub_raw_vel_topic(json jsonObj)
{
    raw_velocity_msg.linear_x = jsonObj["linear_x"] ;
    raw_velocity_msg.linear_y = jsonObj["linear_y"] ;
    raw_velocity_msg.angular_z = jsonObj["angular_z"] ;

    pub_raw_velocity.publish(raw_velocity_msg);    
}
//-----------------------------------------------------------------------------
//-- publish topic - pub_raw_megguider -------- 
void crltMessageInterface::pub_raw_megguider_topic(json jsonObj)
{
    raw_megguider_msg.Mag_center_analog = jsonObj["Mag_center_analog"] ;
    raw_megguider_msg.Mag_center_digital = jsonObj["Mag_center_digital"] ;
    raw_megguider_msg.car_roller_status = jsonObj["car_roller_status"] ;
    raw_megguider_msg.car_velrpm_left = jsonObj["car_velrpm_left"] ;
    raw_megguider_msg.car_velrpm_right = jsonObj["car_velrpm_right"] ;
    raw_megguider_msg.car_control_code = jsonObj["car_control_code"] ;
    raw_megguider_msg.car_Status_code = jsonObj["car_Status_code"] ;
    raw_megguider_msg.car_Command_code = jsonObj["car_Command_code"] ;
    raw_megguider_msg.car_Error_code = jsonObj["car_Error_code"] ;
    raw_megguider_msg.car_SetCommand = jsonObj["car_SetCommand"] ;
    raw_megguider_msg.roller_SetCommand = jsonObj["roller_SetCommand"] ;
    raw_megguider_msg.Mag_center_analog = jsonObj["Mag_center_analog"] ;

    pub_raw_megguider.publish(raw_megguider_msg);    
}
//-----------------------------------------------------------------------------
//-- publish topic - pub_raw_megnav (for ROS use in status of magguider out-of-service)  
void crltMessageInterface::pub_raw_magnav_topic(json jsonObj)
{
    raw_magnav_msg.Mag_center_analog = jsonObj["Mag_center_analog"] ;
    raw_magnav_msg.Mag_center_digital = jsonObj["Mag_center_digital"] ;
    raw_magnav_msg.car_roller_status = jsonObj["car_roller_status"] ;
    raw_magnav_msg.car_velrpm_left = jsonObj["car_velrpm_left"] ;
    raw_magnav_msg.car_velrpm_right = jsonObj["car_velrpm_right"] ;
    raw_magnav_msg.car_control_code = jsonObj["car_control_code"] ;
    raw_magnav_msg.car_Status_code = jsonObj["car_Status_code"] ;
    raw_magnav_msg.car_Command_code = jsonObj["car_Command_code"] ;
    raw_magnav_msg.car_Error_code = jsonObj["car_Error_code"] ;
    raw_magnav_msg.car_SetCommand = jsonObj["car_SetCommand"] ;
    raw_magnav_msg.roller_SetCommand = jsonObj["roller_SetCommand"] ;
    raw_magnav_msg.Mag_center_analog = jsonObj["Mag_center_analog"] ;

    pub_raw_magnav.publish(raw_magnav_msg);    
}
//-----------------------------------------------------------------------------
//-- publish topic - pub_raw_reader
void crltMessageInterface::pub_raw_reader_topic(json jsonObj)
{
    raw_reader_msg.stamp = ros::Time::now() ;
    raw_reader_msg.status = jsonObj["status"] ; 
    raw_reader_msg.error_code = jsonObj["error_code"] ; 
    raw_reader_msg.data = jsonObj["parameter"] ;   

    pub_raw_reader.publish(raw_reader_msg);    
}
//-----------------------------------------------------------------------------
//-- publish topic - pub_stmudp_heartbeat
void crltMessageInterface::pub_stmudp_heartbeat_topic(json jsonObj)
{   
    raw_heartbeat_msg.hb_stamp = jsonObj["hb_stamp"] ;     
    raw_heartbeat_msg.hb_status = jsonObj["hb_status"] ; 

    pub_stmudp_heartbeat.publish(raw_heartbeat_msg);    
}

//-----------------------------------------------------------------------------
//-- publish topic - pub_raw_sick -------- 
void crltMessageInterface::pub_raw_sick_topic(json jsonObj)
{
    raw_sick_msg.data = jsonObj["data"] ;

    pub_raw_sick.publish(raw_sick_msg);    
}
//--
//-----------------------------------------------------------------------------
//-- callback for bot_ledbar_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_ledbar(botcmd_msgs::bot_do_cmd::Request  &req,
								               botcmd_msgs::bot_do_cmd::Response &resp)
{    
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_ledbar_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_ledbar begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_ledbar_cmd_srv";
        jsonObj["command"] = req.command ;
        jsonObj["parameter"] = req.parameter ;
        jsonObj["result"] = resp.result ;

        //-- add command data to clientService_Buffer and send data to stm by thread ---
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);     
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
        
        //-- wait for data (received result from stm) and get response  -----
        call_led_base_time = ros::Time::now();
        b_call_led_timeout = false ;
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);   
    }
    //-- response to service caller ---
    if(bRet && !b_call_led_timeout)
        resp.result = rst_jsonObject["result"] ;
    else
        resp.result = false ; 
    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;//bRet ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_music_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_music(botcmd_msgs::bot_do_cmd::Request  &req,
								              botcmd_msgs::bot_do_cmd::Response &resp)
{
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_music_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_music begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_ledbar_cmd_srv";
        jsonObj["command"] = req.command ;
        jsonObj["parameter"] = req.parameter ;
        jsonObj["result"] = resp.result ;

        //-- add command data to clientService_Buffer and send data to stm by thread ---
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);   
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
        
        //-- wait for data (received result from stm) and get response  -----
        call_music_base_time = ros::Time::now();
        b_call_music_timeout = false ;
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);   
    }
    //-- response to service caller ---
    if(bRet && !b_call_music_timeout)
        resp.result = rst_jsonObject["result"] ;
    else
        resp.result = false ; 
    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_download_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_download(botcmd_msgs::bot_transfer_cmd::Request  &req,
								                 botcmd_msgs::bot_transfer_cmd::Response &resp)
{
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_download_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_download begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_download_cmd_srv";
        jsonObj["index_ID"] = req.index_ID ;
        jsonObj["parameter"] = req.parameter ;
        jsonObj["result"] = resp.result ;
        jsonObj["result_ID"] = resp.result_ID ;
        jsonObj["result_Data"] = resp.result_Data ;

        //-- add command data to clientService_Buffer and send data to stm by thread ---
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);  
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
        
        //-- wait for data (received result from stm) and get response  -----
        call_download_base_time = ros::Time::now();
        b_call_download_timeout = false ;
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);   
    }
    //-- response to service caller ---
    if(bRet && !b_call_download_timeout){
        resp.result = rst_jsonObject["result"] ;
        resp.result_ID = rst_jsonObject["result_ID"] ;
        resp.result_Data = rst_jsonObject["result_Data"] ;
    }
    else{
        resp.result = false ;
        resp.result_ID = 0 ;
        resp.result_Data = "" ;
    }    
    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_ultrasonic_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_ultrasonic(botcmd_msgs::bot_ultrasonic_cmd::Request  &req,
								                   botcmd_msgs::bot_ultrasonic_cmd::Response &resp)
{
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_ultrasonic_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_ultrasonic begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_ultrasonic_cmd_srv";
        jsonObj["command"] = req.command ;
        jsonObj["result"] = resp.result ;
        jsonObj["Command_Params"] = resp.Command_Params ;
        jsonObj["quantity"] = resp.quantity ;
        jsonObj["ranges"] = resp.ranges ;

        //-- add command data to clientService_Buffer and send data to stm by thread ---
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);   
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
        
        //-- wait for data (received result from stm) and get response  -----
        call_ultrasonic_base_time = ros::Time::now();
        b_call_ultrasonic_timeout = false ;
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);   
    }
    //-- response to service caller ---
    if(bRet && !b_call_ultrasonic_timeout){
        resp.result = rst_jsonObject["result"] ;
        resp.Command_Params = rst_jsonObject["Command_Params"] ;
        resp.quantity = rst_jsonObject["quantity"] ;
        resp.ranges = rst_jsonObject["ranges"] ;
        resp.stamp = ros::Time::now() ;
    }
    else{
        resp.result = false ;
        resp.Command_Params = 0;
        resp.quantity = 0 ;
        resp.ranges = "" ;
        resp.stamp = ros::Time::now() ;
    }    
    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_battery_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_battery(botcmd_msgs::bot_battery_cmd::Request  &req,
								                botcmd_msgs::bot_battery_cmd::Response &resp)
{
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_battery_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_battery begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        //---------------------------------0313---------------------------------------
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_battery_cmd_srv";
        jsonObj["command"] = req.command ;
        jsonObj["result"] = resp.result ;
        jsonObj["Command_Params"] = resp.Command_Params ;
        jsonObj["gen_alarmcode"] = resp.gen_alarmcode ;
        jsonObj["emg_alarmcode"] = resp.emg_alarmcode ;
        jsonObj["chargstate_code"] = resp.chargstate_code ;
        jsonObj["cell_balance_code"] = resp.cell_balance_code ;
        jsonObj["cell_volt_min"] = resp.cell_volt_min ;
        jsonObj["cell_volt_max"] = resp.cell_volt_max ;
        jsonObj["chargcurrent_code"] = resp.chargcurrent_code ;
        jsonObj["full_capacity"] = resp.full_capacity ;
        jsonObj["loop_counter"] = resp.loop_counter ;
        jsonObj["cell_temp_min"] = resp.cell_temp_min ;
        jsonObj["cell_temp_max"] = resp.cell_temp_max ;
        jsonObj["Pack_tol_volt"] = resp.Pack_tol_volt ;
        jsonObj["Pack_resistance"] = resp.Pack_resistance ;
        jsonObj["total_discharge"] = resp.total_discharge ;
        jsonObj["ASOC_code"] = resp.ASOC_code ;
        jsonObj["scaleunit_code"] = resp.scaleunit_code ;

        /*jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_battery_cmd_srv";
        jsonObj["command"] = req.command ;
        jsonObj["result"] = resp.result ;
        jsonObj["Command_Params"] = resp.Command_Params ;*/
        //jsonObj["chargcurrent_code"] = resp.chargcurrent_code ;
        //jsonObj["ASOC_code"] = resp.ASOC_code ;
        


        //-- add command data to clientService_Buffer and send data to stm by thread ---
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);      
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
        
        //-- wait for data (received result from stm) and get response  -----
        call_battery_base_time = ros::Time::now();
        b_call_battery_timeout = false ;
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);   
    }
    //-- response to service caller ---
    if(bRet && !b_call_battery_timeout){
        //---------------------------------0313---------------------------------------
        resp.result = rst_jsonObject["result"] ;
        resp.Command_Params = rst_jsonObject["Command_Params"] ;
        resp.gen_alarmcode = rst_jsonObject["gen_alarmcode"] ;
        resp.emg_alarmcode = rst_jsonObject["emg_alarmcode"] ;
        resp.chargstate_code = rst_jsonObject["chargstate_code"] ;
        resp.cell_balance_code = rst_jsonObject["cell_balance_code"] ;
        resp.cell_volt_min = rst_jsonObject["cell_volt_min"] ;
        resp.cell_volt_max = rst_jsonObject["cell_volt_max"] ;
        resp.chargcurrent_code = rst_jsonObject["chargcurrent_code"] ;
        resp.full_capacity = rst_jsonObject["full_capacity"] ;
        resp.loop_counter = rst_jsonObject["loop_counter"] ;
        resp.cell_temp_min = rst_jsonObject["cell_temp_min"] ;
        resp.cell_temp_max = rst_jsonObject["cell_temp_max"] ;
        resp.Pack_tol_volt = rst_jsonObject["Pack_tol_volt"] ;
        resp.Pack_resistance = rst_jsonObject["Pack_resistance"] ;
        resp.total_discharge = rst_jsonObject["total_discharge"] ;
        resp.ASOC_code = rst_jsonObject["ASOC_code"] ;
        resp.scaleunit_code = rst_jsonObject["scaleunit_code"] ;
        resp.stamp = ros::Time::now() ;

        /*resp.result = rst_jsonObject["result"] ;
        resp.Command_Params = rst_jsonObject["Command_Params"] ;
        resp.chargcurrent_code = rst_jsonObject["chargcurrent_code"] ;
        resp.ASOC_code = rst_jsonObject["ASOC_code"] ;
        resp.stamp = ros::Time::now() ;*/
    }
    else{
        resp.result = false ;
        resp.gen_alarmcode = 0 ;
        resp.emg_alarmcode = 0 ;
        resp.chargstate_code = 0 ;
        resp.cell_balance_code = 0 ;
        resp.cell_volt_min = 0 ;
        resp.cell_volt_max = 0 ;
        resp.chargcurrent_code = 0 ;
        resp.full_capacity = 0 ;
        resp.loop_counter = 0 ;
        resp.cell_temp_min = 0 ;
        resp.cell_temp_max = 0 ;
        resp.Pack_tol_volt = 0 ;
        resp.Pack_resistance = 0 ;
        resp.total_discharge = 0 ;
        resp.ASOC_code = 0 ;
        resp.scaleunit_code = 0 ;
        resp.stamp = ros::Time::now() ;
    }    
    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_battery_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_battery_info(botcmd_msgs::bot_battery_info_cmd::Request  &req,
								                     botcmd_msgs::bot_battery_info_cmd::Response &resp)
{
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_battery_info_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_battery begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        //---------------------------------0313---------------------------------------
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_battery_cmd_srv";
        jsonObj["command"] = req.command ;
        jsonObj["result"] = resp.result ;
        jsonObj["Command_Params"] = resp.Command_Params ;
        jsonObj["alarmcode"] = resp.alarmcode ;
        jsonObj["chargstate"] = resp.chargstate ;
        jsonObj["voltage"] = resp.voltage ;
        jsonObj["current"] = resp.current ;
        jsonObj["full_capacity"] = resp.full_capacity ;
        jsonObj["percentage"] = resp.percentage ;    


        //-- add command data to clientService_Buffer and send data to stm by thread ---
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);      
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
        
        //-- wait for data (received result from stm) and get response  -----
        call_battery_info_base_time = ros::Time::now();
        b_call_battery_info_timeout = false ;
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);   
    }
    //-- response to service caller ---
    if(bRet && !b_call_battery_info_timeout){
        //---------------------------------0313---------------------------------------
        resp.result = rst_jsonObject["result"] ;
        resp.Command_Params = rst_jsonObject["Command_Params"] ;
        resp.alarmcode = rst_jsonObject["alarmcode"] ;
        resp.chargstate = rst_jsonObject["chargstate"] ;
        resp.voltage = rst_jsonObject["voltage"] ;
        resp.current = rst_jsonObject["current"] ;
        resp.full_capacity = rst_jsonObject["full_capacity"] ;
        resp.percentage = rst_jsonObject["percentage"] ;
        resp.stamp = ros::Time::now() ;

        /*resp.result = rst_jsonObject["result"] ;
        resp.Command_Params = rst_jsonObject["Command_Params"] ;
        resp.chargcurrent_code = rst_jsonObject["chargcurrent_code"] ;
        resp.ASOC_code = rst_jsonObject["ASOC_code"] ;
        resp.stamp = ros::Time::now() ;*/
    }
    else{
        resp.result = false ;
        resp.alarmcode = 0 ;
        resp.chargstate = 0 ;
        resp.voltage = 0 ;
        resp.current = 0 ;
        resp.full_capacity = 0 ;
        resp.percentage = 0 ;
        resp.stamp = ros::Time::now() ;
    }    
    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_reader_status_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_reader_status(botcmd_msgs::bot_status_cmd::Request  &req,
								                      botcmd_msgs::bot_status_cmd::Response &resp)
{
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_reader_status_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_reader_status begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_reader_status_cmd_srv";
        jsonObj["command"] = req.Command ;
        jsonObj["result"] = resp.result ;
        jsonObj["result_Command"] = resp.result_Command ;
        jsonObj["status_code"] = resp.status_code ;
        jsonObj["error_code"] = resp.error_code ;
        jsonObj["data"] = resp.data ;

        //-- add command data to clientService_Buffer and send data to stm by thread ---
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
        
        //-- wait for data (received result from stm) and get response  -----
        call_reader_base_time = ros::Time::now();
        b_call_reader_timeout = false ;
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);   
    }
    //-- response to service caller ---
    if(bRet && !b_call_reader_timeout){
        resp.result = rst_jsonObject["result"];
		resp.result_Command = rst_jsonObject["result_Command"];
		resp.status_code = rst_jsonObject["status_code"];
		resp.error_code = rst_jsonObject["error_code"];
		resp.data = rst_jsonObject["data"];
        resp.stamp = ros::Time::now() ;
    }
    else{
        resp.result = false;
		resp.result_Command = 0;
		resp.status_code = 0;
		resp.error_code = 0;
		resp.data = "";
        resp.stamp = ros::Time::now() ;
    }    
    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_ssr_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_ssr(botcmd_msgs::bot_do_cmd::Request  &req,
								            botcmd_msgs::bot_do_cmd::Response &resp)
{
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_ssr_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_ssr begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_ssr_cmd_srv";
        jsonObj["command"] = req.command ;
        jsonObj["parameter"] = req.parameter ;
        jsonObj["result"] = resp.result ;

        //-- add command data to clientService_Buffer and send data to stm by thread ---
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);     
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
        
        //-- wait for data (received result from stm) and get response  -----
        call_ssr_base_time = ros::Time::now();
        b_call_ssr_timeout = false ;
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);   
    }
    //-- response to service caller ---
    if(bRet && !b_call_ssr_timeout)
        resp.result = rst_jsonObject["result"] ;
    else
        resp.result = false ; 

    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_imu_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_imu(botcmd_msgs::bot_do_cmd::Request  &req,
								            botcmd_msgs::bot_do_cmd::Response &resp)
{
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_imu_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_imu begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_imu_cmd_srv";
        jsonObj["command"] = req.command ;
        jsonObj["parameter"] = req.parameter ;
        jsonObj["result"] = resp.result ;

        //-- add command data to clientService_Buffer and send data to stm by thread ---
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);   
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
        
        //-- wait for data (received result from stm) and get response  -----
        call_imu_base_time = ros::Time::now();
        b_call_imu_timeout = false ;
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);   
    }
    //-- response to service caller ---
    if(bRet && !b_call_imu_timeout)
        resp.result = rst_jsonObject["result"] ;
    else
        resp.result = false ; 

    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_SetFunction_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_SetFunction(botcmd_msgs::bot_do_cmd::Request  &req,
								            botcmd_msgs::bot_do_cmd::Response &resp)
{
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_SetFunction_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_SetFunction begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_SetFunction_cmd_srv";
        jsonObj["command"] = req.command ;
        jsonObj["parameter"] = req.parameter ;
        jsonObj["result"] = resp.result ;

        //-- add command data to clientService_Buffer and send data to stm by thread ---
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);   
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
        
        //-- wait for data (received result from stm) and get response  -----
        call_SetFunction_base_time = ros::Time::now();
        b_call_SetFunction_timeout = false ;
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);   
    }
    //-- response to service caller ---
    if(bRet && !b_call_SetFunction_timeout)
        resp.result = rst_jsonObject["result"] ;
    else
        resp.result = false ; 

    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_io_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_io(botcmd_msgs::bot_do_cmd::Request  &req,
								            botcmd_msgs::bot_do_cmd::Response &resp)
{
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_io_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_io begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_io_cmd_srv";
        jsonObj["command"] = req.command ;
        jsonObj["parameter"] = req.parameter ;
        jsonObj["result"] = resp.result ;

        //-- add command data to clientService_Buffer and send data to stm by thread ---
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);   
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
        
        //-- wait for data (received result from stm) and get response  -----
        call_io_base_time = ros::Time::now();
        b_call_io_timeout = false ;
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);   
    }
    //-- response to service caller ---
    if(bRet && !b_call_io_timeout)
        resp.result = rst_jsonObject["result"] ;
    else
        resp.result = false ; 

    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_laserarea_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_laserarea(botcmd_msgs::bot_do_cmd::Request  &req,
								            botcmd_msgs::bot_do_cmd::Response &resp)
{
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_laserarea_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_laserarea begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_laserarea_cmd_srv";
        jsonObj["command"] = req.command ;
        jsonObj["parameter"] = req.parameter ;
        jsonObj["result"] = resp.result ;

        //-- add command data to clientService_Buffer and send data to stm by thread ---
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);   
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
        
        //-- wait for data (received result from stm) and get response  -----
        call_laserarea_base_time = ros::Time::now();
        b_call_laserarea_timeout = false ;
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);   
    }
    //-- response to service caller ---
    if(bRet && !b_call_laserarea_timeout)
        resp.result = rst_jsonObject["result"] ;
    else
        resp.result = false ; 

    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_motor1_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_motor1(botcmd_msgs::bot_status_cmd::Request  &req,
								               botcmd_msgs::bot_status_cmd::Response &resp)
{
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_motor1_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_motor1 begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_motor1_cmd_srv";
        jsonObj["command"] = req.Command ;
        jsonObj["result"] = resp.result ;
        jsonObj["result_Command"] = resp.result_Command ;
        jsonObj["status_code"] = resp.status_code ;
        jsonObj["error_code"] = resp.error_code ;
        jsonObj["data"] = resp.data ;

        //-- add command data to clientService_Buffer and send data to stm by thread ---
                //ROS_INFO("<< === srv_Eval_bot_SetFunction begin === >>1");
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);   
                //ROS_INFO("<< === srv_Eval_bot_SetFunction begin === >>2");
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
               // ROS_INFO("<< === srv_Eval_bot_SetFunction begin === >>3");
        
        //-- wait for data (received result from stm) and get response  -----
        call_motor1_base_time = ros::Time::now();
        b_call_motor1_timeout = false ;
        //ROS_INFO("<< === srv_Eval_bot_SetFunction begin === >>4");
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);
        //ROS_INFO("<< === srv_Eval_bot_SetFunction begin === >>5");   
    }
    //-- response to service caller ---
    if(bRet && !b_call_motor1_timeout){
        resp.result = rst_jsonObject["result"];
		resp.result_Command = rst_jsonObject["result_Command"];
		resp.status_code = rst_jsonObject["status_code"];
		resp.error_code = rst_jsonObject["error_code"];
		resp.data = rst_jsonObject["data"];
        resp.stamp = ros::Time::now() ;
    }
    else{
        resp.result = false;
		resp.result_Command = 0;
		resp.status_code = 0;
		resp.error_code = 0;
		resp.data = "";
        resp.stamp = ros::Time::now() ;
    } 

    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_motor2_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_motor2(botcmd_msgs::bot_status_cmd::Request  &req,
								               botcmd_msgs::bot_status_cmd::Response &resp)
{
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_motor2_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_motor2 begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_motor2_cmd_srv";
        jsonObj["command"] = req.Command ;
        jsonObj["result"] = resp.result ;
        jsonObj["result_Command"] = resp.result_Command ;
        jsonObj["status_code"] = resp.status_code ;
        jsonObj["error_code"] = resp.error_code ;
        jsonObj["data"] = resp.data ;

        //-- add command data to clientService_Buffer and send data to stm by thread ---
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);     
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
        
        //-- wait for data (received result from stm) and get response  -----
        call_motor2_base_time = ros::Time::now();
        b_call_motor2_timeout = false ;
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);   
    }
    //-- response to service caller ---
    if(bRet && !b_call_motor2_timeout){
        resp.result = rst_jsonObject["result"];
		resp.result_Command = rst_jsonObject["result_Command"];
		resp.status_code = rst_jsonObject["status_code"];
		resp.error_code = rst_jsonObject["error_code"];
		resp.data = rst_jsonObject["data"];
        resp.stamp = ros::Time::now() ;
    }
    else{
        resp.result = false;
		resp.result_Command = 0;
		resp.status_code = 0;
		resp.error_code = 0;
		resp.data = "";
        resp.stamp = ros::Time::now() ;
    } 

    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_motor3_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_motor3(botcmd_msgs::bot_status_cmd::Request  &req,
								               botcmd_msgs::bot_status_cmd::Response &resp)
{
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_motor3_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_motor3 begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_motor3_cmd_srv";
        jsonObj["command"] = req.Command ;
        jsonObj["result"] = resp.result ;
        jsonObj["result_Command"] = resp.result_Command ;
        jsonObj["status_code"] = resp.status_code ;
        jsonObj["error_code"] = resp.error_code ;
        jsonObj["data"] = resp.data ;

        //-- add command data to clientService_Buffer and send data to stm by thread ---
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);     
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
        
        //-- wait for data (received result from stm) and get response  -----
        call_motor3_base_time = ros::Time::now();
        b_call_motor3_timeout = false ;
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);   
    }
    //-- response to service caller ---
    if(bRet && !b_call_motor3_timeout){
        resp.result = rst_jsonObject["result"];
		resp.result_Command = rst_jsonObject["result_Command"];
		resp.status_code = rst_jsonObject["status_code"];
		resp.error_code = rst_jsonObject["error_code"];
		resp.data = rst_jsonObject["data"];
        resp.stamp = ros::Time::now() ;
    }
    else{
        resp.result = false;
		resp.result_Command = 0;
		resp.status_code = 0;
		resp.error_code = 0;
		resp.data = "";
        resp.stamp = ros::Time::now() ;
    } 

    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_motor4_srvService from ros's clientservice
bool crltMessageInterface::srv_Eval_bot_motor4(botcmd_msgs::bot_status_cmd::Request  &req,
								               botcmd_msgs::bot_status_cmd::Response &resp)
{
    bool b_stm_hb = stm_heartbeat_check() ;
    bool bRet = false ;
    json rst_jsonObject;
    std::string service_name = bot_motor4_srvService_name ; 
    if(b_stm_hb){        
        //ROS_INFO("<< === srv_Eval_bot_motor4 begin === >>");
        thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
        json jsonObj;
        jsonObj["main_type"] = "ros_service";
        jsonObj["service_name"] = service_name ;//"bot_motor4_cmd_srv";
        jsonObj["command"] = req.Command ;
        jsonObj["result"] = resp.result ;
        jsonObj["result_Command"] = resp.result_Command ;
        jsonObj["status_code"] = resp.status_code ;
        jsonObj["error_code"] = resp.error_code ;
        jsonObj["data"] = resp.data ;

        //-- add command data to clientService_Buffer and send data to stm by thread ---
        udpBridge.add_jsonObject_Buffer(jsonObj,eVector_cltService);   
        udpBridge.showWokerDataStatus(service_name,eVector_cltService);     
        
        //-- wait for data (received result from stm) and get response  -----
        call_motor4_base_time = ros::Time::now();
        b_call_motor4_timeout = false ;
        bRet = set_cltservice_send_proc(service_name,rst_jsonObject);   
    }
    //-- response to service caller ---
    if(bRet && !b_call_motor4_timeout){
        resp.result = rst_jsonObject["result"];
		resp.result_Command = rst_jsonObject["result_Command"];
		resp.status_code = rst_jsonObject["status_code"];
		resp.error_code = rst_jsonObject["error_code"];
		resp.data = rst_jsonObject["data"];
        resp.stamp = ros::Time::now() ;
    }
    else{
        resp.result = false;
		resp.result_Command = 0;
		resp.status_code = 0;
		resp.error_code = 0;
		resp.data = "";
        resp.stamp = ros::Time::now() ;
    } 

    if(b_stm_hb){ 
        //-- erase this data from Worker_cltService
        udpBridge.erase_jsonObject_Buffer(service_name,eVector_cltService) ;
        udpBridge.showWokerDataStatus(service_name ,eVector_cltService);
    }
    //------------------------
    return true ;
}
//-----------------------------------------------------------------------------
//-- callback for bot_motor4_srvService from ros's clientservice
int crltMessageInterface::get_Buffer_Size(eVector_type _type)
{       
    return udpBridge.get_Buffer_Size(_type) ;
}
//-----------------------------------------------------------------------------
//-- udpCheck_PortIsOpened   ---------------
bool crltMessageInterface::udpCheck_PortIsOpened() 
{	
	bool bRet = udpBridge.udpCheck_PortIsOpened() ;
	return bRet ;
}
//-----------------------------------------------------------------------------
//-- udp_CloseCommPort   ---------------
void crltMessageInterface::udp_CloseCommPort() 
{	
	udpBridge.udp_CloseCommPort() ;
}
//-----------------------------------------------------------------------------
//-- udp_CloseCommPort   ---------------
robot_control_msgs::hyc_heartbeat crltMessageInterface::get_raw_heartbeat_msg() 
{	
	return raw_heartbeat_msg ;
}
//-----------------------------------------------------------------------------
//-- stm heart beat check !!!  --
bool crltMessageInterface::stm_heartbeat_check() 
{
    bool bRet = (pre_heartbeat_id != raw_heartbeat_msg.hb_stamp);
    if(!bRet){
        int counter = 0;
        while(counter < 5){
            thd::this_thread::sleep_for(std::chrono::milliseconds(5));
            bRet = (pre_heartbeat_id != raw_heartbeat_msg.hb_stamp);
            if(bRet) break ;
            else     counter++;     
        }
    }    
    pre_heartbeat_id = raw_heartbeat_msg.hb_stamp ;

    return bRet ; 
}
//-----------------------------------------------------------------------------
//-- call_service_timeout_check --
bool crltMessageInterface::call_service_timeout_check(std::string type_name)
{
    bool bRet = false ;
    if(type_name == bot_ledbar_srvService_name){ //"led"){
        bRet = ((ros::Time::now() - call_led_base_time).toSec() >= call_service_timeout)  ;
    }
    else if(type_name == bot_music_srvService_name){ //"music"){
        bRet = ((ros::Time::now() - call_music_base_time).toSec() >= call_service_timeout)  ;
    }

    else if(type_name == bot_download_srvService_name){ //"download"){
        bRet = ((ros::Time::now() - call_download_base_time).toSec() >= call_service_timeout)  ;
    }
    else if(type_name == bot_ultrasonic_srvService_name){ //"ultrasonic"){
        bRet = ((ros::Time::now() - call_ultrasonic_base_time).toSec() >= call_service_timeout)  ;
    }
    else if(type_name == bot_battery_srvService_name){ //"battery"){
        bRet = ((ros::Time::now() - call_battery_base_time).toSec() >= call_service_timeout)  ;
    }
    //-- 20200317 Add --
    else if(type_name == bot_battery_info_srvService_name){ //"battery"){
        bRet = ((ros::Time::now() - call_battery_info_base_time).toSec() >= call_service_timeout)  ;
    }
    //-------------------
    else if(type_name == bot_reader_status_srvService_name){ //"reader"){
        bRet = ((ros::Time::now() - call_reader_base_time).toSec() >= call_service_timeout)  ;
    }
    else if(type_name == bot_ssr_srvService_name){ //"ssr"){
        bRet = ((ros::Time::now() - call_ssr_base_time).toSec() >= call_service_timeout)  ;
    }
    else if(type_name == bot_imu_srvService_name){ //"imu"){
        bRet = ((ros::Time::now() - call_imu_base_time).toSec() >= call_service_timeout)  ;
    }
    else if(type_name == bot_SetFunction_srvService_name){ //"SetFunction"){
        bRet = ((ros::Time::now() - call_SetFunction_base_time).toSec() >= call_service_timeout)  ;
    }
    else if(type_name == bot_io_srvService_name){ //"io"){
        bRet = ((ros::Time::now() - call_io_base_time).toSec() >= call_service_timeout)  ;
    }
    else if(type_name == bot_laserarea_srvService_name){ //"laserarea"){
        bRet = ((ros::Time::now() - call_laserarea_base_time).toSec() >= call_service_timeout)  ;
    }
    else if(type_name == bot_motor1_srvService_name){ //"motor1"){
        bRet = ((ros::Time::now() - call_motor1_base_time).toSec() >= call_service_timeout)  ;
    }
    else if(type_name == bot_motor2_srvService_name){//"motor2"){
        bRet = ((ros::Time::now() - call_motor2_base_time).toSec() >= call_service_timeout)  ;
    }
    else if(type_name == bot_motor3_srvService_name){ //"motor3"){
        bRet = ((ros::Time::now() - call_motor3_base_time).toSec() >= call_service_timeout)  ;
    }
    else if(type_name == bot_motor3_srvService_name){ //"motor4"){
        bRet = ((ros::Time::now() - call_motor4_base_time).toSec() >= call_service_timeout)  ;
    }
    return bRet ;
}
//-----------------------------------------------------------------------------
void crltMessageInterface::bManual_test_set(bool btest)
{
    bManual_test = btest ;
}
//-----------------------------------------------------------------------------
