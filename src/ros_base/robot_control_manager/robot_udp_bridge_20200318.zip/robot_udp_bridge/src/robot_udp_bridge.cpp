#include <robot_udp_bridge/robot_udp_bridge.h>
#include <range/v3/all.hpp>
//#include <tools/ros_tools.h>
#include <ros_utility_tools/ros_tools.h>
//*****************************************************************************
//** main class crlt_messagemanager                                          ** 
//*****************************************************************************
//-----------------------------------------------------------------------------
//-- crlt_messagemanager constructor  -----
robot_udp_bridge::robot_udp_bridge(ros::NodeHandle &nh) : crlt_msg_Interface(nh) 
{ 
    nh_ = nh ;
    Load_CntParameter();
}
//-----------------------------------------------------------------------------
//-- crlt_messagemanager de-constructor ---------------
robot_udp_bridge::~robot_udp_bridge()
{
  crlt_msg_Interface.crltMessage_start_set(false);
}
//-----------------------------------------------------------------------------
//-- load control parameters from parameter.yaml  ---------------
void robot_udp_bridge::Load_CntParameter()
{
    ros::NodeHandle pnh("~");

	if(!pnh.getParam("udp_PORT_OPEN_RETRY", udp_PORT_OPEN_RETRY))
        udp_PORT_OPEN_RETRY = 5 ;	
}
//-----------------------------------------------------------------------------
//-- udpCheck_PortIsOpened   ---------------
bool robot_udp_bridge::udpCheck_PortIsOpened() 
{	
	bool bRet = crlt_msg_Interface.udpCheck_PortIsOpened() ;
	return bRet ;
}
//-----------------------------------------------------------------------------
//-- udpCheck_PortIsOpened   ---------------
void robot_udp_bridge::udp_CloseCommPort() 
{	
	crlt_msg_Interface.udp_CloseCommPort() ;
}
//-----------------------------------------------------------------------------
//-- robot_udp_bridge_Start   ---------------
void robot_udp_bridge::robot_udp_bridge_Start() 
{	
	crlt_msg_Interface.crltMessage_start_set(true);
    //------------------
    #if(using_msgTest_unit)
	    crlt_msg_testunit = new crlt_message_testunit(nh_) ;
        crlt_msg_Interface.bManual_test_set(true);
    #endif  
}
//-----------------------------------------------------------------------------
//*****************************************************************************
//** main enterpoint of this crlt_messagemanager_node                        ** 
//*****************************************************************************
//-----------------------------------------------------------------------------
int main(int argc, char **argv)
{
    ros::init(argc, argv, "robot_udp_bridge_node");
    ros::NodeHandle nh;
    robot_udp_bridge _robot_udp_bridge(nh);
    
    bool budp_ready = false ;
    for(int i=0;i<_robot_udp_bridge.udp_PORT_OPEN_RETRY*10;i++){
        budp_ready = _robot_udp_bridge.udpCheck_PortIsOpened();
        if(budp_ready)
            break ;
        else{
            std::string tmp = "retry counter : " + convert_str(i);
			ROS_INFO(tmp.c_str());
        }

    }
    if(!budp_ready){
        ROS_INFO("udp_port initial fail,system exit !!!");
        return -1 ;    
    }
    _robot_udp_bridge.robot_udp_bridge_Start();

    ros::spin();
    return 0;
}
//-----------------------------------------------------------------------------
