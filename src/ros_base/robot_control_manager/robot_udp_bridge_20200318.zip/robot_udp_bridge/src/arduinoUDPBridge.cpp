#include <robot_udp_bridge/arduinoUDPBridge.h>
//*****************************************************************************
//-----------------------------------------------------------------------------
//-- ArduinoUDPBridge constructor  -----
arduinoUDPBridge::arduinoUDPBridge(ros::NodeHandle &nh): nh_(nh),
				Worker_publish(eVector_pub),	
				Worker_subscribe(eVector_sub),
				Worker_cltService(eVector_cltService),
				Worker_srvService(eVector_srvService)								 
{ 
	Load_CntParameter();
	//----------------
	udpServerPtr = std::make_shared<async_comm::UDP>(sever_bind_host, sever_bind_port, sever_remote_host, sever_remote_port);
	//----------------
	udpClient_thd_destory = false;
	udpClient_thd_pass = false;
    udpClient_thread = std::unique_ptr<thd::thread>( new thd::thread( thd::bind(&arduinoUDPBridge::udpClient_ThreadEntry, this)));
}
//-----------------------------------------------------------------------------
//-- ArduinoUDPBridge de-constructor ---------------
arduinoUDPBridge::~arduinoUDPBridge()
{
	CloseCommPort();
}
//-----------------------------------------------------------------------------
//-- load control parameters from parameter.yaml  ---------------
void arduinoUDPBridge::Load_CntParameter()
{
    ros::NodeHandle pnh("~");

    if(!pnh.getParam("sever_bind_host", sever_bind_host))
        sever_bind_host = "192.168.99.62";
    if(!pnh.getParam("sever_bind_port", sever_bind_port))
        sever_bind_port = 14620 ;
    if(!pnh.getParam("sever_remote_host", sever_remote_host))
        sever_remote_host = "192.168.99.177";
    if(!pnh.getParam("sever_remote_port", sever_remote_port))
        sever_remote_port = 14625 ;

	if(!pnh.getParam("client_bind_host", client_bind_host))
        client_bind_host = "192.168.99.62";
    if(!pnh.getParam("client_bind_port", client_bind_port))
        client_bind_port = 14425 ;
    if(!pnh.getParam("client_remote_host", client_remote_host))
        client_remote_host = "192.168.99.177";
    if(!pnh.getParam("client_remote_port", client_remote_port))
        client_remote_port = 14420 ;	

	if(!pnh.getParam("udp_PORT_OPEN_RETRY", udp_PORT_OPEN_RETRY))
        udp_PORT_OPEN_RETRY = 5 ;	
}
//-----------------------------------------------------------------------------
//-- get udpServer's opened－status of communication port ---------------
bool arduinoUDPBridge::udpServer_PortIsOpened() 
{
    return udpServerPtr->init() ;	
}
//-----------------------------------------------------------------------------
//-- get udpClient's opened－status of communication port ---------------
bool arduinoUDPBridge::udpClient_PortIsOpened() 
{
    return udpClientPtr->init() ;
}
//-----------------------------------------------------------------------------
//-- close udpServer‘s ＆ udpClient's port ---------------
void arduinoUDPBridge::CloseCommPort()
{
	if (udpClient_thread->joinable())
	{
        thd::lock_guard<thd::mutex> lock(udpClient_mtx);
        udpClient_thd_destory = true;
        udpClient_cv.notify_one();
    }
	//----------------	
	udpServerPtr->close();
	udpClientPtr->close();
}
//-----------------------------------------------------------------------------
//-- read data from sever_remote_port of sever_remote_host ---------------
void arduinoUDPBridge::Receive_Data_CB(const uint8_t *buf, size_t len)
{	
	//ROS_INFO("=== Receive_Data_CB === ");
	thd::this_thread::sleep_for(std::chrono::milliseconds(1));
	//-- get and parse data and assign to vector --	
	json recv_jsonObj ;
	std::string _main_type ;
	try{
		vector<uint8_t> vdata(buf, buf + len);
		std::string str(vdata.begin(),vdata.end());
		//ROS_INFO(str.c_str());
		recv_jsonObj = json::parse(str) ;	

		_main_type = recv_jsonObj["main_type"] ;	
	}
	catch (const json::type_error& e){
		std::cout << "from Receive - message: " << e.what() << '\n'
				<< "exception id: " << e.id << std::endl;
		return ;
	}
	catch (const std::bad_alloc& e) {
		std::cout << "from Receive Allocation failed: " << e.what() << '\n';
		return ;
	}
	catch (const std::logic_error& e) {
		std::cout << "from Receive std::logic_error: " << e.what() << '\n';
		return ;
	}
	catch (const std::exception &e)
	{		
		std::cerr << " from Receive error: " << e.what() << '\n';
		return ;
	}
	
	//-------------------			
	if(_main_type == "topic")
		add_jsonObject_Buffer(recv_jsonObj,eVector_sub) ;
	//--- clientSevice from stm , Register in serverService_Buffer ---- 
	else if(_main_type == "carcnt_service"){
		//ROS_INFO("==== Receive_Data_CB -- eVector_srvService =====") ;
		add_jsonObject_Buffer(recv_jsonObj,eVector_srvService) ;	
	}
	//--- response of serverSevice from stm , update status to clientService_Buffer --- 
	else if(_main_type == "ros_service")
		serverService_Response(recv_jsonObj);
	
}
//-----------------------------------------------------------------------------
void arduinoUDPBridge::udpClient_ThreadEntry() 
{
	//ROS_INFO("udpClient_ThreadEntry");
	thd::this_thread::sleep_for(std::chrono::milliseconds(1));
	//-- send message to stm for UDPWOrkerData including eVector_pub,eVector_cltService,eVector_srvService type
	while(true){
		thd::unique_lock<thd::mutex> lock(udpClient_mtx);	
		udpClient_cv.wait( lock, [&] () { return (udpClient_thd_destory || udpClient_thd_pass) ; } );
		if(udpClient_thd_destory)
			break;
		else{
			//-- run Action ----	
			udpClient_SendData();
		}	
		thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
	}
}
//-----------------------------------------------------------------------------
bool arduinoUDPBridge::udpClient_SendData_Action() 
{
	bool bRet = true ;
	std::string jsondata ;	
	try{
		jsondata = udp_result_json.dump();
	}
	catch (const json::type_error& e){
			std::cout << "from send message: " << e.what() << '\n'
					<< "exception id: " << e.id << std::endl;
			bRet = false ;
	}
	catch (const std::bad_alloc& e) {
		std::cout << "from send Allocation failed: " << e.what() << '\n';
		bRet = false ;
	}
	catch (const std::logic_error& e) {
		std::cout << "from send std::logic_error: " << e.what() << '\n';
		bRet = false ;
	}
	catch (const std::exception &e)
	{		
		std::cerr << " from send error: " << e.what() << '\n';
		bRet = false ;
	}

	if(bRet){
		bRet = (std::strlen(udp_result_json.dump().c_str())>0) ; 
		if(bRet)
			udpClientPtr->send_bytes((uint8_t*)(udp_result_json.dump().c_str()),std::strlen(udp_result_json.dump().c_str()));	
	}
	return bRet ;
}
//-----------------------------------------------------------------------------
void arduinoUDPBridge::udpClient_SendData() 
{
	//-- Send UDPWorkData : Worker_publish - eSRV_PROC_Register	
	if(Worker_publish.find_SRV_PROC_Step(eSRV_PROC_Register)){
		thd::lock_guard<thd::mutex> lock(udpClientRun_mtx);
		udp_result_json = Worker_publish.get_result_jsonObject(udp_result_iter);
		//udpClientPtr->send_bytes((uint8_t*)(udp_result_json.dump().c_str()),std::strlen(udp_result_json.dump().c_str()));	
		if(udp_result_iter >=0){
			udpClient_SendData_Action();
			Worker_publish.erase_data_jsonObject(udp_result_iter);
		}
	}
	//-- Send UDPWorkData : Worker_cltService - eSRV_PROC_Register	
	if(Worker_cltService.find_SRV_PROC_Step(eSRV_PROC_Register)){
		thd::lock_guard<thd::mutex> lock(udpClientRun_mtx);
		udp_result_json = Worker_cltService.get_result_jsonObject(udp_result_iter);
		//udpClientPtr->send_bytes((uint8_t*)(udp_result_json.dump().c_str()),std::strlen(udp_result_json.dump().c_str()));	
		if(udp_result_iter >=0){
			udpClient_SendData_Action();
			//-- set statue to eSRV_PROC_Send ----
			std::string type_name = udp_result_json["service_name"] ;
			Worker_cltService.modify_data_jsonObject(type_name,eSRV_PROC_Send);	
			showWokerDataStatus(type_name ,eVector_cltService) ;
		}
	}
	//-- Send UDPWorkData : Worker_srvService - eSRV_PROC_Recv	
	if(Worker_srvService.find_SRV_PROC_Step(eSRV_PROC_Recv)){
		//ROS_INFO("Worker_srvService sendout data !!");
		thd::lock_guard<thd::mutex> lock(udpClientRun_mtx);
		udp_result_json = Worker_srvService.get_result_jsonObject(udp_result_iter);	
		if(udp_result_iter >=0){
			if(udp_result_json != NULL){
				//ROS_INFO("==== send_jsonObject_Buffer -- eVector_srvService =====") ;			
				udpClient_SendData_Action();				
				Worker_srvService.erase_data_jsonObject(udp_result_iter);
				thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 		
			}
		}
	}
	//-- check buffer size ----
	bool buffer_size = Worker_publish.get_data_size() + Worker_cltService.get_data_size() +Worker_srvService.get_data_size() ;
	udpClient_thd_pass = (buffer_size > 0);
	udpClient_cv.notify_one();
}
//-----------------------------------------------------------------------------
//-- add a jsonObject  ---------------
bool arduinoUDPBridge::add_jsonObject_Buffer(json jsonObject,eVector_type _type)
{
	thd::lock_guard<thd::mutex> lock(udpClientRun_mtx);
	//if(_type == eVector_srvService){
	//	ROS_INFO("==== add_jsonObject_Buffer -- eVector_srvService =====") ;		
	//}
	bool bRet = true ;
	if(_type == eVector_pub)				Worker_publish.add_data_jsonObject(jsonObject);
	else if(_type == eVector_sub)			Worker_subscribe.add_data_jsonObject(jsonObject);
	else if(_type == eVector_cltService)	Worker_cltService.add_data_jsonObject(jsonObject);
	else if(_type == eVector_srvService)	Worker_srvService.add_data_jsonObject(jsonObject);
	else bRet = false ;

	if(bRet){
		udpClient_thd_pass = true;
		udpClient_cv.notify_one();
	}

	return bRet ;
}
//-----------------------------------------------------------------------------
//-- erase a assigned jsonObject   ---------------
bool arduinoUDPBridge::erase_jsonObject_Buffer(int iter,eVector_type _type)
{
	//ROS_INFO("=== erase_jsonObject_Buffer === ");	
	thd::lock_guard<thd::mutex> lock(udpClientRun_mtx);
	bool bRet = true ;
	if(_type == eVector_pub)				Worker_publish.erase_data_jsonObject(iter);
	else if(_type == eVector_sub)			Worker_subscribe.erase_data_jsonObject(iter);
	else if(_type == eVector_cltService)	Worker_cltService.erase_data_jsonObject(iter);
	else if(_type == eVector_srvService)	Worker_srvService.erase_data_jsonObject(iter);
	else bRet = false ;
	if(bRet){
		udpClient_thd_pass = true;
		udpClient_cv.notify_one();
	}

	return bRet ;	
}
//-----------------------------------------------------------------------------
//-- erase a assigned jsonObject   ---------------
bool arduinoUDPBridge::erase_jsonObject_Buffer(std::string type_name,eVector_type _type)
{
	//ROS_INFO("=== erase_jsonObject_Buffer_1 === ");	
	thd::lock_guard<thd::mutex> lock(udpClientRun_mtx);
	bool bRet = true ;
	if(_type == eVector_pub)				Worker_publish.erase_data_jsonObject(type_name);
	else if(_type == eVector_sub)			Worker_subscribe.erase_data_jsonObject(type_name);
	else if(_type == eVector_cltService)	Worker_cltService.erase_data_jsonObject(type_name);
	else if(_type == eVector_srvService)	Worker_srvService.erase_data_jsonObject(type_name);
	else bRet = false ;

	if(bRet){
		udpClient_thd_pass = true;
		udpClient_cv.notify_one();
	}

	return bRet ;	
}
//-----------------------------------------------------------------------------
//-- swap assigned two jsonObjects   ---------------
/*bool arduinoUDPBridge::swap_jsonObject_Buffer(int iter1,int iter2,eVector_type _type)
{
	//ROS_INFO("=== swap_jsonObject_Buffer === ");	
	thd::lock_guard<thd::mutex> lock(udpClientRun_mtx);
	bool bRet = true ;
	if(_type == eVector_pub)				Worker_publish.swap_data_jsonObject(iter1,iter2);
	else if(_type == eVector_sub)			Worker_subscribe.swap_data_jsonObject(iter1,iter2);
	else if(_type == eVector_cltService)	Worker_cltService.swap_data_jsonObject(iter1,iter2);
	else if(_type == eVector_srvService)	Worker_srvService.swap_data_jsonObject(iter1,iter2);
	else bRet = false ;

	if(bRet){
		udpClient_thd_pass = true;
		udpClient_cv.notify_one();
	}
	return bRet ;	
}*/
//-----------------------------------------------------------------------------
//-- get assigned jsonObject   ---------------
bool arduinoUDPBridge::get_jsonObject_Buffer(int iter,eVector_type _type,json &jsonObject,SRV_PROC_Step &_Step)
{
	bool bRet = true ;
	if(_type == eVector_pub)				Worker_publish.get_data_jsonObject(iter,jsonObject,_Step);  
	else if(_type == eVector_sub)			Worker_subscribe.get_data_jsonObject(iter,jsonObject,_Step);  
	else if(_type == eVector_cltService)	Worker_cltService.get_data_jsonObject(iter,jsonObject,_Step);  
	else if(_type == eVector_srvService)	Worker_srvService.get_data_jsonObject(iter,jsonObject,_Step);  
	else bRet = false ;

	if(bRet){
		udpClient_thd_pass = true;
		udpClient_cv.notify_one();
	}

	return bRet ;
}
//-----------------------------------------------------------------------------
//-- get assigned jsonObject   ---------------
int arduinoUDPBridge::get_Buffer_Size(eVector_type _type)
{
	int iRet = 0 ;
	if(_type == eVector_pub)				iRet = Worker_publish.get_data_size() ;
	else if(_type == eVector_sub)			iRet = Worker_subscribe.get_data_size() ; 
	else if(_type == eVector_cltService)	iRet = Worker_cltService.get_data_size() ;  
	else if(_type == eVector_srvService)	iRet = Worker_srvService.get_data_size() ;
	return iRet ;	
}
//-----------------------------------------------------------------------------
//-- update serverService_Buffer and serverService_Status_Buffer   ---------------
bool arduinoUDPBridge::serverService_Response(json jsonObject)
{	
	std::string main_type = jsonObject["main_type"] ;	
	bool bRet = (main_type == "ros_service") ;
	if(!bRet)	return bRet ;

	std::string type_name = jsonObject["service_name"] ;
	json _jsonObject ;
	SRV_PROC_Step _Step ;
	int _iter ;
	bRet = Worker_cltService.get_data_jsonObject(type_name,_jsonObject,_Step,_iter) ;
	if(bRet){
		//ROS_INFO(_jsonObject.dump().c_str());
		bRet = (_Step == eSRV_PROC_Send);
		if(bRet){	
			thd::lock_guard<thd::mutex> lock(udpClientRun_mtx);
			bRet = Worker_cltService.modify_data_jsonObject(type_name,jsonObject,eSRV_PROC_Recv);
			if(bRet){
				showWokerDataStatus(type_name ,eVector_cltService) ;

				udpClient_thd_pass = true;
				udpClient_cv.notify_one();
			}
		}
	}
	return true ;	
}
//-----------------------------------------------------------------------------
//-- add a jsonObject to publish_Buffer from back ---------------
bool arduinoUDPBridge::get_SRV_PROC_Step(std::string type_name,SRV_PROC_Step &_Step,eVector_type _type)
{
	bool bRet = false ;
	if(_type == eVector_pub)				bRet = Worker_publish.get_data_SRV_PROC_Step(type_name,_Step);
	else if(_type == eVector_sub)			bRet = Worker_subscribe.get_data_SRV_PROC_Step(type_name,_Step);
	else if(_type == eVector_cltService)	bRet = Worker_cltService.get_data_SRV_PROC_Step(type_name,_Step);
	else if(_type == eVector_srvService)	bRet = Worker_srvService.get_data_SRV_PROC_Step(type_name,_Step);

	return bRet ;
}
//-----------------------------------------------------------------------------
//-- get assigned jsonObject   ---------------
bool arduinoUDPBridge::get_jsonObject_Buffer(std::string type_name,eVector_type _type,json &jsonObject,SRV_PROC_Step &_Step) 
{	
	bool bRet = false ;
	int _iter ;
	if(_type == eVector_pub)				bRet = Worker_publish.get_data_jsonObject(type_name,jsonObject,_Step,_iter);  
	else if(_type == eVector_sub)			bRet = Worker_subscribe.get_data_jsonObject(type_name,jsonObject,_Step,_iter);   
	else if(_type == eVector_cltService)	bRet = Worker_cltService.get_data_jsonObject(type_name,jsonObject,_Step,_iter);    
	else if(_type == eVector_srvService)	bRet = Worker_srvService.get_data_jsonObject(type_name,jsonObject,_Step,_iter);  

	return bRet ;	
}
//-----------------------------------------------------------------------------
//-- get assigned jsonObject   ---------------
bool arduinoUDPBridge::modify_jsonObject_Buffer(std::string type_name,eVector_type _type,json jsonObject,SRV_PROC_Step _Step) 
{	
	//ROS_INFO("=== modify_jsonObject_Buffer === ");
	thd::lock_guard<thd::mutex> lock(udpClientRun_mtx);
	
	bool bRet = false ;
	if(_type == eVector_pub)				bRet = Worker_publish.modify_data_jsonObject(type_name,jsonObject,_Step);  
	else if(_type == eVector_sub)			bRet = Worker_subscribe.modify_data_jsonObject(type_name,jsonObject,_Step);   
	else if(_type == eVector_cltService)	bRet = Worker_cltService.modify_data_jsonObject(type_name,jsonObject,_Step);    
	else if(_type == eVector_srvService)	bRet = Worker_srvService.modify_data_jsonObject(type_name,jsonObject,_Step);  

	if(bRet){
		udpClient_thd_pass = true;
		udpClient_cv.notify_one();
	}

	return bRet ;	
}
//-----------------------------------------------------------------------------
//-- udpCheck_PortIsOpened   ---------------
bool arduinoUDPBridge::udpCheck_PortIsOpened() 
{	
	b_portIsOpened = false ;
	try
	{
		bool bClient_Reay = false ;
		bool bServer_Reay = false ;
		udpClient_thd_pass = false;	
		udpServerPtr = std::make_shared<async_comm::UDP>(sever_bind_host, sever_bind_port,sever_remote_host,sever_remote_port);
		udpClientPtr = std::make_shared<async_comm::UDP>(client_bind_host, client_bind_port,client_remote_host,client_remote_port);
		udpServerPtr->register_receive_callback(std::bind(&arduinoUDPBridge::Receive_Data_CB,this,
	                                            std::placeholders::_1,std::placeholders::_2));
		if(!bClient_Reay){
			bClient_Reay = udpClientPtr->init();
		}
		if(!bServer_Reay){
			bServer_Reay = udpServerPtr->init();
		}
		if(bClient_Reay && bServer_Reay){
			b_portIsOpened = true;
		}	
		else
			ros::Duration(0.5).sleep(); 

	}
	catch (const std::exception &e)
	{
		std::cerr << e.what() << " udp_PortIsOpened " << '\n';
	}
	return b_portIsOpened ;
}
//-----------------------------------------------------------------------------
//-- udp_CloseCommPort()   ---------------
void arduinoUDPBridge::udp_CloseCommPort()
{	
	CloseCommPort() ;
}
//-----------------------------------------------------------------------------
void arduinoUDPBridge::showWokerDataStatus(std::string type_name ,eVector_type _type)
{	
	/*if((_type == eVector_pub) || (_type == eVector_sub) ||(_type == eVector_srvService))
		return ;
	
	//--- show buffer size ---
	int counter = get_Buffer_Size(_type) ;
    std::string Worker_type = (_type == eVector_cltService) ? "Worker_cltService " : "Worker_srvService " ;
    std::string tmp_str = Worker_type + "buffer size :"+convert_str(counter);   
    ROS_INFO(tmp_str.c_str());

    if( counter > 0){    
        SRV_PROC_Step _Step ;		
        get_SRV_PROC_Step(type_name,_Step,_type);			
		tmp_str = Worker_type + "current _Step:"+ convert_str(_Step) ;
		if(_Step == eSRV_PROC_Register)	
			tmp_str = tmp_str  + "(eSRV_PROC_Register)"; 
		else if(_Step == eSRV_PROC_Finished)	
			tmp_str = tmp_str  + "(eSRV_PROC_Finished)"; 
		else if(_Step == eSRV_PROC_Send)	
			tmp_str = tmp_str  + "(eSRV_PROC_Send)"; 
		else if(_Step == eSRV_PROC_Recv)	
			tmp_str = tmp_str  + "(eSRV_PROC_Recv)"; 

        ROS_INFO(tmp_str.c_str());	
    }*/
}
//-----------------------------------------------------------------------------
