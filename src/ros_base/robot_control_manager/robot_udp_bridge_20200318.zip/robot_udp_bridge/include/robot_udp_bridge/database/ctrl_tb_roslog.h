#ifndef CTRL_TB_ROSLOG_H
#define CTRL_TB_ROSLOG_H
//----------------------------------------------------------------------------
#include <ros_utility_tools/base_mongodbstore_client.h>
#include <robot_control_msgs/robot_ctrl_roslog.h>
//----------------------------------------------------------------------------
typedef boost::shared_ptr<robot_control_msgs::robot_ctrl_roslog>	ptr_robot_ctrl_roslog ;
typedef std::map<std::string, ptr_robot_ctrl_roslog> _roslog_cmdMap;	
//---------------------------------------------------------------------------
typedef enum {
	roslog_search_none = 0 , roslog_search_level, roslog_search_node, roslog_search_time 
} roslog_search_type ;
//---------------------------------------------------------------------------
typedef enum {
	roslog_level_DEBUG = 0 , roslog_level_INFO, roslog_level_WARN, roslog_level_ERROR,roslog_level_FATAL 
} roslog_level_type ;
//-----------------------------------------------------------------------------
class ctrl_tb_roslog  : public  base_mongodbstore_client
{	
	private:	
		ros::NodeHandle nh_ ;
		std::map<std::string, ptr_robot_ctrl_roslog> indexkey_map ;	//first:alarm_code	second:system_id
		std::multimap<std::string, std::string> searchkey_map ;
		roslog_search_type F_roslog_search_type;
  	public :
		ctrl_tb_roslog(ros::NodeHandle &nh,std::string tablename);	// disable the function of implicit-type cast 
		~ctrl_tb_roslog();
		//------------------------------------------
		//void mapdata_modify(boost::any &_map,boost::any &_data);
		//------------------------------------------
		void indexkey_map_refresh();
		bool _indexdata_insert(const ptr_robot_ctrl_roslog &_data);
		bool _indexdata_modify(const ptr_robot_ctrl_roslog &_data);
		bool _indexdata_update(const ptr_robot_ctrl_roslog &_data);
		bool _indexdata_delete(std::string system_id);
		ptr_robot_ctrl_roslog _indexdata_query(std::string system_id);	
		_roslog_cmdMap _indexdata_multi_query(std::string system_id_L,std::string system_id_U);
		//--------------------------------------------
		void searchkey_map_refresh(roslog_search_type search_type); 
		_roslog_cmdMap _searchkey_map_query(std::string searchkey_L,std::string searchkey_U = "");	
		ptr_robot_ctrl_roslog _searchkey_query(std::string searchkey);				
};
//-----------------------------------------------------------------------------
#endif   
