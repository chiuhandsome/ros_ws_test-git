#ifndef CTRL_TB_ALARMCODE_H
#define CTRL_TB_ALARMCODE_H
//----------------------------------------------------------------------------
#include <ros_utility_tools/base_mongodbstore_client.h>
#include <robot_control_msgs/robot_ctrl_alarmCode.h>
//----------------------------------------------------------------------------
typedef boost::shared_ptr<robot_control_msgs::robot_ctrl_alarmCode>	ptr_robot_ctrl_alarmCode ;
typedef std::map<std::string, ptr_robot_ctrl_alarmCode> _alarmCode_cmdMap;	
//---------------------------------------------------------------------------
typedef enum {
	alarmCode_search_none = 0 , alarmCode_search_level, alarmCode_search_time
} alarmCode_search_type ;
//-----------------------------------------------------------------------------
class ctrl_tb_alarmcode  : public  base_mongodbstore_client
{	
	private:	
		ros::NodeHandle nh_ ;
		std::map<std::string, ptr_robot_ctrl_alarmCode> indexkey_map ;	//first:alarm_code	second:system_id
		std::multimap<std::string, std::string> searchkey_map ;
		alarmCode_search_type F_alarmCode_search_type;
  	public :
		ctrl_tb_alarmcode(ros::NodeHandle &nh,std::string tablename);	// disable the function of implicit-type cast 
		~ctrl_tb_alarmcode();
		//------------------------------------------
		//void mapdata_modify(boost::any &_map,boost::any &_data);
		//------------------------------------------
		void indexkey_map_refresh();
		bool _indexdata_insert(const ptr_robot_ctrl_alarmCode &_data);
		bool _indexdata_modify(const ptr_robot_ctrl_alarmCode &_data);
		bool _indexdata_update(const ptr_robot_ctrl_alarmCode &_data);
		bool _indexdata_delete(std::string alarm_code);
		ptr_robot_ctrl_alarmCode _indexdata_query(std::string alarm_code);	
		_alarmCode_cmdMap _indexdata_multi_query(std::string alarm_code_L,std::string alarm_code_U);
		//--------------------------------------------
		void searchkey_map_refresh(alarmCode_search_type search_type); 
		_alarmCode_cmdMap _searchkey_map_query(std::string searchkey_L,std::string searchkey_U = "");	
		ptr_robot_ctrl_alarmCode _searchkey_query(std::string searchkey);				
};
//-----------------------------------------------------------------------------
#endif   
