#ifndef UDPWORKERDATA_H
#define UDPWORKERDATA_H
//----------------------------------------------------------------------------
#include <ros/ros.h>
#include <string>
#include <regex>
#include <math.h>
#include <mutex>
#include <nlohmann/json.hpp>
#include <range/v3/all.hpp>
#include <vector>
#include <ros_utility_tools/ros_tools.h>

#define usingThread_STD		true
#define usingThread_Boost	false
#if(usingThread_STD)
	#include <thread>
    namespace thd = std;
#elif(usingThread_Boost)
	#include <boost/thread.hpp>
    namespace thd = boost;
#endif
#define usingFindJson_STD	false


using namespace std;
using json = nlohmann::json;
//----------------------------------------------------------------------------
typedef enum {
	S_IDLE,S_INIT,S_RESET,S_PARAM,S_PARAM_SUCCESS,S_PARAM_RUNNING,S_SYNCH,
	S_SYNCH_SUCCESS,S_SYNCH_FAIL,S_START_READ_DATA,S_READ_DATA_RUNNING,S_DATA
} Comm_Status ;
typedef enum {
	eVector_pub = 0, eVector_sub, eVector_cltService,eVector_srvService
} eVector_type ;
typedef enum{
    eSRV_PROC_Register = 0, eSRV_PROC_Finished = 1, eSRV_PROC_Send = 2, eSRV_PROC_Recv = 3    
}SRV_PROC_Step;
//----------------------------------------------------------------------------
class UDPWorkerData
{
	private:
		std::vector<json> Worker_Buffer ;
		std::vector<int> Worker_status_Buffer ;
		eVector_type act_Buffer_type ; 	

		thd::mutex lockMutex;
		bool is_josonObjExist(json jsonObject);
		bool is_SRV_PROC_StepExist(int _step);
		std::string find_main_type ;
		std::string find_type_name ;
		SRV_PROC_Step find_PROC_Step ;
		//eVector_type find_type ;	

		bool find_josonObjData(); 
		
		int result_iter ;
		json result_jsonObject ;
		SRV_PROC_Step result_Step ;
	public:
		UDPWorkerData(eVector_type _Buffer_type); 
		~UDPWorkerData();

		bool find_SRV_PROC_Step(SRV_PROC_Step _PROC_Step); 
		json get_result_jsonObject(int &_result_iter);
		//void UDPWorkerData_InitSet(shared_ptr<async_comm::UDP> _udpClientPtr) ;
		void add_data_jsonObject(json jsonObject) ;
		void modify_data_jsonObject(int iter,SRV_PROC_Step _Step) ;
		void modify_data_jsonObject(int iter,json jsonObject,SRV_PROC_Step _Step) ;
		bool modify_data_jsonObject(std::string type_name,SRV_PROC_Step _Step) ;
		bool modify_data_jsonObject(std::string type_name,json jsonObject,SRV_PROC_Step _Step) ;
		void erase_data_jsonObject(int iter);
		void erase_data_jsonObject(std::string type_name);
		bool swap_data_jsonObject(int iter1,int iter2) ;
		bool swap_data_jsonObject(std::string type_name_1,std::string type_name_2) ;
		bool get_data_jsonObject(std::string type_name,json &jsonObject,SRV_PROC_Step &_Step,int &_iter) ;
		bool get_data_jsonObject(int iter,json &jsonObject,SRV_PROC_Step &_Step) ;
		bool get_data_SRV_PROC_Step(std::string type_name,SRV_PROC_Step &_Step);
		int  get_data_size() ;
};
//-----------------------------------------------------------------------------
#endif   
