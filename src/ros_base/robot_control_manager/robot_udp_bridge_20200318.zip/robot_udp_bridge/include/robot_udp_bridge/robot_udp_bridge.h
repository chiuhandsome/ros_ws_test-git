#ifndef CRLTMESSAGEMANAGER_H
#define CRLTMESSAGEMANAGER_H

#define using_msgTest_unit		false
//-----------------------------------------------------------------------------
#include <robot_udp_bridge/crltMessageInterface.h>
#if(using_msgTest_unit)
	#include <robot_udp_bridge/crlt_message_testunit.h>
#endif

//-----------------------------------------------------------------------------
class robot_udp_bridge    
{
	private:
	   	ros::NodeHandle nh_ ;
	   	crltMessageInterface crlt_msg_Interface ;	
		void Load_CntParameter();
		#if(using_msgTest_unit)   
			crlt_message_testunit* crlt_msg_testunit ;  
		#endif
	public:
	   robot_udp_bridge(ros::NodeHandle& nh);
	   ~robot_udp_bridge();

	   int udp_PORT_OPEN_RETRY ;

	   bool udpCheck_PortIsOpened();
	   void udp_CloseCommPort() ;
	   void robot_udp_bridge_Start();
};
//-----------------------------------------------------------------------------
#endif
