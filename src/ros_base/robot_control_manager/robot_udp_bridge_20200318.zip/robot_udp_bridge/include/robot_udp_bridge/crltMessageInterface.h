#ifndef CRLTMESSAGEINTERFACE_H
#define CRLTMESSAGEINTERFACE_H
//----------------------------------------------------------------------------
#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
//#include <lino_msgs/PID.h>
//#include <lino_msgs/Velocities.h>
#include <robot_control_msgs/PID.h>
#include <robot_control_msgs/Velocities.h>
#include <robot_control_msgs/hyc_heartbeat.h>
#include <botcmd_msgs/bot_devicestatus.h>
#include <botcmd_msgs/bot_do_cmd.h>
#include <botcmd_msgs/bot_transfer_cmd.h>
#include <botcmd_msgs/bot_ultrasonic_cmd.h>
#include <botcmd_msgs/bot_battery_cmd.h>
#include <botcmd_msgs/bot_battery_info_cmd.h>
#include <botcmd_msgs/bot_status_cmd.h>
#include <std_msgs/String.h>
#include <samsungcmd_msgs/samsung_cntparamsdata.h>
#include <robot_udp_bridge/arduinoUDPBridge.h>
//-----------------------------------------------------------------------------
class crltMessageInterface
{	
	private:	
		ros::NodeHandle nh_ ;
		void Load_CntParameter();
		//bool wait_buffer_SRV_PROC_Step(std::string main_type,std::string type_name,eVector_type _type,int &iter_No,
		//                               json &resultObject,SRV_PROC_Step &_Step);
		//----------------------------------------------------
		arduinoUDPBridge 	udpBridge ;
		bool				crltMessage_destory; 
		bool				crltMessage_start; 		

		bool bDebug_Show ;
		//-- main thread for crltMessageInterface  --
		//std::unique_ptr<thd::thread> 	main_threads;
		//thd::mutex 						main_mutex;
		//thd::condition_variable 		main_condition_variable;		
		//-- thread for publish the ros' subscribe data (source come from stm-Pub_Queue)  --
		std::unique_ptr<thd::thread> 	sub_received_threads;
		thd::mutex 						sub_received_mtx;
		thd::condition_variable 		sub_received_cv;		
		void sub_received_threadEntry();
		void sub_received_threadClose();
		void sub_received_call();

		//-- thread for waiting response-result of the ros' server service (source come from stm-serverService_Queue)  --
		std::unique_ptr<thd::thread>	cltservice_recv_thread;
		thd::condition_variable       	cltservice_recv_cv;
		thd::mutex                    	cltservice_recv_mtx;
		void cltservice_recv_threadEntry();
		bool cltservice_recv_Check();
		//-- waiting response's finished status from callback function of each ros' server-service ---
		thd::condition_variable       	cltservice_send_cv;
		thd::mutex                    	cltservice_send_mtx;			
		bool set_cltservice_send_proc(std::string srvService_name,json &jsonObj);
		//-- control parameters of ros's client service ---
		bool b_ledbar_set, b_ledbar_finish  ;
		bool b_music_set, b_music_finish  ;
		bool b_download_set, b_download_finish  ;
		bool b_ultrasonic_set, b_ultrasonic_finish  ;
		bool b_battery_set, b_battery_finish  ;
		bool b_battery_info_set, b_battery_info_finish  ;	//20200317 Add
		bool b_reader_set, b_reader_finish  ;
		bool b_ssr_set, b_ssr_finish  ;
		bool b_imu_set, b_imu_finish  ;
		bool b_SetFunction_set, b_SetFunction_finish  ;
		bool b_io_set, b_io_finish  ;
		bool b_laserarea_set, b_laserarea_finish  ;
		bool b_motor1_set, b_motor1_finish  ;
		bool b_motor2_set, b_motor2_finish  ;
		bool b_motor3_set, b_motor3_finish  ;
		bool b_motor4_set, b_motor4_finish  ;
		//-- multi-thread for waiting reqests of stm's clientservice (ros' server service) (source come from stm-clientService_Queue)  --
		std::unique_ptr<thd::thread> srvservice_recv_threads;//[1];//[2];	//for Synchronize request
		thd::mutex srvservice_recv_mtx;
		thd::condition_variable srvservice_recv_cv;
		
		void srvservice_recv_threadEntry(std::string cltService_name);
		void srvservice_recv_threadClose();
		void srvservice_recv_call(std::string cltService_name);		
		//--------------------------------------------------
		//-- subscriber for upper level - subscribe from ROS's publisher  --
		ros::Subscriber sub_cmd_vel ;
		std::string sub_cmd_vel_name;
		int sub_cmd_vel_queue ;
		void sub_cmd_vel_CB(const geometry_msgs::Twist& cmd_msg);
		
		ros::Subscriber sub_pid ;
		std::string sub_pid_name;
		int sub_pid_queue ;
		//void sub_pid_CB(const lino_msgs::PID& pid_msg);
		void sub_pid_CB(const robot_control_msgs::PID& pid_msg);
		//-- publish to ROS from subscribe_Buffer --
		ros::Publisher pub_raw_velocity ;
		std::string pub_raw_velocity_name ;
		int pub_raw_velocity_queue ;
		//lino_msgs::Velocities raw_velocity_msg;
		robot_control_msgs::Velocities raw_velocity_msg;
		void pub_raw_vel_topic(json jsonObj);

		ros::Publisher pub_raw_megguider ;
		std::string pub_raw_megguider_name ;
		int pub_raw_megguider_queue ;
		samsungcmd_msgs::samsung_cntparamsdata raw_megguider_msg;
		void pub_raw_megguider_topic(json jsonObj);

		ros::Publisher pub_raw_magnav ;
		std::string pub_raw_magnav_name ;
		int pub_raw_magnav_queue ;
		samsungcmd_msgs::samsung_cntparamsdata raw_magnav_msg;
		void pub_raw_magnav_topic(json jsonObj);

		ros::Publisher pub_raw_reader ;
		std::string pub_raw_reader_name ;
		int pub_raw_reader_queue ;
		botcmd_msgs::bot_devicestatus raw_reader_msg;
		void pub_raw_reader_topic(json jsonObj);

		ros::Publisher pub_stmudp_heartbeat ;
		std::string pub_stmudp_heartbeat_name ;
		int pub_stmudp_heartbeat_queue ;
		robot_control_msgs::hyc_heartbeat raw_heartbeat_msg;
		void pub_stmudp_heartbeat_topic(json jsonObj);

		ros::Publisher pub_raw_sick ;
		std::string pub_raw_sick_name ;
		int pub_raw_sick_queue ;
		std_msgs::String raw_sick_msg;
		void pub_raw_sick_topic(json jsonObj);

		//-- serverService for upper level - from ROS's clientService  --
		ros::ServiceServer bot_ledbar_srvService ;
		std::string bot_ledbar_srvService_name ;
		bool srv_Eval_bot_ledbar(botcmd_msgs::bot_do_cmd::Request  &req,
								 botcmd_msgs::bot_do_cmd::Response &resp);

		ros::ServiceServer bot_music_srvService ;
		std::string bot_music_srvService_name ;
		bool srv_Eval_bot_music(botcmd_msgs::bot_do_cmd::Request  &req,
								botcmd_msgs::bot_do_cmd::Response &resp);

		ros::ServiceServer bot_download_srvService ;
		std::string bot_download_srvService_name ;
		bool srv_Eval_bot_download(botcmd_msgs::bot_transfer_cmd::Request  &req,
								   botcmd_msgs::bot_transfer_cmd::Response &resp);

		ros::ServiceServer bot_ultrasonic_srvService ;
		std::string bot_ultrasonic_srvService_name ;
		bool srv_Eval_bot_ultrasonic(botcmd_msgs::bot_ultrasonic_cmd::Request  &req,
								     botcmd_msgs::bot_ultrasonic_cmd::Response &resp);

		ros::ServiceServer bot_battery_srvService ;
		std::string bot_battery_srvService_name ;
		bool srv_Eval_bot_battery(botcmd_msgs::bot_battery_cmd::Request  &req,
								  botcmd_msgs::bot_battery_cmd::Response &resp);

		ros::ServiceServer bot_battery_info_srvService ;	//20200317 Add
		std::string bot_battery_info_srvService_name ;
		bool srv_Eval_bot_battery_info(botcmd_msgs::bot_battery_info_cmd::Request  &req,
								       botcmd_msgs::bot_battery_info_cmd::Response &resp);

		ros::ServiceServer bot_reader_status_srvService ;
		std::string bot_reader_status_srvService_name ;
		bool srv_Eval_bot_reader_status(botcmd_msgs::bot_status_cmd::Request  &req,
								        botcmd_msgs::bot_status_cmd::Response &resp);

		ros::ServiceServer bot_ssr_srvService ;
		std::string bot_ssr_srvService_name ;
		bool srv_Eval_bot_ssr(botcmd_msgs::bot_do_cmd::Request  &req,
							  botcmd_msgs::bot_do_cmd::Response &resp);

		ros::ServiceServer bot_imu_srvService ;
		std::string bot_imu_srvService_name ;
		bool srv_Eval_bot_imu(botcmd_msgs::bot_do_cmd::Request  &req,
							  botcmd_msgs::bot_do_cmd::Response &resp);

		ros::ServiceServer bot_SetFunction_srvService ;
		std::string bot_SetFunction_srvService_name ;
		bool srv_Eval_bot_SetFunction(botcmd_msgs::bot_do_cmd::Request  &req,
							          botcmd_msgs::bot_do_cmd::Response &resp);

		ros::ServiceServer bot_io_srvService ;
		std::string bot_io_srvService_name ;
		bool srv_Eval_bot_io(botcmd_msgs::bot_do_cmd::Request  &req,
							  botcmd_msgs::bot_do_cmd::Response &resp);

		ros::ServiceServer bot_laserarea_srvService ;
		std::string bot_laserarea_srvService_name ;
		bool srv_Eval_bot_laserarea(botcmd_msgs::bot_do_cmd::Request  &req,
							  botcmd_msgs::bot_do_cmd::Response &resp);

		ros::ServiceServer bot_motor1_srvService ;
		std::string bot_motor1_srvService_name ;
		bool srv_Eval_bot_motor1(botcmd_msgs::bot_status_cmd::Request  &req,
								 botcmd_msgs::bot_status_cmd::Response &resp);

		ros::ServiceServer bot_motor2_srvService ;
		std::string bot_motor2_srvService_name ;
		bool srv_Eval_bot_motor2(botcmd_msgs::bot_status_cmd::Request  &req,
								 botcmd_msgs::bot_status_cmd::Response &resp);

		ros::ServiceServer bot_motor3_srvService ;
		std::string bot_motor3_srvService_name ;
		bool srv_Eval_bot_motor3(botcmd_msgs::bot_status_cmd::Request  &req,
								 botcmd_msgs::bot_status_cmd::Response &resp);

		ros::ServiceServer bot_motor4_srvService ;
		std::string bot_motor4_srvService_name ;
		bool srv_Eval_bot_motor4(botcmd_msgs::bot_status_cmd::Request  &req,
								 botcmd_msgs::bot_status_cmd::Response &resp);

		//-- clientService for upper level - to ROS's serverService  --
		ros::ServiceServer bot_Upload_srvService ;
		bool srv_Eval_bot_Upload(botcmd_msgs::bot_transfer_cmd::Request  &req,
								 botcmd_msgs::bot_transfer_cmd::Response &resp);
		botcmd_msgs::bot_transfer_cmd bot_Upload_cmd_data ;
		ros::ServiceClient bot_Upload_cltService ;
		std::string bot_Upload_cltService_name ;
		bool b_Upload_finish  ;
		int Upload_test_counter ;
		bool bManual_test ;

		/*ros::ServiceServer bot_sysstatus_srvService ;
		bool srv_Eval_bot_sysstatus(botcmd_msgs::bot_do_cmd::Request  &req,
								    botcmd_msgs::bot_do_cmd::Response &resp);
		botcmd_msgs::bot_do_cmd bot_sysstatus_cmd_data ;
		ros::ServiceClient bot_sysstatus_cltService ;
		std::string bot_sysstatus_cltService_name ;
		bool b_sysstatus_finish  ;*/
		//----
		//int pre_vel_heartbeat_id , pre_pid_heartbeat_id ;
		int pre_heartbeat_id ;
		bool stm_heartbeat_check()  ;
		double call_service_timeout ;	//unit : sec
		ros::Time call_led_base_time ; bool b_call_led_timeout ;
		ros::Time call_music_base_time ; bool b_call_music_timeout ;
		ros::Time call_download_base_time ; bool b_call_download_timeout ;
		ros::Time call_ultrasonic_base_time ; bool b_call_ultrasonic_timeout ;
		ros::Time call_battery_base_time ; bool b_call_battery_timeout ;
		//-- 20200317 Add ---
		ros::Time call_battery_info_base_time ; bool b_call_battery_info_timeout ;
		//--------------------
		ros::Time call_reader_base_time ; bool b_call_reader_timeout ;
		ros::Time call_ssr_base_time ; bool b_call_ssr_timeout ;
		ros::Time call_imu_base_time ; bool b_call_imu_timeout ;
		ros::Time call_SetFunction_base_time ; bool b_call_SetFunction_timeout ;
		ros::Time call_io_base_time ; bool b_call_io_timeout ;
		ros::Time call_laserarea_base_time ; bool b_call_laserarea_timeout ;
		ros::Time call_motor1_base_time ; bool b_call_motor1_timeout ;
		ros::Time call_motor2_base_time ; bool b_call_motor2_timeout ;
		ros::Time call_motor3_base_time ; bool b_call_motor3_timeout ;
		ros::Time call_motor4_base_time ; bool b_call_motor4_timeout ;
		bool call_service_timeout_check(std::string type_name)  ;

		json json_srv_recv_call ;
  	public :
		crltMessageInterface(ros::NodeHandle &nh);	// disable the function of implicit-type cast 
		~crltMessageInterface();
		//------------------------------------------
		void crltMessage_start_set(bool bSet);
		int  get_Buffer_Size(eVector_type _type) ;
		bool udpCheck_PortIsOpened();
		void udp_CloseCommPort() ;
		robot_control_msgs::hyc_heartbeat get_raw_heartbeat_msg();

		void bManual_test_set(bool btest);
};
//-----------------------------------------------------------------------------
#endif   
