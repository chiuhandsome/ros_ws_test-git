#ifndef CRLTMESSAGETESTUNIT_H
#define CRLTMESSAGETESTUNIT_H
//-----------------------------------------------------------------------------
#include <robot_udp_bridge/crltMessageInterface.h>
//-----------------------------------------------------------------------------
class crlt_message_testunit    
{
	private:
	   	ros::NodeHandle nh_ ;
	   	//-- for tets ---
	   	//bool bUDPTestFlag ;
	   	//-- publish cmd_vel --
		double controller_frequency_ { 40.0 };
	   	ros::Duration desired_control_duration_;
  		ros::Timer control_loop_timer_;
		void controlLoopCallback(const ros::TimerEvent& event);

		ros::Publisher pubROS_cmd_vel ;
		std::string pubROS_cmd_vel_name ;
		int pubROS_cmd_vel_queue ;
		geometry_msgs::Twist cmd_vel_msg ;
		void pubROS_cmd_vel_topic();
		int test_counter ;

		ros::Publisher pubROS_cmd_pid ;
		std::string pubROS_cmd_pid_name ;
		int pubROS_cmd_pid_queue ;
		robot_control_msgs::PID cmd_pid_msg ;
		void pubROS_cmd_pid_topic();
		int test_counter_1 ;

		ros::Time begin_Time ;

	public:
	   crlt_message_testunit(ros::NodeHandle& nh);
	   ~crlt_message_testunit();
	   //--------
	   void message_testunit_start();
	   void message_testunit_stop();
};
//-----------------------------------------------------------------------------
#endif
