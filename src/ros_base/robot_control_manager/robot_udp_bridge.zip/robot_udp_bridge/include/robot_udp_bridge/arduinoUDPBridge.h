#ifndef ARDUINOUDPBRIDGE_H
#define ARDUINOUDPBRIDGE_H
//----------------------------------------------------------------------------
#include <async_comm/udp.h>
#include <boost/thread.hpp>
#include <condition_variable>
#include <mutex>
#include <robot_udp_bridge/UDPWorkerData.h>

#define usingThread_STD		true
#define usingThread_Boost	false
#if(usingThread_STD)
	#include <thread>
    namespace thd = std;
#elif(usingThread_Boost)
	#include <boost/thread.hpp>
    namespace thd = boost;
#endif
//-----------------------------------------------------------------------------
class arduinoUDPBridge
{	
	private:
		ros::NodeHandle nh_ ;
		void Load_CntParameter();
		//-- UDP's parameters for communication -------
		std::string sever_bind_host ;	//= "192.168.11.194"  ; 
		int sever_bind_port ;			//= 14620  ;
		std::string sever_remote_host ;	//= "192.168.11.177";
		int sever_remote_port ;			//= 14625 ;

		std::string client_bind_host ;	//= "192.168.11.194"  ; 
		int client_bind_port ;			//= 14425  ;
		std::string client_remote_host ;//= "192.168.11.177";
		int client_remote_port ;		//= 14420 ; 
		shared_ptr<async_comm::UDP> udpServerPtr ;
   		shared_ptr<async_comm::UDP> udpClientPtr ;	
		//-- UDPWorkerData clare for publish,subscribe,clientservice,serverservice 
		UDPWorkerData Worker_publish ;
		UDPWorkerData Worker_subscribe ;
		UDPWorkerData Worker_cltService ;
		UDPWorkerData Worker_srvService ;
		//-- function declare of udpServer ----
		void Receive_Data_CB(const uint8_t *buf, size_t len);	
		//-- function declare of udpClient ----	
		std::unique_ptr<thd::thread>	udpClient_thread;
		thd::condition_variable       	udpClient_cv;
		thd::mutex                    	udpClient_mtx;
		bool	                        udpClient_thd_destory; 
		bool 							udpClient_thd_pass; 
		int _sleep_period ;

		thd::mutex                    	udpClientRun_mtx;
		void udpClient_ThreadEntry() ;
		void udpClient_SendData() ;
		bool udpClient_SendData_Action();
		int  udp_result_iter ;
		json udp_result_json ;
		//-- Send ----
		void publish_Buffer_Send() ;
		bool clientService_Buffer_Send() ;	//-- eSRV_PROC_Register(0)->eSRV_PROC_Send(2)
		bool serverService_Buffer_Send() ;	//-- eSRV_PROC_Recv(3)->erase
		//-- Receive -----
		bool serverService_Response(json jsonObject) ;	

			
  	public:
		//explicit ActionController(ros::NodeHandle& _nh);	// disable the function of implicit-type cast 
		arduinoUDPBridge(ros::NodeHandle &nh);	// disable the function of implicit-type cast 
		~arduinoUDPBridge();
		//------------------------------------------------- 
		bool udpServer_PortIsOpened() ;
		bool udpClient_PortIsOpened() ;
		void CloseCommPort() ;
		//bool udp_PortIsOpened(shared_ptr<async_comm::UDP> udp_Ptr,std::string udp_port = "") ;
		int udp_PORT_OPEN_RETRY ;
		bool b_portIsOpened ;
		//void port_Send_Data() ;

		//void find_Receive_Buffer(std::string topicname) ;
		//-------------------------------------------------- 
		bool add_jsonObject_Buffer(json jsonObject,eVector_type _type) ;

		bool erase_jsonObject_Buffer(int iter,eVector_type _type) ;
		bool erase_jsonObject_Buffer(std::string type_name,eVector_type _type) ;
		//bool swap_jsonObject_Buffer(int iter1,int iter2,eVector_type _type) ;
		bool get_jsonObject_Buffer(int iter,eVector_type _type,json &jsonObject,SRV_PROC_Step &_Step) ;
		int  get_Buffer_Size(eVector_type _type) ;
		//bool get_FindValue_Buffer(std::string main_type,std::string type_name,eVector_type _type,int &iter_No,
		//                          json &resultObject,SRV_PROC_Step &_Step) ;	
		bool get_SRV_PROC_Step(std::string type_name,SRV_PROC_Step &_Step,eVector_type _type);	
		bool get_jsonObject_Buffer(std::string type_name,eVector_type _type,json &jsonObject,SRV_PROC_Step &_Step) ;
		bool modify_jsonObject_Buffer(std::string type_name,eVector_type _type,json jsonObject,SRV_PROC_Step _Step) ;
		bool udpCheck_PortIsOpened();
		void udp_CloseCommPort() ;

		void showWokerDataStatus(std::string type_name ,eVector_type _type);	
};
//-----------------------------------------------------------------------------
#endif   
