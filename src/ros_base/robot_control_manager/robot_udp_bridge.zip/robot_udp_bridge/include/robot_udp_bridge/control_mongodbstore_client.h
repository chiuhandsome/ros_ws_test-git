#ifndef CONTROL_MONGODBSTORE_CLIENT_H
#define CONTROL_MONGODBSTORE_CLIENT_H
//----------------------------------------------------------------------------
#include <robot_udp_bridge/database/ctrl_tb_alarmcode.h>
#include <robot_udp_bridge/database/ctrl_tb_alarmhistory.h>
#include <robot_udp_bridge/database/ctrl_tb_roslog.h>
#include <robot_control_msgs/robot_ctrl_alarmCode_cmd.h>
#include <robot_control_msgs/robot_ctrl_alarmHistory_cmd.h>
#include <robot_control_msgs/robot_ctrl_roslog_cmd.h>
//----------------------------------------------------------------------------
typedef enum {
	car_tbedit_none = 0 , car_tbedit_add, car_tbedit_modify, car_tbedit_delete, car_tbedit_query
} car_tbedit_type ;
//----------------------------------------------------------------------------
class control_mongodbstore_client 
{
	private:
		ros::NodeHandle nh_ ;
		//-------------------------
		ctrl_tb_alarmcode act_ctrl_tb_alarmcode ;
		ctrl_tb_alarmhistory act_ctrl_tb_alarmhistory ;
		ctrl_tb_roslog act_ctrl_tb_roslog ;	
		//-------------------------
		ros::ServiceServer tb_srvservice_alarmcode ;
		std::string tb_srvservice_alarmcode_name ;
		bool srv_Eval_tb_srvservice_alarmcode(robot_control_msgs::robot_ctrl_alarmCode_cmd::Request  &req,
								              robot_control_msgs::robot_ctrl_alarmCode_cmd::Response &resp);
		alarmCode_search_type F_alarmCode_search_type ;
		alarmCode_search_type find_alarmCode_search_type(std::string search_type);

		ros::ServiceServer tb_srvservice_alarmhistory ;
		std::string tb_srvservice_alarmhistory_name ;
		bool srv_Eval_tb_srvservice_alarmhistory(robot_control_msgs::robot_ctrl_alarmHistory_cmd::Request  &req,
								                 robot_control_msgs::robot_ctrl_alarmHistory_cmd::Response &resp);
		alarmHistory_search_type F_alarmHistory_search_type ;
		alarmHistory_search_type find_alarmHistory_search_type(std::string search_type);

		ros::ServiceServer tb_srvservice_log ;
		std::string tb_srvservice_log_name ;
		bool srv_Eval_tb_srvservice_log(robot_control_msgs::robot_ctrl_roslog_cmd::Request  &req,
								        robot_control_msgs::robot_ctrl_roslog_cmd::Response &resp);
		roslog_search_type F_roslog_search_type ;
		roslog_search_type find_roslog_search_type(std::string search_type);							  
		
	protected:
	public:
		control_mongodbstore_client(ros::NodeHandle &nh,
                             std::string tbname_alarmcode,std::string tbname_alarmhistory,
                             std::string tbname_roslog);	 
		~control_mongodbstore_client();	
};
//-----------------------------------------------------------------------------
#endif   
