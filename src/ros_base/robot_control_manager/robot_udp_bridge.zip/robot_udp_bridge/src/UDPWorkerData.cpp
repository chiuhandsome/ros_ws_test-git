#include <robot_udp_bridge/UDPWorkerData.h>
//*****************************************************************************
//-----------------------------------------------------------------------------
//-- UDPWorkerData constructor  -----
UDPWorkerData::UDPWorkerData(eVector_type _Buffer_type) //: act_Buffer_type(_Buffer_type)
{
	act_Buffer_type = _Buffer_type ; 
	//ROS_INFO("UDPWorkerData");
	//std::string aa = convert_str(act_Buffer_type); 
	//ROS_INFO(aa.c_str());
}
//-----------------------------------------------------------------------------
//-- UDPWorkerData de-constructor ---------------
UDPWorkerData::~UDPWorkerData() 
{
	
}
//-----------------------------------------------------------------------------
//-- add a jsonObject to publish_Buffer from back ---------------
void UDPWorkerData::add_data_jsonObject(json jsonObject)
{
	////-- lock queueMutex --- 
	thd::lock_guard<thd::mutex> lock(lockMutex);
	//-- push data ----
	if(act_Buffer_type == eVector_srvService){
		if(get_data_size() == 0){
			//ROS_INFO("=== Add ====="); 
			//ROS_INFO(jsonObject.dump().c_str()); 
			Worker_Buffer.push_back(jsonObject);
			Worker_status_Buffer.push_back((int)eSRV_PROC_Register);
			thd::this_thread::sleep_for(std::chrono::milliseconds(1)); 
		}
	}
	else{
		Worker_Buffer.push_back(jsonObject);
		Worker_status_Buffer.push_back((int)eSRV_PROC_Register);
	}
}
//-----------------------------------------------------------------------------
//-- modify a jsonObject data  ---------------
void UDPWorkerData::modify_data_jsonObject(int iter,SRV_PROC_Step _Step)
{
	//-- lock queueMutex --- 
	thd::lock_guard<thd::mutex> lock(lockMutex);
	//-- push data ----
	if(iter < Worker_Buffer.size()){
		vector<int>::iterator it = Worker_status_Buffer.begin() + iter; 
		*it = (int)_Step ;
	}
}
//-----------------------------------------------------------------------------
//-- modify a jsonObject data and its proc_step ---------------
void UDPWorkerData::modify_data_jsonObject(int iter,json jsonObject,SRV_PROC_Step _Step)
{
	//-- lock queueMutex --- 
	thd::lock_guard<thd::mutex> lock(lockMutex);
	//-- push data ----
	//std::string tmp = "size:"+convert_str(Worker_Buffer.size());
	//ROS_INFO(tmp.c_str());
	//tmp = "iter:"+convert_str(iter);
	//ROS_INFO(tmp.c_str());
	if(iter < Worker_Buffer.size()){
		vector<json>::iterator it = Worker_Buffer.begin() + iter; 
		*it = jsonObject ;	

		vector<int>::iterator _it1 = Worker_status_Buffer.begin() + iter; 
		*_it1 = (int)_Step ;
	}
}
//-----------------------------------------------------------------------------
//-- main modify a jsonObject proc_step ---------------
bool UDPWorkerData::modify_data_jsonObject(std::string type_name,SRV_PROC_Step _Step)
{
	//-- lock queueMutex --- 
	//thd::lock_guard<thd::mutex> lock(lockMutex);

	if((act_Buffer_type == eVector_pub) || (act_Buffer_type == eVector_sub))
		find_main_type = "topic" ;	
	else if(act_Buffer_type == eVector_cltService) 
		find_main_type = "ros_service" ;
	else if(act_Buffer_type == eVector_srvService)
		find_main_type = "carcnt_service" ;

	find_type_name = type_name ;
	bool bRet = (find_josonObjData()) ;
	if(bRet){
		modify_data_jsonObject(result_iter,_Step);	
	}
	return bRet ;
}
//-----------------------------------------------------------------------------
//-- modify a jsonObject data and its proc_step ---------------
bool UDPWorkerData::modify_data_jsonObject(std::string type_name,json jsonObject,SRV_PROC_Step _Step)
{
	//-- lock queueMutex --- 
	//thd::lock_guard<thd::mutex> lock(lockMutex);

	if((act_Buffer_type == eVector_pub) || (act_Buffer_type == eVector_sub))
		find_main_type = "topic" ;	
	else if(act_Buffer_type == eVector_cltService) 
		find_main_type = "ros_service" ;
	else if(act_Buffer_type == eVector_srvService)
		find_main_type = "carcnt_service" ;

	find_type_name = type_name ;
	bool bRet = (find_josonObjData()) ;
	if(bRet){
		modify_data_jsonObject(result_iter,jsonObject,_Step);	
	}
	return bRet ;
}
//-----------------------------------------------------------------------------
//-- erase a assigned jsonObject   ---------------
void UDPWorkerData::erase_data_jsonObject(int iter)
{
	//-- lock queueMutex --- 
	thd::lock_guard<thd::mutex> lock(lockMutex);
	//-- erase data ----
	int isize = Worker_Buffer.size() ; 
	bool bRet = (iter < isize);
	if(bRet){
		vector<json>::iterator it = Worker_Buffer.begin() + iter; 
		Worker_Buffer.erase(it);
		vector<int>::iterator it1 = Worker_status_Buffer.begin() + iter; 
		Worker_status_Buffer.erase(it1);
		//if(act_Buffer_type == eVector_srvService)
		//	ROS_INFO("=== delete ====="); 
	}	
}
//-----------------------------------------------------------------------------
//-- get assigned jsonObject   ---------------
bool UDPWorkerData::is_josonObjExist(json jsonObject)
{	
	/*ROS_INFO("< ====== is_josonObjExist ============ >");
	ROS_INFO(jsonObject.dump().c_str());
	std::string tmp = "main_type:" + convert_str(jsonObject["main_type"]) + " / " + find_main_type ;
	ROS_INFO(tmp.c_str());	
	*/
	bool _result = (jsonObject["main_type"] == find_main_type) ;
	if(_result){
		if((act_Buffer_type == eVector_pub) || (act_Buffer_type == eVector_sub))
			_result = (jsonObject["topic_name"] == find_type_name);	
		else if((act_Buffer_type == eVector_cltService) || (act_Buffer_type == eVector_srvService))
			_result = (jsonObject["service_name"] == find_type_name);	
	}
	return _result; 
}
//-----------------------------------------------------------------------------
//-- get assigned jsonObject   ---------------
bool UDPWorkerData::is_SRV_PROC_StepExist(int _step)
{
	bool _result = (_step == find_PROC_Step) ;
	return _result; 
}
//-----------------------------------------------------------------------------
//-- get assigned jsonObject   ---------------
bool UDPWorkerData::find_josonObjData()//(std::string main_type,std::string type_name)
{
	std::vector<json>::iterator it ;
	#if(usingFindJson_STD)
		it = ranges::find_if(Worker_Buffer, std::bind(&WorkerThread::is_josonObjExist,this,std::placeholders::_1));	
	#else
		it = std::find_if (Worker_Buffer.begin(), Worker_Buffer.end(), std::bind(&UDPWorkerData::is_josonObjExist,this,std::placeholders::_1));	
	#endif
	
	bool bRet = (it != Worker_Buffer.end());

	//ROS_INFO("< ================== >");
	//std::string tmp = "worker_buffer size:" + convert_str(Worker_Buffer.size()) + " /is_josonObjExist result:" + convert_str(bRet) ;
	//ROS_INFO(tmp.c_str());
	if(bRet){		
		//tmp = "main_type:" + find_main_type + "  / find_type_name:" + find_type_name;
		//ROS_INFO(tmp.c_str());


		result_jsonObject = *it ;
		//ROS_INFO(result_jsonObject.dump().c_str());
		int distance = std::distance(Worker_Buffer.begin(), it);
		std::vector<int>::iterator _it = Worker_status_Buffer.begin() + distance ;
		result_Step = (SRV_PROC_Step)*_it ;
		result_iter = distance ;
	}

	return true ;		
}
//-----------------------------------------------------------------------------
//-- get assigned jsonObject   ---------------
bool UDPWorkerData::find_SRV_PROC_Step(SRV_PROC_Step _PROC_Step)
{
	find_PROC_Step = _PROC_Step ;
	
	std::vector<int>::iterator it ;
	#if(usingFindJson_STD)
		it = ranges::find_if(Worker_status_Buffer, std::bind(&UDPWorkerData::is_SRV_PROC_StepExist,this,std::placeholders::_1));	
	#else
		it = std::find_if (Worker_status_Buffer.begin(), Worker_status_Buffer.end(), std::bind(&UDPWorkerData::is_SRV_PROC_StepExist,this,std::placeholders::_1));	
	#endif
	
	bool bRet = (it != Worker_status_Buffer.end());
	if(bRet){
		result_Step = (SRV_PROC_Step)*it ;
		int distance = std::distance(Worker_status_Buffer.begin(), it);
		std::vector<json>::iterator _it = Worker_Buffer.begin() + distance ;
		result_jsonObject = *_it ;
		result_iter = distance ;
	}
	return bRet ;		
	//return true ;		
}
//-----------------------------------------------------------------------------
//-- erase a assigned jsonObject   ---------------
void UDPWorkerData::erase_data_jsonObject(std::string type_name)
{
	if((act_Buffer_type == eVector_pub) || (act_Buffer_type == eVector_sub))
		find_main_type = "topic" ;	
	else if(act_Buffer_type == eVector_cltService) 
		find_main_type = "ros_service" ;
	else if(act_Buffer_type == eVector_srvService)
		find_main_type = "carcnt_service" ;

	find_type_name = type_name ;
	if(find_josonObjData()){
		erase_data_jsonObject(result_iter);	
	}
}
//-----------------------------------------------------------------------------
//-- swap assigned two jsonObjects   ---------------
bool UDPWorkerData::swap_data_jsonObject(int iter1,int iter2)
{
	//-- lock queueMutex --- 
	thd::lock_guard<thd::mutex> lock(lockMutex);
	//-- erase data ----
	int isize = Worker_Buffer.size() ;
	bool bRet = (iter1 < isize) && (iter2 < isize);
	if(bRet){ 
		vector<json>::iterator it1 = Worker_Buffer.begin() + iter1; 
		json jsonObject = *it1 ;
		vector<json>::iterator it2 = Worker_Buffer.begin() + iter2; 
		*it1 = *it2 ;
		*it2 = jsonObject ;

		vector<int>::iterator _it1 = Worker_status_Buffer.begin() + iter1; 
		int tmp = *_it1 ;
		vector<int>::iterator _it2 = Worker_status_Buffer.begin() + iter2; 
		*_it1 = *_it2 ;
		*_it2 = tmp ;
	}	

	return bRet ;	
}
//-----------------------------------------------------------------------------
//-- swap assigned two jsonObjects   ---------------
bool UDPWorkerData::swap_data_jsonObject(std::string type_name_1,std::string type_name_2)
{
	if((act_Buffer_type == eVector_pub) || (act_Buffer_type == eVector_sub))
		find_main_type = "topic" ;	
	else if(act_Buffer_type == eVector_cltService) 
		find_main_type = "ros_service" ;
	else if(act_Buffer_type == eVector_srvService)
		find_main_type = "carcnt_service" ;	

	find_type_name = type_name_1 ;
	bool bRet = find_josonObjData();
	if(!bRet)	return bRet ;
	//---------
	int iter1 = result_iter ;
	find_type_name = type_name_2 ;
	bRet = find_josonObjData();
	if(!bRet)	return bRet ;
	//---------
	int iter2 = result_iter ; 

	bRet = swap_data_jsonObject(iter1,iter2);

	return bRet ;
}
//-----------------------------------------------------------------------------
//-- swap assigned two jsonObjects   ---------------
bool UDPWorkerData::get_data_jsonObject(std::string type_name,json &jsonObject,SRV_PROC_Step &_Step,int &_iter)
{
	if((act_Buffer_type == eVector_pub) || (act_Buffer_type == eVector_sub))
		find_main_type = "topic" ;	
	else if(act_Buffer_type == eVector_cltService) 
		find_main_type = "ros_service" ;
	else if(act_Buffer_type == eVector_srvService)
		find_main_type = "carcnt_service" ;

	find_type_name = type_name ;
	bool bRet = find_josonObjData();
	if(!bRet)	return bRet ;
	//---------
	jsonObject = result_jsonObject ;
	_Step = result_Step ;
	_iter = result_iter ;

	return bRet ;
}
//-----------------------------------------------------------------------------
//-- get assigned jsonObject   ---------------
bool UDPWorkerData::get_data_jsonObject(int iter,json &jsonObject,SRV_PROC_Step &_Step)
{	
	int isize = Worker_Buffer.size() ;
	bool bRet = (iter < isize) ;
	if(bRet){ 
		vector<json>::iterator it1 = Worker_Buffer.begin() + iter; 
		jsonObject = *it1 ;
		vector<int>::iterator _it1 = Worker_status_Buffer.begin() + iter; 
		_Step = (SRV_PROC_Step)*_it1;
	}	
	return bRet ;		
}
//-----------------------------------------------------------------------------
//-- swap assigned two jsonObjects   ---------------
bool UDPWorkerData::get_data_SRV_PROC_Step(std::string type_name,SRV_PROC_Step &_Step)
{
	if((act_Buffer_type == eVector_pub) || (act_Buffer_type == eVector_sub))
		find_main_type = "topic" ;	
	else if(act_Buffer_type == eVector_cltService) 
		find_main_type = "ros_service" ;
	else if(act_Buffer_type == eVector_srvService)
		find_main_type = "carcnt_service" ;

	find_type_name = type_name ;
	bool bRet = find_josonObjData();
	if(!bRet)	return bRet ;
	//---------
	//jsonObject = result_jsonObject ;
	_Step = result_Step ;
	//_iter = result_iter ;

	return bRet ;
}
//-----------------------------------------------------------------------------
//-- get assigned jsonObject   ---------------
int UDPWorkerData::get_data_size()
{	
	int isize = Worker_Buffer.size() ;
	return isize ;		
}
//-----------------------------------------------------------------------------
//-- get_result_jsonObject ------------
json UDPWorkerData::get_result_jsonObject(int &_result_iter)
{
	_result_iter = result_iter ;
	return result_jsonObject ;
}
//-----------------------------------------------------------------------------
