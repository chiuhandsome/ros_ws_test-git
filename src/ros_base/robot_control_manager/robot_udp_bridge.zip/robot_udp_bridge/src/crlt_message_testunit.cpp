#include <robot_udp_bridge/crlt_message_testunit.h>
//#include <range/v3/all.hpp>
//#include <tools/ros_tools.h>
#include <ros_utility_tools/ros_tools.h>
//*****************************************************************************
//** main class crlt_message_testunit                                          ** 
//*****************************************************************************
//-----------------------------------------------------------------------------
//-- crlt_message_testunit constructor  -----
crlt_message_testunit::crlt_message_testunit(ros::NodeHandle &nh):nh_(nh)									 
{    
    nh_ = nh ;
    //------------------
    test_counter = 0 ;
    pubROS_cmd_vel = nh_.advertise<geometry_msgs::Twist>("cmd_vel", 10);
    test_counter_1 = 0 ;
    pubROS_cmd_pid = nh_.advertise<robot_control_msgs::PID>("cmd_pid", 10);

    // Timer Stuff
  
    desired_control_duration_ = ros::Duration(1.0 / controller_frequency_);
    control_loop_timer_ = nh_.createTimer(desired_control_duration_,
                                                  &crlt_message_testunit::controlLoopCallback,
                                                  this, false, false);  // one_shot=false(default), auto_start=false

    begin_Time = ros::Time::now() ;
    //control_loop_timer_.start();
   
}
//-----------------------------------------------------------------------------
//-- crlt_message_testunit de-constructor ---------------
crlt_message_testunit::~crlt_message_testunit()
{
  //test_msg_Interface->crltMessage_start_set(false);
  control_loop_timer_.stop();
}
//-----------------------------------------------------------------------------
void crlt_message_testunit::message_testunit_start()
{
    control_loop_timer_.start();
}
//-----------------------------------------------------------------------------
void crlt_message_testunit::message_testunit_stop()
{
    control_loop_timer_.stop();
}
//-----------------------------------------------------------------------------
void crlt_message_testunit::pubROS_cmd_vel_topic()
{
    test_counter ++;
    if(test_counter >=100)  test_counter = 0 ;    

    double linear_x = 0.1 + 0.01*test_counter ;
    double linear_y = 1.2 + 0.01*test_counter ;
    double angular_z = 0.2 + 0.01*test_counter ;

    cmd_vel_msg.linear.x = linear_x ;//0.2 ;//+ 0.01 * test_counter;
    cmd_vel_msg.linear.y = linear_y ;
    cmd_vel_msg.linear.z = 0.0 ;

    cmd_vel_msg.angular.x = 0.0 ;
    cmd_vel_msg.angular.y = 0.0 ;
    cmd_vel_msg.angular.z = angular_z ;//0.1 ;//+ 0.01 * test_counter ;

    pubROS_cmd_vel.publish(cmd_vel_msg);   
}
//-----------------------------------------------------------------------------
void crlt_message_testunit::pubROS_cmd_pid_topic()
{
    test_counter_1 ++;
    if(test_counter_1 >=100)  test_counter_1 = 0 ;   

    double _d = 0.01 + 0.01*test_counter ;
    double _p = 1.02 + 0.01*test_counter ;
    double _i = 0.20 + 0.01*test_counter ;

    cmd_pid_msg.d = _d ;
    cmd_pid_msg.i = _i ;
    cmd_pid_msg.p = _p ; 

    pubROS_cmd_pid.publish(cmd_pid_msg);   
    //ROS_INFO("pubROS_cmd_pid_topic -----------");  
}
//-----------------------------------------------------------------------------
void crlt_message_testunit::controlLoopCallback(const ros::TimerEvent& event)
{
    pubROS_cmd_vel_topic(); 
    pubROS_cmd_pid_topic();
    /*double fTime_period = (ros::Time::now() - begin_Time).toSec() ;
    std::string tmp = "Time Period:" + convert_str(fTime_period);
    ROS_INFO(tmp.c_str());*/
}
//-----------------------------------------------------------------------------
