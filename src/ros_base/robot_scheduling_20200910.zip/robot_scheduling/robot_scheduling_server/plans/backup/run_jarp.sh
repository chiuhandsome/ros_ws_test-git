#!/bin/bash
JARP_DIR=$PNP_LIB/../../Jarp
java -cp $JARP_DIR -jar $JARP_DIR/ultrajarp.jar
