#include <public_actions/worksheetrun_action.h>
#include <ros_utility_tools/table_mongodbstore_client.h>
#include <ros_utility_tools/ros_tools.h>
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
worksheetrun_action::worksheetrun_action(ros::NodeHandle nh,std::string name_as,std::string name_rcvr_as) :
                        nh_(nh),//name_as_(name_as),name_rcvr_as_(name_rcvr_as),
                        worksheetrun_as_(nh_,name_as, boost::bind(&worksheetrun_action::worksheetrun_as_CB, this, _1), false)//,
                        //db_process_rcvr_as_(nh_,name_rcvr_as, boost::bind(&db_process_action::db_process_rcvr_CB, this, _1), false)
{ 
    //_Recovery_current_time = 0;    
    ROS_INFO("db_process_as_.start()");
    worksheetrun_as_.start();
    //ROS_INFO("db_process_rcvr_as_.start()");
    //db_process_rcvr_as_.start();
}    
//-----------------------------------------------------------------------------
worksheetrun_action::~worksheetrun_action()
{
    
}
//-----------------------------------------------------------------------------
void worksheetrun_action::set_robot_scheduling_parameter(robot_scheduling_parameter* parameter)
{
    parameter_ = parameter ;    
}
//-----------------------------------------------------------------------------
void worksheetrun_action::worksheetrun_as_CB(const robot_scheduling_msgs::worksheetrunGoalConstPtr& goal)
{
    ROS_INFO("worksheetrun_as_CB");
    if (worksheetrun_as_.isPreemptRequested() || !ros::ok()){
        ROS_ERROR("worksheetrun_as_CB execution preempted.");
        worksheetrun_as_.setPreempted();
        return;
    }
    else{   
        std::shared_ptr<robot_scheduling_msgs::worksheetrunGoal> goal_ac_ptr = std::make_shared<robot_scheduling_msgs::worksheetrunGoal>();  
        int cmd_id = goal->cmd_id ;  
        std::string cmd_data = goal->cmd_data ; 
        ROS_INFO("cmd_id:%d , cmd_data:%s ",cmd_id,cmd_data.c_str()); 
        robot_scheduling_msgs::worksheetrunResult _result;
        if(cmd_id == robot_scheduling_msgs::worksheetrunGoal::WS_RUNCHECK){
            bool bWorkSheet_Start = parameter_->get_WorkSheetRun_Start();            
            _result.result = bWorkSheet_Start ? robot_scheduling_msgs::worksheetrunResult::OK :
                             robot_scheduling_msgs::worksheetrunResult::PASS ;
            worksheetrun_as_.setSucceeded(_result); 
            worksheet_current_item = 0 ;  
            ROS_INFO("<< WS_RUNCHECK status: %d>>",(int)bWorkSheet_Start); 
        }
        else if(cmd_id == robot_scheduling_msgs::worksheetrunGoal::WS_RUN){
            worksheet_items = parameter_->get_ac_action_worksheet_size();
            ROS_INFO("<< WS_RUN::parameter_->get_ac_action_worksheet_size(): %d>>",worksheet_items); 
            if(worksheet_items > 0){
                _result.result = robot_scheduling_msgs::worksheetrunResult::OK ;
                worksheetrun_as_.setSucceeded(_result);       
            }
            else{
                _result.result = robot_scheduling_msgs::worksheetrunResult::NOT_OK ;
                worksheetrun_as_.setAborted(_result);      
            }
        }
        else if(cmd_id == robot_scheduling_msgs::worksheetrunGoal::WS_RUNFINISh){
            ROS_INFO("<< WS_RUNFINISh::worksheet_current_item:%d   worksheet_items:%d>>",worksheet_current_item,worksheet_items); 
            if(worksheet_current_item >= worksheet_items){
                _result.result = robot_scheduling_msgs::worksheetrunResult::OK ;
                worksheetrun_as_.setSucceeded(_result);  
            }
            else{
                parameter_->set_worksheet_current_index(worksheet_current_item);
                _result.result = robot_scheduling_msgs::worksheetrunResult::NOT_FINISH ;
                worksheetrun_as_.setSucceeded(_result);     
            }            
        }
        else if(cmd_id == robot_scheduling_msgs::worksheetrunGoal::WS_RUNNEXT){
            worksheet_current_item++ ;
            _result.result = robot_scheduling_msgs::worksheetrunResult::OK ;
            worksheetrun_as_.setSucceeded(_result);     
        }
        else if(cmd_id == robot_scheduling_msgs::worksheetrunGoal::WS_ASSIGNINDEX){
            parameter_->set_worksheet_current_index(worksheet_current_item);
            _result.result = robot_scheduling_msgs::worksheetrunResult::OK ;
            worksheetrun_as_.setSucceeded(_result);         
        }
    }
}
//--------------------------------------------------------------------------------
